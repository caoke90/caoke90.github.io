// 引入公共配置1
import Vue from 'vue';
require('../common/base.css');
require('../common/750rem.css');
require('../common/marvel.css');

Vue.component('mv-img', require('../marvel/img.vue'));
Vue.component('mv-modal', require('../marvel/modal.vue'));
// require('./container.js');

import cardSync from "../api/cardSync.js";
cardSync.useDemo();

