// 引入公共配置1
import Vue from 'vue';

Vue.component('mv-modal', require('../marvel/modal.vue'));
Vue.component('mv-img', require('../marvel/img.vue'));


require('../common/base.css');
require('../common/marvel.css');

//容器
Vue.component('container', require("../marvel/container.vue"));
import App from '../views/admin.vue';

/* eslint-disable no-new */
new Vue({
  el: '#app',
  components: {
    //异步组件
    App: async function (resolve, reject) {
      resolve(App)
    }
  },
  template:'<div><mv-modal></mv-modal><App/></div>'
})
