import Vue from 'vue';
import MyComponent from '../marvel/container.vue'
Vue.component('container', MyComponent);
