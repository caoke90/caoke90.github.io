import 'es6-promise/auto';
import 'core-js/es7/array'
// pc端：使用路由、图片懒加载、element-ui、服务、组件
import Vue from 'vue'

// 修改移动端设备延迟300ms

import fastclick from 'fastclick';

const str = navigator.userAgent.toLowerCase();
let ver = str.match(/ os (.*?) like mac os/);
ver = ver ? ver[1].replace(/_/g,".") : '';
if(window.FastClick && (!ver || parseInt(ver) < 11)){
  window.FastClick.attach(document.body);
}


/*
  1、注册 服务容器 mv-modal
  增加服务的接口
* */

Vue.component('mv-modal', require('../marvel/modal.vue'));
Vue.component('mv-img', require('../marvel/img.vue'));


require('../common/base.css');
require('../common/750rem.css');
//容器
Vue.component('container', require("../marvel/container.vue"));

// 17练习域名
window.baseUrl = location.protocol + (process.env.baseUrl || '//' + location.host);
export default Vue;
