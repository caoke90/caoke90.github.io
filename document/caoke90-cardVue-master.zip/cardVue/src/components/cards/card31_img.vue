<template>
  <img  src="https://s2.ax1x.com/2019/08/20/mJ70qs.jpg" width="100%">
</template>
