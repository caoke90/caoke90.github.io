<template>
  <img  src="https://s2.ax1x.com/2019/08/19/m3mYe1.jpg" width="100%">
</template>
