<template>
  <container :mkey="card.mkey" :key="card.mkey"></container>
</template>
<script>
  export default {
    data() {
      return {};
    },
    props: ['card'],
    methods: {},
  };
</script>
