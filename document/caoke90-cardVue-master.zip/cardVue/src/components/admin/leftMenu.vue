<template>
  <div class="leftEdit" >
    <div class="active" v-if="hoverE" :style="{'top':top+'px'}">
      <container :mkey="dataUrl" :key="dataUrl"></container>
    </div>
    <div>
<!--      <div class="card10" v-if="cardMap">-->
<!--        <div class="card">-->
<!--          <h2 class="card-title">容器历史记录</h2>-->
<!--        </div>-->
<!--        <div class="card m-panel card28" :class="['m-col-4']">-->
<!--          <div class="card-wrap">-->
<!--            <div class="card-main">-->
<!--              <div class="m-item-box" v-for="(v,mkey) in cardMap" v-if="mkey[0]!=='_'" :key="mkey"  @mouseover="mouseover($event,mkey)" @mouseleave="mouseleave"  @click.prevent.stop="changePage(mkey)">-->
<!--                <div class="m-diy-btn m-box-col m-box-center m-box-center-a">-->
<!--                  <h4>{{mkey}}<i class="m-font m-font-plus"></i></h4>-->
<!--                </div>-->
<!--              </div>-->
<!--            </div>-->
<!--          </div>-->
<!--        </div>-->
<!--      </div>-->

      <div v-for="card in children" class="card10">
        <div class="card">
          <h2 class="card-title" v-if="card.title">{{card.title}}</h2>
        </div>
        <div class="card m-panel card28" :class="['m-col-'+card.col]">
          <div class="card-wrap">
            <div class="card-main">
              <div class="m-item-box" v-if="helpJSON[item]" v-for="item in card.items" @mouseover="mouseover($event,item)" @mouseleave="mouseleave" @click.prevent.stop="clickCard(item,card)">
                <div class="m-diy-btn m-box-col m-box-center m-box-center-a">
                  <h4>{{helpJSON[item].help}} <i class="m-font m-font-plus"></i></h4>
                </div>
              </div>
              <div class="m-item-box" v-else></div>
            </div>
          </div>
        </div>
      </div>

    </div>
    </div>

</template>

<script>
  import helpJSON from '../adminHelp.js';
  import Bus from '../../api/adminApi.js';

  export default{

    data:function () {
      return {
        cardMap:null,
        dataUrl:'_demo',
        pageData:Bus.pageData,
        children:[{
          "title":"页面",
          "col":"2",
          'type':'Page',
          "items":[
            "box",
            "tabview",
          ],
        },{
          "title":"基础类",
          "col":"2",
          "items":[
            "card13",
            "card2",
            "card3",
            "card8",
            "card9",
            "card20",
            "card21",
            "card22",
            "card23",
            "card24",
            "card25",
            "card26",
            "card28",
            "card29",
            "card31",
            "card32",
            "card33",
          ],
        },{
          "title":"业务类",
          "col":"2",
          "items":[
            "card2008",
            "card3001",
          ],
        }],
        hoverE:"",
        top:0,
        left:0,
        helpJSON:helpJSON
      }
    },
    methods:{
      clickCard(cardName,card) {
        //如果是页面
        if(this.pageData[cardName]){
          this.clickPage(cardName,card)
          return;
        }
        //添加卡片，更新path
        if(Bus.curPath.data.length>0){
          const num=Bus.curPath.data.length%2===0?2:1;
          const rqindex=Bus.curPath.data.length-num;
          const cindex=rqindex+1;
          const mkey=Bus.curPath.data[rqindex];
          const index=Bus.curPath.data[cindex];
          Bus.addCardByName(mkey,cardName)

          if(!index){
            Bus.curPath.data[cindex]=  Vue._cardMap[mkey].length-1
          }else{
            Bus.curPath.data[cindex]=1+parseInt(index)
          }
          Bus.refreshPath(Bus.curPath.data);
        }

      },
      clickPage(cardName,card){

        if(this.pageData[cardName]){
          // Vue._cardMap[cardName]=this.pageData[cardName];
        }
        Bus.root.dataUrl=cardName;
        Bus.root.key++;
        const cardHelp=Bus.adminHelp.getCardData(cardName)
        if(typeof cardHelp.getMkey==='function'){
          const mkey=cardHelp.getMkey(this.pageData[cardName])
          Bus.curPath.data=[mkey];
          Bus.curPath.key++;
        }
        Bus.editor.refreshData(this.pageData[cardName])
      },
      mouseover:function (e,cardName,obj) {
        if(this.hoverE){
          return;
        }
        this.hoverE=cardName;

        this.top=e.currentTarget.getBoundingClientRect().top;
        if(Bus.mActive){
          Bus.mActive.classList.remove("m-active")
        }
        Bus.mActive=e.currentTarget;
        Bus.mActive.classList.add("m-active")
        //展示容器
        if(this.pageData[cardName]){
          this.dataUrl=cardName;
          Vue._cardMap[cardName]=this.pageData[cardName]
        }else{
          //展示卡片
          this.dataUrl="_demo";
          Vue._cardMap["_demo"]=[Bus.adminJSON.getCardData(cardName)]
        }

      },
      mouseleave:function () {
        this.hoverE="";
        if(Bus.mActive){
          Bus.mActive.classList.remove("m-active")
          Bus.mActive=null
          if(this.dataUrl==='_demo'){
            Vue._cardMap['_demo']=[];
          }

        }
      }
    },
    mounted(){
      this.cardMap=Vue._cardMap;

    }
  };

</script>
<style rel="stylesheet/scss" type="text/css" lang="scss" scoped>
  .leftEdit{
    z-index: 10;
    overflow-x:visible;
    overflow-y:scroll;height:100vh;
    padding-bottom: 3rem;
    .active{

      z-index: 100;
      position: absolute;left: 102%;width: 375px;
      top:20px;
      img{
        max-width: 100%;
      }
    }
  }
  .card10{
    margin-bottom: 0.18rem;
    .m-font{
      color: #FF8200;
    }
  }
  .card10 .card-title{
    color: #939393;
    font-size:0.28rem;
    line-height:0.34rem;
    padding: 0.24rem 0 0.14rem 0.24rem;
    background: #f2f2f2;
  }
  .card28{
    overflow: visible;
  }
  .card28 .card-wrap .card-main {
    margin-bottom: -1px;
    /* autoprefixer: off */
    display: flex;
    flex-wrap: wrap; }

  .card28 .m-item-box {
    /*调用itembox组件,参看sasscore*/
    height: auto;
    line-height: 1;
    text-align: center;
    padding: 0.2rem 0 0.2rem;
    min-height: 1.12rem;
    display: -webkit-inline-box;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center; }
  .card28 .m-item-box::before {
    top: 0.32rem;
    bottom: 0.32rem; }
  .card28 .m-item-box::after {
    left: 0.32rem;
    right: 0.32rem; }
  .card28 .m-item-box .m-diy-btn img {
    width: 0.72rem;
    height: 0.72rem; }
  .card28 .m-item-box .m-diy-btn h4 {
    font-size: 0.24rem;
    margin: 0.14rem 0 0 0; }
  .card28 .m-item-box .m-diy-btn {
    cursor: pointer;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    position: relative;
    height: 100%; }
  .card28 .m-item-box .m-diy-btn h3 {
    font-size: 0.3rem;
    color: #333;
    margin-bottom: 0;
    font-weight: 700; }
  .card28 .m-item-box .m-diy-btn h3 + h4 {
    color: #939393; }

</style>
