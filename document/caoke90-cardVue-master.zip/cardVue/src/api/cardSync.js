import Vue from 'vue'
const cardSync={
  card9_img:r => require.ensure([], () => r(require("../components/cards/card9_img.vue")),'card9_img'),
  card20_img:r => require.ensure([], () => r(require("../components/cards/card20_img.vue")),'card20_img'),
  card21_img:r => require.ensure([], () => r(require("../components/cards/card21_img.vue")),'card21_img'),
  card25_img:r => require.ensure([], () => r(require("../components/cards/card25_img.vue")),'card25_img'),
  card31_img:r => require.ensure([], () => r(require("../components/cards/card31_img.vue")),'card31_img'),
  card32_img:r => require.ensure([], () => r(require("../components/cards/card32_img.vue")),'card32_img'),
  card33_img:r => require.ensure([], () => r(require("../components/cards/card33_img.vue")),'card33_img'),
  card2008_img:r => require.ensure([], () => r(require("../components/cards/card2008_img.vue")),'card2008_img'),
  card3001_img:r => require.ensure([], () => r(require("../components/cards/card3001_img.vue")),'card3001_img'),

  box:r => require.ensure([], () => r(require("../components/cards/box.vue")),'box'),
  tabview:r => require.ensure([], () => r(require("../components/cards/tabview.vue")),'tabview'),
  card1:r => require.ensure([], () => r(require("../components/cards/card1.vue")),'card1'),
  card2:r => require.ensure([], () => r(require("../components/cards/card2.vue")),'card2'),
  card3:r => require.ensure([], () => r(require("../components/cards/card3.vue")),'card3'),
  card7:r => require.ensure([], () => r(require("../components/cards/card7.vue")),'card7'),
  card8:r => require.ensure([], () => r(require("../components/cards/card8.vue")),'card8'),
  card9:r => require.ensure([], () => r(require("../components/cards/card9.vue")),'card9'),
  card10:r => require.ensure([], () => r(require("../components/cards/card10.vue")),'card10'),
  card11:r => require.ensure([], () => r(require("../components/cards/card11.vue")),'card11'),
  card13:r => require.ensure([], () => r(require("../components/cards/card13.vue")),'card13'),
  card14:r => require.ensure([], () => r(require("../components/cards/card14.vue")),'card14'),
  card20:r => require.ensure([], () => r(require("../components/cards/card20.vue")),'card20'),
  card21:r => require.ensure([], () => r(require("../components/cards/card21.vue")),'card21'),
  card22:r => require.ensure([], () => r(require("../components/cards/card22.vue")),'card22'),
  card23:r => require.ensure([], () => r(require("../components/cards/card23.vue")),'card23'),
  card24:r => require.ensure([], () => r(require("../components/cards/card24.vue")),'card24'),
  card25:r => require.ensure([], () => r(require("../components/cards/card25.vue")),'card25'),
  card26:r => require.ensure([], () => r(require("../components/cards/card26.vue")),'card26'),
  card28:r => require.ensure([], () => r(require("../components/cards/card28.vue")),'card28'),
  card29:r => require.ensure([], () => r(require("../components/cards/card29.vue")),'card29'),
  card30:r => require.ensure([], () => r(require("../components/cards/card30.vue")),'card30'),
  card31:r => require.ensure([], () => r(require("../components/cards/card31.vue")),'card31'),
  card32:r => require.ensure([], () => r(require("../components/cards/card32.vue")),'card32'),
  card33:r => require.ensure([], () => r(require("../components/cards/card33.vue")),'card33'),
  card100:r => require.ensure([], () => r(require("../components/cards/card100.vue")),'card100'),
  card200:r => require.ensure([], () => r(require("../components/cards/card200.vue")),'card200'),
  card2008:r => require.ensure([], () => r(require("../components/cards/card8.vue")),'card8'),
  card3001:r => require.ensure([], () => r(require("../components/cards/card9.vue")),'card9'),
};

function useAdmin() {
  for(let k in cardSync){
    if(!/_img$/.test(k)){
      if(cardSync[k+'_img']){
        Vue.component(k,cardSync[k+'_img']);
      }else{
        Vue.component(k,cardSync[k]);
      }
    }
  }
}
function useDemo() {
  for(let k in cardSync){
    if(!/_img$/.test(k)){
      Vue.component(k,cardSync[k]);
    }
  }
}
export default {
  useAdmin,
  useDemo,
}
