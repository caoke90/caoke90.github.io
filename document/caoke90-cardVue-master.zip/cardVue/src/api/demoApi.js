import Bus from "../marvel/bus.js";
import storage from "../utils/storage.js";
import cardSync from "./cardSync.js";
cardSync.useDemo();
//初始化数据
Bus.initData=async function(){
  Bus.dataUrl=storage.getData('dataUrl')
  Object.assign(Vue._cardMap,storage.getData('demoData'))

};

export default Bus;
