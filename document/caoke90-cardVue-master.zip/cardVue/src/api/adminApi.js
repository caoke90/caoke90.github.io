// 750兼容方案
(function(doc, win) {
  var docEl = doc.documentElement,
    resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
    recalc = function() {
      var clientWidth = docEl.clientWidth;
      if(!clientWidth) return;
      if(clientWidth >= 375) {
        docEl.style.fontSize = '50px';
      } else {
        docEl.style.fontSize = 100 * (clientWidth / 750) + 'px';
      }
    };
  if(!doc.addEventListener) return;
  win.addEventListener(resizeEvt, recalc, false);
  doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);

import adminJSON from "../components/adminJSON.js";
import adminHelp from "../components/adminHelp.js";
import demoJSON from "../components/demoJSON.js";
import Bus from "../marvel/bus.js";

import storage from "../utils/storage.js";
import cardSync from "./cardSync.js";
cardSync.useAdmin();
import {hget} from "../utils/hobj.js";
Bus.adminJSON=adminJSON;
Bus.adminHelp=adminHelp;
//当前选择
Bus.curPath={
  key:0,
  data:[]
};
Bus.pageData={
  box:Bus.adminJSON.getCardData('box'),
  tabview:Bus.adminJSON.getCardData('tabview'),
};
//选中
Bus.refreshPath=function(data){

  Bus.curPath.data=data;
  Bus.curPath.key++;
  if(Bus.curPath.data.length){
    const num=Bus.curPath.data.length%2===0?2:1;
    const rqindex=Bus.curPath.data.length-num;
    const cindex=rqindex+1;
    Bus.editor.refreshData(Vue._cardMap[data[rqindex]][data[cindex]])

  }else{
    Bus.editor.refreshData(null)
  }
};
//增加一个
Bus.addCardByName=function(mkey,cardName){

  const data=adminJSON.getCardData(cardName);
  let index;
  if(Bus.curPath.data.length===2){
    index=parseInt(Bus.curPath.data[1])+1;
  }else{
    index=Vue._cardMap[mkey].length;
  }
  Vue.addCardByData(mkey,data,index);
  // Bus.editor.refreshData(data)
  // Bus.refreshPath(mkey,index+1);
}
//移除所有
Bus.removeAll=function(mkey){
  Vue._cardMap[mkey]=[];
}
//添加一个移除其他的
Bus.addOneRemoveOther=function(mkey,cardName){
  Bus.removeAll(mkey);
  const data=adminJSON.getCardData(cardName);
  Vue.addCardByData(mkey,data);
}
Bus.addCardRemoveOther=function(mkey,card){
  Bus.removeAll(mkey);
  Vue.addCardByData(mkey,card);
  Bus.editor.refreshData(data)
}
//初始化数据
Bus.initData=function(){
  Bus.dataUrl=storage.getData('dataUrl')
  Object.assign(Bus.pageData,storage.getData('pageData')||{})
  Object.assign(Vue._cardMap,storage.getData('adminData')||{})
  Object.assign(Vue._cardMap,Bus.pageData)
}
function saveCardGroup(card_group){
  for(var i = 0; i < card_group.length; i++) {
    var card = card_group[i];
    if(typeof card.card_type=="number"){
      card.card_type="card"+card.card_type;
    }
    if(card.card_type === "card20") {
      var item = demoJSON.getCardData(card.card_type);
      item.title=card.title;
      item.height=card.pic_height;
      card_group[i] = item;
    }
    if(card.card_type === "card21") {
      var item = demoJSON.getCardData(card.card_type);
      item.title=card.title;
      item.height=card.pic_height;
      card_group[i] = item;
    }
    if(card.card_type === "card9") {
      var item = demoJSON.getCardData(card.card_type);
      card_group[i] = item;
    }
    if(card.card_type === "card100") {
      var item = demoJSON.getCardData(card.card_type);
      if(Array.isArray(item)){
        card_group[i] = item[0|Math.random()*item.length];
      }else{
        card_group[i] = item
      }
    }
    if(card.card_type === "card25") {
      var item = demoJSON.getCardData(card.card_type);
      card_group[i] = item;
    }
    if(card.card_type === "card31") {
      card.diff_endtime=parseInt((new Date(card.end_time).getTime()-new Date().getTime())/1000);
      card.diff_warningtime=parseInt((new Date(card.warning_time).getTime()-new Date().getTime())/1000);
    }
    if(card.card_type === "card32") {
      var item = demoJSON.getCardData(card.card_type);
      card.rate=item.rate;
      card.update_url=item.update_url;
      card.update_url_freq=item.update_url_freq;
      card.count=item.count;
    }
    if(card.card_type === "card33") {
      var item = demoJSON.getCardData(card.card_type);
      item.title=card.title;
      item.desc=card.desc;
      item.is_pic=card.is_pic;
      item.width=card.width;
      item.height=card.height;
      item.button_vote_text=card.button_vote_text;
      item.button_have_vote_text=card.button_have_vote_text;
      card_group[i] = item;
    }
    if(card.card_type === "card2008") {
      var item = demoJSON.getCardData(card.card_type);
      card_group[i] = item;
    }
    if(card.card_type === "card3001") {
      var item = demoJSON.getCardData(card.card_type);
      card_group[i] = item;
    }

  }
}
//保存
Bus.saveData=function(){
  storage.setData('viewData',Bus.viewData)
  storage.setData('adminData',Vue._cardMap)
  storage.setData('pageData',Bus.pageData)
  storage.setData('dataUrl',Bus.root.dataUrl)

  const demoData=storage.getData('adminData');
  demoData._demo=Bus.root.dataUrl;
  for(let mkey in demoData){
    const card_group=demoData[mkey];
    saveCardGroup(card_group)
    if(mkey===''||card_group.length===0){
      delete demoData[mkey]
    }
  }

  storage.setData('demoData',demoData)
}
Bus.clearData=function(){
  storage.clearData();
  location.reload()
}
document.addEventListener('keyup',function (e) {
  if((e.code==='Delete'||e.code==='Backspace')&&Bus.curPath.data.length==2){
    const mkey=Bus.curPath.data[0];
    const index=parseInt(Bus.curPath.data[1]);
    Vue._cardMap[mkey].splice(index,1)

    if(index>0){
      Bus.curPath.data[1]--;
    }else{
      Bus.curPath.data=[mkey];
    }
    Bus.curPath.key++
  }
})

document.addEventListener('click',function (e) {
  let ele=e.target;
  const arr=[]
  while (ele){
    if(ele.attributes&&ele.attributes.path){
      arr.unshift(ele.attributes.path.value)
    }
    ele=ele.parentNode
  }
  if(arr.length){
    Bus.refreshPath(arr);
    e.preventDefault()
  }
});

export default Bus;
