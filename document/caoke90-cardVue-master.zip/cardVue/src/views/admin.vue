<template>
  <div>
    <div class="g-bd5 f-cb">
      <div class="g-sd51" :style="{width:leftWidth+'px',marginRight:-leftWidth+'px'}" style="z-index: 100;position:fixed;">

        <leftedit></leftedit>

      </div>
      <div class="g-mn5">
        <div class="g-mn5c" :style="{marginRight:(rightWidth+10)+'px',marginLeft:(leftWidth+10)+'px'}">
          <div class="phone" >
            <div class="maintop" :key="Bus.curPath.key">当前选中：{{Bus.curPath.data.join('>')}}</div>
            <div class="page">
              <div class="boxcenter" >
                <container :mkey="dataUrl" :key="key" ></container>
<!--              <div class="boxcenter" :key="card.card_type">-->
<!--                <component :is="card.card_type" :card="card"></component>-->
<!--                <container :mkey="dataUrl"></container>-->
              </div>
            </div>

          </div>

        </div>
      </div>
      <div class="g-sd52" :style="{width:rightWidth+'px',marginLeft:-rightWidth+'px'}">

        <div class="right">
          <el-col style="margin-bottom: 10px;">
            <el-button plain @click="fabu">发布</el-button>
            <el-button plain @click="open">预览</el-button>
            <el-button plain @click="save">保存</el-button>
            <el-button plain @click="clearData">清空</el-button>
          </el-col>
          <div>
            <editor ref="editor"></editor>
          </div>
        </div>
      </div>
    </div>


  </div>
</template>

<script>
  //通信方式
  import Bus from '../api/adminApi.js';

  export default {
    data(){
      return {
        leftWidth:300,
        rightWidth:300,
        curPath:Bus.curPath,
        dataUrl:'',
        key:0,
        Bus:Bus,
      };

    },
    created(){
      Bus.root=this;
    },
    async mounted(){
      Bus.editor=this.$refs.editor;
      Bus.initData();
      if(Bus.dataUrl){
        this.dataUrl=Bus.dataUrl;
        const cardName=Bus.dataUrl;
        const cardHelp=Bus.adminHelp.getCardData(cardName)
        if(cardHelp&&typeof cardHelp.getMkey==='function'){
          const mkey=cardHelp.getMkey(Bus.pageData[cardName])
          Bus.curPath.data=[mkey];
          Bus.curPath.key++;
        }
        Bus.editor.refreshData(Bus.pageData[cardName])
      }
      this.key++
      this.dataUrl=this.dataUrl||'home'
      Bus.curPath.data=[this.dataUrl];
      Bus.curPath.key++;

    },
    components: {
      'leftedit': require('../components/admin/leftMenu.vue'),
      'editor': require('../components/admin/editor.vue')
    },
    methods:{


      fabu(){

      },
      clearData(){
        Bus.clearData()
      },
      open(){
        window.open('demo.html')
      },
      //保存
      save(){
        Bus.saveData()

      },

    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss" type="text/css" rel="stylesheet/scss">

  .g-bd5{
    width: 100%;
  }
  .g-sd51,.g-sd52{position:relative;float:left;width:300px;margin:0 -300px 0 0;}
  .g-sd52{float:right;width:300px;margin:0 0 0 -300px;}
  .g-mn5{float:left;width:100%;}
  .g-mn5c{margin:0 310px 0 375px;}


  .maintop{
    height: 100px;
    color: #fff;
    padding: 0 100px;
    font-size: 14px;
    line-height: 100px;
  }
  .phone{
    width: 575px; margin: 0 auto;  background: url("https://s2.ax1x.com/2019/08/19/m3AmOx.png") top center; background-repeat: no-repeat;background-size: 407px;
  }
  .page{
    position: relative;
    overflow-x: hidden;
    height: calc(100vh - 100px);
  }
  .boxcenter{
    width: 375px;margin: 0 auto;position: relative;
    background: #f0f0f0;
    height: 667px;
    overflow-y: scroll;
  }

  .right{
    overflow: scroll;height: 100vh;
  }
  .right .mint-field-core{
    color: #0bb20c;
  }
  .right .mint-field-core::placeholder{
    color: #0bb20c;
    opacity: 0.4;
  }

  .right .mint-cell-value a{
    cursor: pointer;
    color: #26a2ff;
  }
  .mint-tab-item-label{
    color: #404040;
  }
  .mint-tab-item.is-selected .mint-tab-item-label{
    color: #26a2ff;
  }
</style>
