<template>
  <div class="container" v-if="dataUrl">
    <container :mkey="dataUrl"></container>
  </div>
</template>

<script>
  //通信方式
  import Bus from '../api/demoApi.js';
  export default {
    data(){
      return {
        dataUrl:''
      };
    },
    async mounted(){

      Bus.initData()
      this.dataUrl=Bus.dataUrl;
    },
    components: {},
    methods:{}
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss" type="text/css" rel="stylesheet/scss">

</style>
