<template>
  <div :path="mkey" v-if="Array.isArray(card_group)">
    <div  v-for="(data,k) in card_group" :key="k" :path="k">
      <component  :is="data.card_type" :card="data" ></component>
    </div>
  </div>
  <component v-else-if="card_group&&card_group.card_type" :is="card_group.card_type" :card="card_group" :key="mkey+card_group.key"></component>
</template>
<script>


  import Vue from 'vue';
  /*
    往容器添加组件的接口
  * */

  Vue._cardMap={};
  Vue.addCardByData = function (mkey='mv',data,index) {
    if(!Vue._cardMap[mkey]){Vue._cardMap[mkey]=[]}

    const len=index||Vue._cardMap[mkey].length-1;
    Vue._cardMap[mkey].splice(len,0,data);
  };

  export default {
    data: function () {
      if(!Vue._cardMap[this.mkey]){Vue._cardMap[this.mkey]=[]}

      return {
        "card_group": Vue._cardMap[this.mkey],
      }
    },

    props: ['mkey'],
  };
</script>

