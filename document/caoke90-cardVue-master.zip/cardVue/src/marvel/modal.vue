<template>
  <div :key="mkey">
    <component v-for="name in modalMap[mkey]" :is="mkey+'-'+name" :key="name"></component>
  </div>
</template>
<script>
  import Vue from 'vue'
  import Bus from './bus';

  /*
    增加服务的接口
  * */
  Bus.modalMap={};
  Bus.addModalComponent = function (model,mkey,data) {
    if(!Bus.modalMap[mkey]){Bus.modalMap[mkey]=[]}

    if (Bus.modalMap[mkey].indexOf(model.name) === -1) {
      Bus.modalMap[mkey].push(model.name);
      Vue.component(mkey+"-" + model.name, model);
    }
  }

  export default {
    name: 'modal',
    data: function () {
      if(!Bus.modalMap[this.mkey]){
        Bus.modalMap[this.mkey]=[]
      }
      return {
        "modalMap": Bus.modalMap
      }
    },

    props: ['mkey'],
  };
</script>
