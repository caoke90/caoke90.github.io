###文件生成树
**有任何问题，请联系shanquan54@gmail.com**
```
├── build
│   ├── better.js
│   ├── build.js
│   ├── check-versions.js
│   ├── utils.js
│   ├── vue-loader.conf.js
│   ├── webpack.base.conf.js
│   ├── webpack.dev.conf.js
│   └── webpack.prod.conf.js
├── config
│   ├── dev.env.js
│   ├── index.js
│   ├── prod.env.js
│   ├── staging.env.js
│   └── test.env.js
├── dist
│   ├── admin.html
│   ├── container.html
│   ├── demo.html
│   ├── fonts
│   │   ├── element-icons.535877f.woff
│   │   └── element-icons.732389d.ttf
│   ├── img
│   │   └── sprite.cbc55b9.svg
│   └── js
│       ├── admin.b83fbe1.js
│       ├── box.b8ae268.js
│       ├── card1.9da7881.js
│       ├── card10.93edd6b.js
│       ├── card100.439f35d.js
│       ├── card11.692955c.js
│       ├── card13.3060bb3.js
│       ├── card14.30dd408.js
│       ├── card2.b76569a.js
│       ├── card20.6c4c7a6.js
│       ├── card200.f9add93.js
│       ├── card2008_img.b42784f.js
│       ├── card20_img.fe2cc1c.js
│       ├── card21.26da2a7.js
│       ├── card21_img.006f275.js
│       ├── card22.1583cbe.js
│       ├── card23.a1abaa1.js
│       ├── card24.46ba186.js
│       ├── card25.f3929e1.js
│       ├── card25_img.38d43e5.js
│       ├── card26.17307f2.js
│       ├── card28.5c3eb90.js
│       ├── card29.f9a1193.js
│       ├── card3.b842703.js
│       ├── card30.efabb2b.js
│       ├── card3001_img.6b7cc95.js
│       ├── card31.adbd395.js
│       ├── card31_img.55ef366.js
│       ├── card32.747730b.js
│       ├── card32_img.78a64eb.js
│       ├── card33.601bb92.js
│       ├── card33_img.0117fa3.js
│       ├── card7.ee30de1.js
│       ├── card8.e67e448.js
│       ├── card9.d117a9e.js
│       ├── card9_img.0b4cc6e.js
│       ├── container.474953d.js
│       ├── demo.88bb041.js
│       └── tabview.1c41542.js
├── index.html
├── mock
│   ├── index.js
│   ├── movie
│   │   ├── Act_Starpoll
│   │   └── starinfo
│   ├── rewrite.js
│   └── subject
│       └── h5
│           ├── ajax_getpolllist
│           ├── callbackoperator
│           ├── getcardinfo
│           ├── getpageinfo
│           ├── getuserandtask
│           └── ok
├── node_modules
├── package.json
├── README.en.md
├── README.md
├── src
│   ├── api
│   │   ├── adminApi.js
│   │   ├── ajax.js
│   │   ├── cardSync.js
│   │   └── demoApi.js
│   ├── assets
│   │   ├── css
│   │   │   ├── animate.css
│   │   │   ├── swiper.css
│   │   │   └── swiper.min.css
│   │   ├── font
│   │   │   ├── font.css
│   │   │   ├── goldv.png
│   │   │   ├── marvelfont.eot
│   │   │   ├── marvelfont.svg
│   │   │   ├── marvelfont.ttf
│   │   │   ├── marvelfont.woff
│   │   │   ├── marvelfont.woff2
│   │   │   ├── sprite.css
│   │   │   └── sprite.svg
│   │   ├── img
│   │   │   ├── common_icon_play.png
│   │   │   ├── dayu.svg
│   │   │   ├── fire@3x.png
│   │   │   ├── icon_article.png
│   │   │   ├── icon_map.png
│   │   │   ├── icon_rig.png
│   │   │   ├── icon_sele_ring.png
│   │   │   ├── jiantou.svg
│   │   │   ├── none.png
│   │   │   ├── phone.png
│   │   │   └── session_tips_icon@3x.png
│   │   └── js
│   │       ├── swiper.esm.bundle.js
│   │       ├── swiper.esm.js
│   │       ├── swiper.js
│   │       ├── swiper.min.js
│   │       └── swiper.min.js.map
│   ├── common
│   │   ├── 750rem.css
│   │   ├── 750rem.js
│   │   ├── base.css
│   │   ├── js
│   │   │   ├── audioPlayer.js
│   │   │   ├── errorCode.js
│   │   │   ├── jsError.js
│   │   │   ├── logger.js
│   │   │   ├── mathJax.js
│   │   │   ├── practiceTypeDict.js
│   │   │   ├── questionUtils.js
│   │   │   ├── task.js
│   │   │   └── utils
│   │   │       ├── index.js
│   │   │       ├── logConfig.js
│   │   │       └── URLUtils.js
│   │   ├── marvel.css
│   │   ├── mbase.js
│   │   └── scss
│   │       ├── animate.scss
│   │       ├── common.scss
│   │       └── question.scss
│   ├── components
│   │   ├── admin
│   │   │   ├── drag.vue
│   │   │   ├── editor.vue
│   │   │   ├── editorItem.vue
│   │   │   ├── leftMenu.vue
│   │   │   └── webview.vue
│   │   ├── adminHelp.js
│   │   ├── adminJSON.js
│   │   ├── card.vue
│   │   ├── cards
│   │   │   ├── box.vue
│   │   │   ├── card1.vue
│   │   │   ├── card10.vue
│   │   │   ├── card100.vue
│   │   │   ├── card11.vue
│   │   │   ├── card13.vue
│   │   │   ├── card14.vue
│   │   │   ├── card2.vue
│   │   │   ├── card20.vue
│   │   │   ├── card200.vue
│   │   │   ├── card2008_img.vue
│   │   │   ├── card20_img.vue
│   │   │   ├── card21.vue
│   │   │   ├── card21_img.vue
│   │   │   ├── card22.vue
│   │   │   ├── card23.vue
│   │   │   ├── card24.vue
│   │   │   ├── card25.vue
│   │   │   ├── card25_img.vue
│   │   │   ├── card26.vue
│   │   │   ├── card28.vue
│   │   │   ├── card29.vue
│   │   │   ├── card3.vue
│   │   │   ├── card30.vue
│   │   │   ├── card3001_img.vue
│   │   │   ├── card31.vue
│   │   │   ├── card31_img.vue
│   │   │   ├── card32.vue
│   │   │   ├── card32_img.vue
│   │   │   ├── card33.vue
│   │   │   ├── card33_img.vue
│   │   │   ├── card7.vue
│   │   │   ├── card8.vue
│   │   │   ├── card9.vue
│   │   │   ├── card9_img.vue
│   │   │   └── tabview.vue
│   │   ├── demoJSON.js
│   │   ├── other
│   │   │   ├── weibo-article.vue
│   │   │   ├── weibo-footer.vue
│   │   │   ├── weibo-media.vue
│   │   │   ├── weibo-title.vue
│   │   │   └── weibo.vue
│   │   ├── page
│   │   │   └── card202.vue
│   │   └── weibo
│   │       ├── page-article.vue
│   │       ├── weibo-article.vue
│   │       ├── weibo-footer.vue
│   │       ├── weibo-header.vue
│   │       ├── weibo-icon.vue
│   │       ├── weibo-media.vue
│   │       ├── weibo-title.vue
│   │       ├── weibo-video.vue
│   │       └── weibo.vue
│   ├── entry
│   │   ├── admin.js
│   │   ├── container.js
│   │   └── demo.js
│   ├── filters
│   │   ├── fromNow.js
│   │   ├── index.js
│   │   ├── star.js
│   │   └── wordsCount.js
│   ├── marvel
│   │   ├── bus.js
│   │   ├── components
│   │   │   ├── actionsheet.vue
│   │   │   ├── file.vue
│   │   │   ├── img.vue
│   │   │   ├── loadmore.vue
│   │   │   ├── modal.vue
│   │   │   ├── msgbox.vue
│   │   │   ├── pswp
│   │   │   │   ├── default-skin
│   │   │   │   │   ├── default-skin.css
│   │   │   │   │   ├── default-skin.png
│   │   │   │   │   ├── default-skin.svg
│   │   │   │   │   └── preloader.gif
│   │   │   │   └── photoswipe.css
│   │   │   ├── pswp.vue
│   │   │   ├── switch.vue
│   │   │   ├── toast.vue
│   │   │   └── topbar.vue
│   │   ├── container.vue
│   │   ├── directives
│   │   │   ├── inf-scroll.js
│   │   │   └── mvlink.js
│   │   ├── flatlist.vue
│   │   ├── img.vue
│   │   ├── index.js
│   │   ├── modal.vue
│   │   └── vue-touch.js
│   ├── scss
│   │   ├── _sassCore.scss
│   │   ├── _var.scss
│   │   ├── checkin.scss
│   │   ├── compose.scss
│   │   ├── emoticon.scss
│   │   ├── form
│   │   │   ├── _fform.scss
│   │   │   ├── _fgrid.scss
│   │   │   ├── _normal.scss
│   │   │   ├── form.scss
│   │   │   └── mixins
│   │   │       ├── _breakpoints.scss
│   │   │       ├── _clearfix.scss
│   │   │       ├── _grid-framework.scss
│   │   │       ├── _grid.scss
│   │   │       └── _media.scss
│   │   ├── lib
│   │   │   ├── _adapter.scss
│   │   │   ├── _alert.scss
│   │   │   ├── _animation.scss
│   │   │   ├── _bottombar.scss
│   │   │   ├── _bubble.scss
│   │   │   ├── _button.scss
│   │   │   ├── _common.scss
│   │   │   ├── _dialog.scss
│   │   │   ├── _fontface.scss
│   │   │   ├── _fonticon.scss
│   │   │   ├── _form.scss
│   │   │   ├── _guide.scss
│   │   │   ├── _icon.scss
│   │   │   ├── _layout.scss
│   │   │   ├── _loading.scss
│   │   │   ├── _panel.scss
│   │   │   ├── _pop.scss
│   │   │   ├── _popup.scss
│   │   │   ├── _reset.scss
│   │   │   ├── _sassCore.scss
│   │   │   ├── _tab.scss
│   │   │   ├── _tabbar.scss
│   │   │   ├── _tips.scss
│   │   │   ├── _topbar.scss
│   │   │   ├── _topnav.scss
│   │   │   ├── _var.scss
│   │   │   └── base.scss
│   │   └── weixinStatus.scss
│   ├── tpl
│   │   └── demo.html
│   ├── utils
│   │   ├── dataURItoBlob.js
│   │   ├── emojiSupport.js
│   │   ├── file.js
│   │   ├── fullscreenApi.js
│   │   ├── hobj.js
│   │   ├── image.js
│   │   ├── LRU.js
│   │   ├── storage.js
│   │   └── ua.js
│   └── views
│       ├── admin.vue
│       └── demo.vue
├── static
└── webpack-assets.json
```
