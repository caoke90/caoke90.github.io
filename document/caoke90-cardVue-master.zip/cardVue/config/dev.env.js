'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  buildTime:new Date().toLocaleString(),
  NODE_ENV: process.env.NODE_ENV||"development",
  baseUrl:'',
  assetsPublicPath:'',
  assetsSubDirectory:'',
});
