'use strict'
module.exports = {
  buildTime:new Date().toLocaleString(),
  NODE_ENV: process.env.NODE_ENV||"test",
  baseUrl: "",
  assetsPublicPath: '',
  assetsSubDirectory: '',
}
