'use strict'
module.exports = {
  buildTime:new Date().toLocaleString(),
  NODE_ENV: process.env.NODE_ENV||"staging",
  baseUrl: "",
  assetsPublicPath: '',
  assetsSubDirectory: '',
}
