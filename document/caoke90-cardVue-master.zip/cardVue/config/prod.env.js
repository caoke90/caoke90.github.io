'use strict'
module.exports = {
  buildTime:new Date().toLocaleString(),
  NODE_ENV: process.env.NODE_ENV||"production",
  baseUrl: "",
  assetsPublicPath: 'http://www.caoke.xyz/cardVue/',
  assetsSubDirectory: '',
}
