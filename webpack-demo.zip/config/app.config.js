require('../src/utils/Format')// 日期
// app内配置
const path = require('path')
const glob = require('glob')
const fs = require('fs')
const qs = require('qs')
const NODE_ENV = process.env.NODE_ENV
const {getUrlNode} = require('./execFromNodeOptions');
const UrlNode=getUrlNode();

if (NODE_ENV === 'production' && process.env.buildEnv !== 'test') {
  for (const k in UrlNode) {
    const item = UrlNode[k]
    if (item.build === 'dev') {
      delete UrlNode[k]
    } else {
      delete item.dev_title
      delete item.build
    }
  }
}
// stg1  http://stg1-lps-web.daikuan.360.cn
// stg2  http://stg2-lps-web.daikuan.360.cn
// stg3  http://36.110.233.229
// prod  https://cdn.daikuan.360.cn
// 需要维护的版本
module.exports = {
  NODE_ENV: NODE_ENV,
  buildEnv: process.env.buildEnv,
  curVersion: (new Date()).Format('yyMMdd'),
  path: NODE_ENV === 'development' ? 'dist' : 'dist/front', // 打包发布目录
  publicPath: NODE_ENV === 'development' ? '/' : '/static/wlhfqk/front/', // 资源根目录
  drop_console: process.env.buildEnv !== 'test', // 打开vconsole
  UrlNode: UrlNode
}
