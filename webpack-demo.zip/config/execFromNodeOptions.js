const fs=require('fs')
const path=require('path')
const glob=require('glob')
const qs=require('qs')
//获取views目录的页面配置
function getUrlNode(){
  const vuedirPath=glob.sync(__dirname+'/../src/views/')[0]
  const arr1 = glob.sync(vuedirPath+'**/*.vue')
  const UrlNode={}
  arr1.forEach(function (file) {
    const urlName=path.basename(file,'.vue')+'.html';
    const temp=fs.readFileSync(file).toString();
    const obj={
      title:'默认标题'
    }
    if(/\/\/页面配置 *(.+) */.test(temp)){
      const nobj=qs.parse(RegExp.$1)
      Object.assign(obj,nobj)
    }
    UrlNode[urlName]=obj
  })
  return UrlNode;
}
//__dirname表示子模块的目录
module.exports={
  path,
  fs,
  getUrlNode,
  getText:function(url){
    return fs.readFileSync(path.join(this.__dirname,url)).toString()
  },
}