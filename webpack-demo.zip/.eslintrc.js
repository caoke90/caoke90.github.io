module.exports = {
  env: {
    browser: true,
    es6: true
  },
  extends: [
    'standard',
    'plugin:vue/recommended'
  ],
  parserOptions: {
    parser: 'babel-eslint',
    ecmaVersion: 12,
    sourceType: 'module'
  },
  plugins: [
    'vue'
  ],
  rules: {
    'quote-props': [0, 'always'],
    'spacing': 'off',
    'space-before-blocks': 'off',
    'singleQuote': 'off',
    'keyword-spacing': 'off',
    'no-console': 'off',
    'camelcase': 'off',
    'comma-spacing': 'off',
    'comma-dangle': 'off',
    'padded-blocks': 'off',
    'eol-last': 'off',
    'spaced-comment': 'off',
    'vue/html-closing-bracket-spacing': 'off',
    'vue/mustache-interpolation-spacing': 'off',
    'vue/max-attributes-per-line': 'off',
    'vue/html-self-closing': 'off',
    'vue/multiline-html-element-content-newline': 'off',
    'vue/singleline-html-element-content-newline': 'off',
    'no-irregular-whitespace': 'off', // 这禁止掉 空格报错检查
    'vue/html-closing-bracket-newline': 'off',
    'vue/no-v-html': 'off'
  },
  globals: {
    Native: false
  }
}
