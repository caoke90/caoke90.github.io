//mkdir.js
const fs=require('fs');
const dirCache={};
function mkdir(filepath) {
  filepath=filepath.replace(/\\/g,'/')
    const arr=filepath.split('/');
    let dir=arr[0];
    for(let i=1;i<arr.length;i++){
        if(!dirCache[dir]&&!fs.existsSync(dir)){
            dirCache[dir]=true;
            fs.mkdirSync(dir);
        }
        dir=dir+'/'+arr[i];
    }
}
module.exports=mkdir;
