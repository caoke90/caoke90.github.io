const axios = require('axios');
const fs = require('fs');
 function getText(url) {
   return fs.readFileSync(url).toString();
}
module.exports=getText;
