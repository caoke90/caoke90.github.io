const mkdir=require('./mkdir')
const fs = require('fs');
async function setText(filepath,buffer) {
    mkdir(filepath);
    fs.writeFileSync(filepath,buffer)
}
module.exports=setText;