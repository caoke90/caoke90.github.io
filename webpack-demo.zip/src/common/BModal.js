//BModal 公共弹窗组件
import Vue from 'vue';
const BModal = new Vue();
export default BModal;

