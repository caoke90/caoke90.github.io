import Config from './Config'

const url = {}
for (const k in Config.UrlNode) {
  url[k] = Config.UrlNode[k].url
}

// 本地地址
const api = {
  LPS: '/api/gateway.do', // 接口地址
  LPSV2: '/api/v2/gateway.do', // 接口地址
  IPAYLPS: '/api/ipay/gateway.do', // 接口地址
  IPAYLPS_NEW: '/service/ipay/apigateway.do',

  MMS: '/api/gateway.do', // 营销接口地址
  ELE: '/api/element.do', // 接口地址
  HELP: '/live.html?gestureAble=Y&appChannel=APP&source=weilinghua&pkg=jietiao', // 客服地址
  ANALYSLS_URL: '/ubas/event/report', // 数据上报地址

  OLD_WLH_BILL: '/pending.html?jumpStatus=5&e_track=FQK', // 老微零花账单
  CONTRACTCDN: Config.query.serverEnv === 'dev' ? '/contract/' : '/',
  INTEGRAL_URL: Config.query.serverEnv === 'UAT' ? '/api/benefit/benefitway.do' : '/benefit/api/v1/gateway.do',
  WLH_CDN: '/'
}
// cdn.daikuan.360.cn
const baseUrlMap = {
  // 测试环境地址
  STG: {
    baseUrl: 'http://stg1-lps-web.daikuan.360.cn',
    MMS: 'http://stg1-mms-web.daikuan.360.cn',
    ELE: 'http://stg1-ele-web.daikuan.360.cn',
    HELP: 'http://support.uat.360jie.com.cn',
    ANALYSLS_URL: 'http://stg3-ubas-web.daikuan.360.cn',
    OLD_WLH_BILL: 'http://demo.t.360.cn/agw',
    CONTRACTCDN: 'http://stg1-lps-web.daikuan.360.cn/static/testpackage/html',
    INTEGRAL_URL: 'http://101.199.113.66',
    WLH_CDN: 'http://stg1-lps-web.daikuan.360.cn/static/testpackage/wlh-h5'
  },
  // 测试环境地址
  STG2: {
    baseUrl: 'http://stg2-lps-web.daikuan.360.cn',
    MMS: 'http://111.206.250.138',
    ELE: 'http://stg2-ele-web.daikuan.360.cn',
    HELP: 'http://support.uat.360jie.com.cn',
    ANALYSLS_URL: 'http://stg3-ubas-web.daikuan.360.cn',
    OLD_WLH_BILL: 'http://demo.t.360.cn/agw',
    CONTRACTCDN: 'http://stg2-lps-web.daikuan.360.cn/static/testpackage/html',
    INTEGRAL_URL: 'http://101.199.113.57',
    WLH_CDN: 'http://stg2-lps-web.daikuan.360.cn/static/testpackage/wlh-h5'
  },
  // 测试环境地址
  STG3: {
    baseUrl: 'http://stg3-lps-web.daikuan.360.cn',
    MMS: 'http://stg3-mms-web.daikuan.360.cn',
    ELE: 'http://stg3-ele-web.daikuan.360.cn',
    HELP: 'http://support.uat.360jie.com.cn',
    ANALYSLS_URL: 'http://stg3-ubas-web.daikuan.360.cn',
    OLD_WLH_BILL: 'http://demo.t.360.cn/agw',
    CONTRACTCDN: 'http://stg3-lps-web.daikuan.360.cn/static/testpackage/html',
    INTEGRAL_URL: 'http://101.199.113.28',
    WLH_CDN: 'http://stg3-lps-web.daikuan.360.cn/static/testpackage/wlh-h5'
  },
  // 测试环境地址
  UAT: {
    baseUrl: 'http://36.110.213.55',
    MMS: 'http://36.110.236.175',
    ELE: 'http://stg1-ele-web.daikuan.360.cn',
    HELP: 'http://support.uat.360jie.com.cn',
    ANALYSLS_URL: 'http://stg3-ubas-web.daikuan.360.cn',
    OLD_WLH_BILL: 'http://demo.t.360.cn/agw',
    CONTRACTCDN: 'http://stg1-lps-web.daikuan.360.cn/static/testpackage/html',
    INTEGRAL_URL: 'http://36.110.213.55',
    WLH_CDN: 'http://stg1-lps-web.daikuan.360.cn/static/testpackage/wlh-h5'
  },
  // 生产环境地址
  PRD: {
    baseUrl: 'https://daikuan.360.cn',
    MMS: 'https://mms.daikuan.360.cn',
    ELE: 'https://ele.daikuan.360.cn',
    HELP: 'https://support.360-jr.com',
    ANALYSLS_URL: 'https://ubas.daikuan.360.cn',

    OLD_WLH_BILL: 'https://pay.360jinrong.net',
    CONTRACTCDN: 'https://cdn.daikuan.360.cn/html',
    INTEGRAL_URL: 'https://cafe-front.daikuan.360.cn',
    WLH_CDN: 'https://cdn.xjietiao.com/wlh-h5'
  }
}
const mapData = baseUrlMap[Config.query.serverEnv]
if (mapData) {
  for (const name in api) {
    const baseUrl = mapData[name] || mapData.baseUrl
    if (/^\//.test(api[name])) {
      api[name] = baseUrl + api[name]
    }
  }
}
const methods = {
  // 首页优惠券信息查询接口
  HOME_COUPON_QUERY: 'qihoo.sdk.marketing.micro.pk.index.data.query',
  // 跨年活动红包领取接口
  NEW_YEAR_2021_DRAW: 'qihoo.sdk.marketing.activity.newyear2021.receive.info',
  // 跨年活动信息查询接口
  NEW_YEAR_2021: 'qihoo.sdk.marketing.activity.newyear2021.data.info',
  // ELE通用点击接口
  ELE_COMMON_CLICK: 'qihoo.sdk.ele.elements.commonClick',
  // 微零花首页接口
  WLH_iPayHome: 'qihoo.sdk.ipay.home.page',
  // 微零花老首页接口
  WLH_iPayOldHome: 'qihoo.sdk.ipay.old.bill',
  // 状态查询接口
  WLH_STATUS: 'qihoo.sdk.lps2ipay.home.entrance.info',
  // 通用提交接口
  WLH_iPayCommit: 'qihoo.sdk.appl.item.iPayCommit',
  // 通用查询接口v2
  WLH_iPayQueryState: 'qihoo.sdk.ipay.query.state',
  // 通用提交接口v2
  WLH_iPayAppLCommit: 'qihoo.sdk.ipay.appl.commit',
  // 人脸侦测
  WLH_iPayFaceDetect: 'qihoo.sdk.ipay.real.time.face.detect',
  // 开卡激活接口
  openCardActive: 'qihoo.sdk.ipay.card.openCardActive',
  // 开卡流程查询接口
  WLH_openCardQuery: 'qihoo.sdk.ipay.card.openCardQuery',
  // 开卡提交接口
  WLH_openCardCommit: 'qihoo.sdk.ipay.card.openCardCommit',
  // 多文件上传
  COMMON_MULTI_FILE_UPLOAD: 'qihoo.sdk.common.multifile.upload.new',
  // OCR 身份证识别
  USER_OCRINFO_QUERY: 'qihoo.sdk.user.ocrinfo.query',
  // 用户分期查询
  WLH_iPayQueryTerm: 'qihoo.sdk.ipay.installment.query.term',
  // 保存用户分期
  WLH_iPaySaveTerm: 'qihoo.sdk.ipay.installment.save.term',
  // 微零花 优惠卷查询接口
  WLH_queryCoupon: 'qihoo.sdk.marketing.micro.pocket.my.coupon.query',
  // 微零花 设置优先级券
  WLH_SET_PRIORITY_COUPON: 'qihoo.sdk.marketing.user.wlh.set.priority.coupon',
  IPAY_H5_STATUS_INFO: 'qihoo.sdk.ipay.h5.status.info', // 登录后微零花状态查询

  /**
   * 免息额度相关接口
   */
  INTEREST_FREE_QUOTA_HOME: 'qihoo.sdk.marketing.micro.interestFreeQuota.home', // 首页免息额度信息
  WELFARE_FLOATING_LAYER: 'qihoo.sdk.marketing.micro.user.welfare.floating.layer', // 用户福利浮层
  LOANED_COUPON_RECOMMEND: 'qihoo.sdk.marketing.micro.user.loaned.coupon.recommend', // 已动支状态查询推荐优惠券
  INTEREST_FREE_QUOTA_DETAIL: 'qihoo.sdk.marketing.micro.interestFreeQuota.detail', // 免息额度详情页
  INTEREST_FREE_QUOTA_SWITCH: 'qihoo.sdk.marketing.micro.interestFreeQuota.switch', // 免息额度开关更新
  INTEREST_FREE_QUOTA_DATA: 'qihoo.sdk.marketing.micro.interestFreeQuota.data', // 免息额度组成
  INTEREST_FREE_QUOTA_LOG: 'qihoo.sdk.marketing.micro.interestFreeQuota.log', // 免息额度记录

  // 开卡有礼
  WLH_openCardIssue: 'qihoo.sdk.marketing.activity.micropk.open.card.issue',
  // 灰度开卡有礼
  WLH_openCardIssue2: 'qihoo.sdk.marketing.activity.micropk.open.card2.issue',
  // 资源位
  queryElements: 'qihoo.sdk.ele.elements.query',
  // 资源位点击
  commonClickElements: 'qihoo.sdk.ele.elements.commonClick',
  // 我的账单-首页
  BILL_PAGE: 'qihoo.sdk.ipay.bill.first.page',
  // 年度账单-12月列表
  BILL_MONTH_LIST: 'qihoo.sdk.ipay.bill.month.list',
  // 账单明细
  BILL_DETAIL: 'qihoo.sdk.ipay.bill.detail',
  // 订单详情
  BILL_LOAN_DETAIL: 'qihoo.sdk.ipay.bill.loan.detail',
  // 退款详情接口
  BILL_REFUND_DETAIL: 'qihoo.sdk.ipay.bill.refund.detail',
  // 账单详情接口
  BILL_INSTALLMENT_DETAIL: 'qihoo.sdk.ipay.bill.installment.detail',
  // 还款优惠券
  REPAY_COUPON: 'qihoo.sdk.marketing.micro.pocket.coupon.query.for.use',
  // 还款金额校验
  CHECK_AMOUNT: 'qihoo.sdk.ipay.check.amount',
  // 用户还款记录
  BILL_QUERY_REPAY: 'qihoo.sdk.ipay.bill.query.repay',

  // 我的额度页面
  USER_AMOUNT: 'qihoo.sdk.ipay.home.user.amout',
  // 介绍页合同列表
  INTRO_AGS_LIST: 'qihoo.sdk.ipay.introduction.ags.list',
  // 合同列表接口
  USER_AGS_LIST: 'qihoo.sdk.ipay.home.user.ags.list',
  // 借条查询合同协议详情接口
  USER_AGR_QUERY: 'qihoo.sdk.agr.query',
  // LPS协议信息预览 qihoo.sdk.agr.preview
  USER_AGR_PREVIEW: 'qihoo.sdk.ipay.home.preview.ags.agreement',
  // IPAY协议参数预览
  IPAY_AGR_PREVIEW: 'qihoo.sdk.ipay.agreement.preview',

  // 查看设置分期合同预览
  PREVIEW_INSTALLMENT_AGREEMENT: 'qihoo.sdk.ipay.home.preview.agreement',

  // 介绍页-合同列表，对一类协议进行了打包
  AGREEMENT_PARCEL_LIST: 'qihoo.sdk.ipay.query.agreement.parcel.list',

  // 微信支付宝页面查询银行卡列表
  WECHAT_ALIPAY_BANK_CARD: 'qihoo.sdk.ipay.query.bind.open.card.list',

  // 笔笔返首页信息查询
  CASH_BACK_INDEX: 'qihoo.sdk.marketing.activity.micro.draw.cash.back.index',
  // 笔笔返抽奖接口
  CASH_BACK_DRAW: 'qihoo.sdk.marketing.activity.micro.draw.cash.back',
  // 笔笔返奖品列表接口
  CASH_BACK_AWARD_LIST: 'qihoo.sdk.marketing.activity.micro.draw.cash.back.award',

  // 设置页面
  NOTICE_QUERY: 'qihoo.sdk.ipay.notice.query',
  // 设置页面
  NOTICE_CLICK: 'qihoo.sdk.ipay.notice.click',
  // 设置页面
  SETTING_PAGE_QUERY: 'qihoo.sdk.ipay.home.install',
  // 获取是否设置小额免密接口
  QUOTA_FREE_PASS_QUERY: 'qihoo.sdk.ipay.quota.free.pass.query',
  // 保存免密金额设置接口
  QUOTA_FREE_PASS_SAVE: 'qihoo.sdk.lps2ipay.quota.free.pass.save',
  // 关闭免密金额接口
  QUOTA_PASS_CLOSE: 'qihoo.sdk.lps2ipay.quota.free.pass.close',
  // 获取免密金额选项列表接口
  QUOTA_FREE_PASS_OPTIONS: 'qihoo.sdk.ipay.quota.free.pass.options',
  // 获取二维码接口
  PAY_GETQRNO: 'qihoo.sdk.lps2ipay.pay.getQrNo',
  // 二维码状态轮询接口
  PAY_qrNoStatus: 'qihoo.sdk.ipay.pay.qrNoStatus',
  // 二维码校验支付密码（超额度）
  PAY_checkTransPwd: 'qihoo.sdk.lps2ipay.qrNo.checkTransPwd',

  // 消费-消费列表分页展示
  PAY_CONSUME_LIST: 'qihoo.sdk.ipay.pay.consume.list',

  // 还款补鉴权校验
  qihoo_sdk_ipay_check_bank: 'qihoo.sdk.ipay.check.bank',
  // 多资金方鉴权校验接口
  qihoo_sdk_ipay_multi_check_bank: 'qihoo.sdk.ipay.multi.check.bank',
  // 还款补鉴权发送验证码
  qihoo_sdk_ipay_verify_code: 'qihoo.sdk.ipay.verify.code',
  // 还款补鉴权-确认
  qihoo_sdk_ipay_repay_auth: 'qihoo.sdk.ipay.repay.auth',
  // 首页卡号验证交易密码
  LPSTOIPAY_user_verifyPwd: 'qihoo.sdk.lps2ipay.user.verifyPwd',
  // 支持银行列表
  qihoo_sdk_bank_info_list: 'qihoo.sdk.bank.info.list',
  // 多卡- 银行卡列表
  qihoo_sdk_ipay_repay_card_list: 'qihoo.sdk.ipay.repay.card.list',
  // 多卡- 提交(发送验证码)
  qihoo_sdk_ipay_repay_card_appl: 'qihoo.sdk.ipay.repay.card.appl',
  // 多卡- 验证
  qihoo_sdk_ipay_repay_card_cert: 'qihoo.sdk.ipay.repay.card.cert',
  // H5授信节点资料详情接口
  IPAY_H5_INFO_COMPLETE: 'qihoo.sdk.ipay.h5.info.complete.status',
  // 多文件上传
  COMMON_MULTI_FILE_UPLOAD_OLD: 'qihoo.sdk.common.multifile.upload',
  // 补充Face接口
  FACE_COMMIT: 'qihoo.sdk.ipay.user.iouSupp.face',
  // 查询银行卡列表
  BANK_INFO_LIST: 'qihoo.sdk.bank.info.list',
  // 银行卡鉴权重新发送短信
  CUST_CARD_VERIFYCODE: 'qihoo.sdk.cust.card.verifycode',
  // 地推绑卡获取短信验证码
  CUST_FRIST_CARD_SUBMIT: 'qihoo.sdk.cust.firstCard.submit',
  // (补银行卡) 提交
  CARD_COMMIT: 'qihoo.sdk.ipay.cust.bankCard.submit',
  // 补充联系人接口
  CONTACT_COMMIT: 'qihoo.sdk.ipay.user.iouSupp.contactCommit',
  // 协议查询接口
  H5_AGREEMENT_LIST: 'qihoo.sdk.ipay.h5.agreement.list',
  // H5激活开卡
  ACTIVATION_BANK_CARD: 'qihoo.sdk.ipay.card.h5.openCardActive',
  // 数据上送接口
  DRAW_CRAWL_USER_DATA: 'qihoo.sdk.ipay.trade.draw.crawl',
  // 补充idcard 接口
  COMMIT_OCR: 'qihoo.sdk.ipay.user.iouSupp.idCardOcrCommit',
  // 天天抽奖-查询
  ACT_LOTTERY_QUERY: 'qihoo.sdk.marketing.activity.micro.draw.index',
  // 天天抽奖-点击抽奖
  ACT_LOTTERY_DRAW: 'qihoo.sdk.marketing.activity.micro.user.draw',
  // 天天抽奖-奖品列表
  ACT_LOTTERY_PRIZE_LIST: 'qihoo.sdk.marketing.activity.micro.user.draw.award.list',

  // 天天抽奖V2-查询
  ACT_LOTTERY_QUERY_V: 'qihoo.sdk.marketing.activity.micro.draw.v2.index',
  // 天天抽奖V2-点击抽奖
  ACT_LOTTERY_DRAW_V: 'qihoo.sdk.marketing.activity.micro.user.v2.draw',
  // 天天抽奖V2-奖品列表
  ACT_LOTTERY_PRIZE_LIST_V: 'qihoo.sdk.marketing.activity.micro.draw.award.v2.list',
  // 是否降价查询接口
  PRICE_REDUCE_QUERY: 'qihoo.sdk.ipay.price.reduce.query',
  // 降价签约接口
  PRICE_REDUCE_SIGN: 'qihoo.sdk.ipay.price.reduce.sign',

  // 查询是否已领取券活动奖励（绑定微信活动）
  BIND_WECHAT_STATUS: 'qihoo.sdk.marketing.activity.is.receive',
  // 查询绑定微信活动规则
  BIND_WEHCAT_RULES: 'https://cdn.daikuan.360.cn/dir_mkteditor/activity_xd/template/copywriting/20200426/fa11508a46b970bc862c9a7958e72b54.txt',

  // 订阅服务页面入口
  SMS_SUBSCRIBE_ENTRY: 'qihoo.sdk.ipay.service.subscribe.entrance',
  // 服务订阅
  SERVICE_SUBSCRIBE_ADD: 'qihoo.sdk.ipay.service.subscribe.add',
  // 自动续费查询
  SERVICE_AUTO_RENEWAL_QUERY: 'qihoo.sdk.ipay.service.auto.renewal.query',
  // 取消自动续费
  SERVICE_AUTO_RENEWAL_CANCEL: 'qihoo.sdk.ipay.service.auto.renewal.cancel',

  // mgm
  // mgm首页信息查询
  MGM_INDEX_INFO_QUERY: 'qihoo.sdk.marketing.micro.share.home.page',
  // mgm拆提额包接口
  MGM_UP_AMOUNT: 'qihoo.sdk.marketing.micro.share.up.amount',
  // mgm邀请记录查询
  MGM_INVITE_RECORD: 'qihoo.sdk.marketing.micro.share.invite.list',
  // mgm分享到小程序
  MGM_SHARE_MINIPROGRAM: 'qihoo.sdk.marketing.share.query.v2',
  // mgm活动规则
  MGM_ACTIVITY_RULE: 'https://cdn.daikuan.360.cn/dir_mkteditor/external_static/h8tp1g5ddf71592465657198.html',
  // 查询活动配置的券信息
  SERVICE_ACTIVITY_COUPON: 'qihoo.sdk.marketing.activity.coupon.query',
  // 花花币活动
  // 花花币-明细
  HHB_DETAILS: 'qihoo.sdk.wlh.activity.user.bills',
  // 花花币-福利列表
  HHB_WELFARE_LIST: 'qihoo.sdk.wlh.activity.goods.list',
  // 花花币-商品兑换
  HHB_GOODS_EXCHANGE: 'qihoo.sdk.wlh.activity.user.exchage',
  // 花花币-我的奖品
  HHB_MY_PRIZE: 'qihoo.sdk.wlh.activity.user.reward',
  // 花花币-领取
  HHB_RECEIVE: 'qihoo.sdk.wlh.user.receive.award',
  // 花花币-用户账户信息
  HHB_ACCOUNT_INFO: 'qihoo.sdk.wlh.activity.user.account',
  // 花花币-营销优惠券信息
  HHB_COUPON_INFO: 'qihoo.sdk.marketing.micro.pocket.my.coupon.max.total.amount.query',
  // 微零花绑卡活动首页
  activity_micro_bind_card: 'qihoo.sdk.marketing.activity.micro.bind.card.index',
  activity_micro_bind_card_receive_task: 'qihoo.sdk.marketing.activity.micro.bind.card.receive.task',
  activity_micro_bind_card_receive_award: 'qihoo.sdk.marketing.activity.micro.bind.card.receive.award',

  // 花花币
  // 用户账户信息
  HHB_USER_ACCOUNT: 'qihoo.sdk.wlh.daily.user.account',
  // 花花币明细
  HHB_USER_BILLS: 'qihoo.sdk.wlh.daily.user.bills',
  // 福利列表
  HHB_GOODS_LIST: 'qihoo.sdk.wlh.daily.goods.list',
  // 优惠券弹框包
  HHB_GOODS_DETAIL: 'qihoo.sdk.wlh.daily.goods.detail',
  // 福利兑换
  HHB_USER_EXCHAGE: 'qihoo.sdk.wlh.daily.user.exchage',
  // 任务列表
  HHB_USER_TASK_LIST: 'qihoo.sdk.wlh.user.task.list',
  // 用户签到
  HHB_USER_SIGN: 'qihoo.sdk.wlh.user.sign',
  // 领取任务奖励
  HHB_USER_RECEIVE_AWARD: 'qihoo.sdk.wlh.user.receive.award',
  // 进阶商品查询
  HHB_JINJIE_INFO: 'qihoo.sdk.wlh.daily.jinjie.info',

  // 分享信息查询
  MARKETING_SHARE_QUERYV2: 'qihoo.sdk.marketing.share.query.v2',

  // 首页新增资金方弹窗接口
  ADD_FUND_AGREEMENT: 'qihoo.sdk.ipay.popup.agreement.list',
  // 首页新增资金方弹窗-确认接口
  CONFIRM_ADD_FUND: 'qihoo.sdk.ipay.sign.popup.agreement',

  // 百信银行一键绑卡查询
  BAIXIN_BIND_CARD_QUERY: 'qihoo.sdk.ipay.query.bind.support',
  // 百信银行一键绑卡
  BAIXIN_BIND_CARD: 'qihoo.sdk.ipay.baixin.bind.card',
  // 微零花双11主页查询接口
  MMS_DOUBLE_ONE_COUPON: 'qihoo.sdk.marketing.wlh.promotion.home.page',
  // 微零花双11券领取查询接口
  MMS_DOUBLE_ONE_RECEIVE: 'qihoo.sdk.marketing.wlh.promotion.receive',

  IPAY_USER_CARD_OPEN_STATUS: 'qihoo.sdk.ipay.user.card.open.status',
  IPAY_activity_double11_recommend_goods: 'qihoo.sdk.ipay.activity.double11.recommend.goods',

  // 借款结果
  IPAY_LOAN_RELATE: 'qihoo.sdk.ipay.loan.relate.info',

  // 弹框 - 协议查询接口 (新户)
  IPAY_DIALOG_AGS_LIST: 'qihoo.sdk.ipay.dialog.ags.list',
  // 一户多卡-开卡结果查询
  IPAY_MORE_CARD_INFO: 'qihoo.sdk.ipay.query.more.card.open.result',
  // 一户多卡-提交开卡
  IPAY_MORE_CARD_COMMIT: 'qihoo.sdk.ipay.more.card.open.commit',
  // 一户多卡-银行卡列表查询
  IPAY_MORE_CARD_LIST: 'qihoo.sdk.ipay.query.open.card.list',
  // 查询是否可信设备
  IPAY_USER_DEVICE_TRUST_STATUS: 'qihoo.sdk.ipay.user.device.trust.status',
  // 优惠券展示页面费率展示
  IPAY_INSTALLMENT_QUERY_INTRODUCE_RATE: 'qihoo.sdk.ipay.installment.query.introduce.rate',

  // 微零花圣诞活动-查询用户奖励
  BENEFIT_CHRIS_QUERY_AWARD: 'qihoo.sdk.benefit.ipay.chris.activity.query.user.all.award',
  // 微零花圣诞活动-查询全部任务
  BENEFIT_CHRIS_QUERY_TASK: 'qihoo.sdk.benefit.ipay.chris.activity.query.all.task',
  // 微零花圣诞活动-用户奖励历史列表
  BENEFIT_CHRIS_AWARD_HISTORY: 'qihoo.sdk.benefit.ipay.chris.activity.receive.award.history',
  // 微零花圣诞活动-领取任务奖励
  BENEFIT_CHRIS_RECEIVE_AWARD: 'qihoo.sdk.benefit.ipay.chris.activity.receive.award',
  // 微零花圣诞活动-用户签到
  BENEFIT_CHRIS_USER_SIGN: 'qihoo.sdk.benefit.activity.user.sign',

  // 周周赢iPhone-周周送iphone首页
  ACT_WEEK_PK_MAIN: 'qihoo.sdk.activity.week.pk.main',
  // 周周赢iPhone-立即报名
  ACT_WEEK_PK_APPLY: 'qihoo.sdk.activity.week.pk.apply',
  // 周周赢iPhone-立即订阅
  ACT_WEEK_PK_SUB: 'qihoo.sdk.activity.week.pk.sub',
  // 周周赢iPhone-参与记录
  ACT_WEEK_PK_PARTICIPATION: 'qihoo.sdk.activity.week.pk.participation',
  // 周周赢iPhone-历史排行榜
  ACT_WEEK_PK_HISTORY: 'qihoo.sdk.activity.week.pk.history',

  // 还款账单写入日历
  REPAY_CALENDAR_SCHEDULE: 'qihoo.sdk.trade.repay.calendar.schedule',

  query_home_all_task: 'qihoo.sdk.benefit.ipay.query.all.task',
  query_home_user_sign_record: 'qihoo.sdk.benefit.activity.user.sign.record',
  query_home_user_sign: 'qihoo.sdk.benefit.activity.user.sign',
  home_receive_task: 'qihoo.sdk.benefit.ipay.receive.task',
  home_receive_award: 'qihoo.sdk.benefit.ipay.receive.award',
  qihoo_sdk_ipay_anti_fraud_sniffer: 'qihoo.sdk.ipay.anti.fraud.sniffer',
  qihoo_sdk_ipay_fire_event: 'qihoo.sdk.ipay.fire.event'
}
export default function (name) {
  return api[name] || methods[name] || url[name]
}
