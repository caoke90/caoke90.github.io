//包含第三方的公共库以及初始化
import '../assets/base/base.css';
import '../assets/base/750rem.css';
import './vendor.less';
//fastclick
const str = navigator.userAgent.toLowerCase();
let ver = str.match(/ os (.*?) like mac os/);
ver = ver ? ver[1].replace(/_/g,".") : '';
if(!ver || parseInt(ver) < 11){
  FastClick.attach(document.body);
}
import Vue from 'vue';

import mvmodal from '../utils/modal.vue';
Vue.component('mv-modal', mvmodal);//服务层

const rootEle = document.createElement('div')
document.body.appendChild(rootEle)   //创建节点
import _ from 'lodash';
if (typeof Object.assign != 'function') {
  Object.assign=_.assign;
}
if (typeof Array.prototype.includes != 'function') {
  Array.prototype.includes=function (arg) {
    return _.includes(this,arg)
  }
}
if (typeof Array.prototype.isArray != 'function') {
  Array.prototype.isArray=function (arg) {
    return _.isArray(this,arg)
  }
}
window.requestAnimFrame = (function () {
  return window.requestAnimationFrame ||
    window.webkitRequestAnimationFrame ||
    window.mozRequestAnimationFrame ||
    function (callback) {
      window.setTimeout(callback, 100);
    };
})();


/**
 * iOS键盘收起页面未下移bug
 */
(/iphone|ipod|ipad/i.test(navigator.appVersion))&&document.addEventListener('blur', (e) => {
  // 这里加了个类型判断，因为a等元素也会触发blur事件
  ['input', 'textarea'].includes(e.target.localName) && document.body.scrollIntoView(false)
}, true)
export {rootEle};