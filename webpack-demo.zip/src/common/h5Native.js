/* eslint-disable no-undef */
import Config from './Config'
import Api from './api'
import getQueryObject from '../utils/getQueryObject'
import getQueryString from '../utils/getQueryString'
import copyToClipboard from '../utils/copyToClipboard'
import conCurentLoad from '../utils/conCurentLoad'
import { initCache, limitCache, getCache, delCache, getCacheData, updateCache } from '../utils/limitCache'
import sleep from '../utils/sleep'
import router from '../router'
import { Toast } from 'vant'
import _ from 'lodash'
axios.defaults.method = 'post'
axios.defaults.headers.post['Content-Type'] = 'application/json'
function getUrl (url, option) {
  const data = Object.assign({}, option)
  if (/(.+)\?(.+)/.test(url)) {
    url = RegExp.$1
    const paramstr = RegExp.$2
    Object.assign(data, getQueryObject(paramstr))
  }
  const str = getQueryString(data)
  if (str) {
    return url + '?' + getQueryString(data)
  } else {
    return url
  }
}
const ua = navigator.userAgent.toUpperCase()
const IS_IOS = /(IPHONE|IPAD|IPOD|IOS)/gi.test(ua)
// 用户信息，使用getUserInfo;
const uerInfo = {
  userNo: ''
}
try {
  Object.assign(uerInfo, JSON.parse(localStorage.getItem('dev_uerInfo') || '{}'))
} catch (e) {
}
// 设备信息，使用getDeviceInfo;
const deviceInfo = {
  buildSerial: 'f11fb8c5c376940af13780e6cc952973',
  imsi: '460016627505874',
  deviceName: 'liao的 iPhone',
  wifiMac: '3CB6B75AA1A8',
  isJailbreaking: 'N',
  brand: 'iPhone',
  deviceSn: 'B8451623-E488-8C81-D62A-2843F4E30164',
  deviceIp: '192.168.1.185',
  uuid: '00000000-78ef-1565-be24-15520b102783',
  bssid: '74:3e:2b:f:27:cc',
  deviceFingerPrintM2: '68a2ac66-9e23-45dc-b12a-d6777d1f2456',
  deviceFingerPrintTd: 'ewogICJ0b2tlbklkIiA6ICIzNjBqaWViYmQyNDlkODEwMGIxYTM1ZGE2NDQ4ZDUzYjM0MWZlNyIsCiAgIm9zIiA6ICJpT1MiLAogICJwcm9maWxlVGltZSIgOiA2MDQsCiAgInZlcnNpb24iIDogIjIuMS40Igp9',
  wifiName: 'qibu-public',
  networkType: 'WIFI',
  model: 'iPhone',
  deviceOsVersion: 'iOS 10.0.2',
  isEmulator: 'N',
  usedStorage: '8.50G',
  deviceOs: 'IOS',
  deviceFingerPrintBr: '-',
  terminalType: 'app',
  totalStorage: '11.04G'
}
// 获取安卓渠道信息
const channelInfo = {
  sourceType: '',
  channleId: '',
  productName: '',
  packageName: '',
  productLabel: '',
  subChannel: '',
  channelStat: ''
}
// 额外日志
const reportExtra = {
  e_source: ''
}
export default {
  uerInfo: uerInfo,
  router: null,
  IS_IOS: IS_IOS,
  IS_IPHONE_X: IS_IOS && ((window.screen.height === 812 && window.screen.width === 375) || (window.screen.height === 896 && window.screen.width === 414)),
  IS_ANDROID: ua.indexOf('ANDROID') !== -1,
  reportExtra: reportExtra,
  // 埋点ubas
  reportUbas (option) {
    console.log('report', option)
    setTimeout(async () => {
      const uerInfo = await this.getUserInfo()
      const deviceInfo = await this.getDeviceInfo()
      const channelInfo = await this.getAndroidChannleInfo()
      var eventCode = option.eventCode || option.eventId || {}
      var bizData = option.bizData || option.customAttributes || {}
      bizData.e_source = reportExtra.e_source
      const _data = {
        bizCode: '360PAY',
        eventCode: eventCode,
        pageName: Config.pageName + '.html',
        userOprTime: (new Date()).getTime(),
        hostApp: (String(channelInfo.productLabel).toUpperCase() === 'LOAN' ? '360LOAN' : String(channelInfo.productLabel).toUpperCase()) || '360LOAN',
        sourceType: channelInfo.sourceType || '',
        channelSource: channelInfo.channleId || '',
        subChannel: channelInfo.subChannel || '',
        token: uerInfo.token || '',
        userNo: uerInfo.userNo || '',
        productCode: '360PAY',
        appVersion: deviceInfo.appVersion,
        h5Version: localStorage.getItem('wlhVersion'),
        deviceFingerPrint: (this.IS_IOS ? deviceInfo.idfaUUID : deviceInfo.android_id) || '',
        deviceIp: deviceInfo.clientIp || '',
        deviceOs: this.IS_IOS ? 'IOS' : 'ANDROID',
        bizData: JSON.stringify(bizData),
        deviceInfo: JSON.stringify(deviceInfo)
      }
      var n = 'log_' + (new Date()).getTime()
      var c = window[n] = new Image() // 把new Image()赋给一个全局变量长期持有
      c.onload = (c.onerror = function () { window[n] = null })
      c.src = Api('ANALYSLS_URL') + '?' + getQueryString(_data)
      c = null // 释放局部变量c
    }, 0)
  },
  // 获取设备信息
  async getAndroidChannleInfo () {
    return channelInfo
  },
  // 获取设备信息
  async getUserInfo () {
    return uerInfo
  },
  // 获取设备信息
  async getDeviceInfo () {
    return deviceInfo
  },
  // 状态栏，字体、电池颜色
  updateStatusBarStyle (light) {
    console.log(
      `%c updateStatusBarStyle: ${light ? 'light' : 'black'} `,
      light ? 'background: #217AFE; color: #fff' : 'background: #ddd; color: #000')
  },
  /**
   * 加密SS接口字段
   * @param params {object} 需加密数据对象
   * @param callback {function} 回调函数
   */
  getRSAEncodeString (params, callback) {
    // eslint-disable-next-line standard/no-callback-literal
    callback({
      flag: 'S',
      data: {
        result: 'S',
        params: {
          password: '123123'
        }
      }
    })
  },
  // 拦截android返回按钮
  interceptBackPressEvent () {
    console.log('interceptBackPressEvent')
  },
  // 打开第三方支付，目前使用场景是打开微信支付
  openThirdPay (options) {
    const json = {
      data: options.data || {},
      callback: options.callback || ''
    }
    console.log('openThirdPay request', json)
  },
  // 支付宝支付
  //start:调起支付授权 end:支付宝回调到app,用户主动杀掉app则可能无回调信息
  aliPayOrder (order,callback) {
    const json = {
      data: { order: order },
      callback: callback
    }
    setTimeout(function () {
      callback({
        "flag": "S",
        "msg": "",
        "data": {
          "status": "start",
          "result": {}
        }
      })
      setTimeout(function () {
        callback({
          "flag": "S",
          "msg": "",
          "data": {
            "status": "end",
            "result": {}
          }
        })
      },50000)
    },1000)
  },
  back (option) {
    location.href = '/'
  },
  copy (text) {
    copyToClipboard(text)
  },
  forward (option) {
    const { url = '', data } = option.data || {}
    if (/wlh_.+?\.html/.test(url)) {
      this.router.push({
        path: url.replace(/.+(wlh_.+?\.html)/, '$1'),
        query: { ...Config.query, ...data }
      })
      console.log('内部跳转:', url.replace(/.+(wlh_.+?\.html)/, '$1'))
    } else {
      window.open(getUrl(option.data.url, Config.query))
      console.log('外部部跳转:', option.data.url)
    }
  },
  go (url, data) {
    this.forward({ data: { url, data } })
  },
  async getIDPhoto (data) {
    return {
      flag: 'S',
      data: { portraitImgID: 'qh_idcard_portrait_udid', sdkType: 'FACEAA', idcardImg: '', photoData: '' }
    }
  },
  openURL (url) {
    location.href = url
  },
  checkInstalledApp () {
    return { flag: 'S', data: { installed: 'Y' } }
  },
  gestureAble () {
    return { flag: 'S' }
  },
  share (data = {}, callback) {
    console.log('app分享数据', data)
    setTimeout(() => {
      typeof callback === 'function' &&
      // eslint-disable-next-line standard/no-callback-literal
      callback({
        flag: 'S',
        data: {
          result: 'S'
        }
      })
    }, 1000)
  },
  // 通用ajax
  async _ajax (option) {
    try {
      const com = await this.getCommonOpts()
      const res = await axios.post(
        option.url + `?method=${option.data.method}`,
        Object.assign({}, option.data, com)
      )
      return res.data
    } catch (e) {
      return { flag: 'F', msg: '网络异常' }
    }
  },
  // 兼容并发加载的情况
  async ajax (options) {
    const id = JSON.stringify(options.data)
    return conCurentLoad(id, () => {
      return Native._ajax(options)
    })
  },
  // 初始化的时候获取缓存
  initCache: initCache,
  getCache: getCache,
  getCacheData: getCacheData,
  delCache: delCache,
  updateCache: updateCache,
  // 接口缓存请求
  async ajaxCache (options) {
    const id = JSON.stringify(options.data)
    // 提交接口不存储
    if (options.noCache === true) {
      return this.ajax(options)
    }
    // 接口缓存20条，兼容一次接口异常
    return limitCache({
      id: id,
      name: options.name || options.data.method,
      useCache: options.useCache,
      store: !!options.store,
      queryNoError: !!options.queryNoError
    }, () => {
      return this.ajax(options)
    })
  },
  /**
   * @param {object} opts                                                  可选参数对象，必选
   * @param {
   *  'LPS' | 'IPAYLPS' | 'IPAYLPS_NEW' | 'MMS' | 'ELE' | 'HELP' |
   *  'ANALYSLS_URL' | 'OLD_WLH_BILL' | 'CONTRACTCDN' | 'INTEGRAL_URL'
   * } opts.url                                                            接口基础路径，非必选，默认 'IPAYLPS'
   * @param {string} opts.method                                           接口实际路径，必选
   * @param {object} opts.data                                             请求参数，非必选，默认 {}
   * @param {boolean} opts.isShowLoading                                   是否显示loading，非必选，默认 true
   * @param {string} opts.loadingText                                      loading加载文本，非必选，默认 Msg.loading
   * @param {boolean} opts.isShowToast                                     是否显示错误Toast，非必选，默认 true
   * @param {boolean} opts.useCache                                        是否使用接口缓存，非必选，默认 false
   * @returns {object} data | resonpse                                        接口返回信息，如果请求成功，则返回data层级数据，否则返回整个数据
   */
  async ajaxv2 (opts) {
    const options = _.merge({}, opts)
    const isShowToast = options.isShowToast !== false
    const isShowLoading = options.isShowLoading !== false
    console.log(isShowLoading, options.data.method)
    const loadingText = options.loadingText === undefined ? '加载中...' : options.loadingText
    isShowLoading && Toast.loading({
      message: loadingText,
      forbidClick: true,
      duration: 0
    })
    try {
      if (typeof options.data.bizContent === 'object') {
        options.data.bizContent = JSON.stringify(options.data.bizContent)
      }
      const res = await this.ajaxCache(options)
      isShowLoading && Toast.clear()
      if (res && res.flag === 'S') {
        return res.data
      }
      throw res
    } catch (err) {
      console.error(err)
      isShowLoading && Toast.clear()
      isShowToast && err && err.msg && Toast(err.msg)

      const msg = err ? (err.msg || err.message) : '空数据'
      this.reportUbas({
        eventCode: 1500114,
        bizData: {
          method: options.data.method,
          msg: msg
        }
      })
      return Promise.reject(err)
    }
  },
  async getCommonOpts () {
    const userInfo = await this.getUserInfo()
    return {
      ABFrom: 'A',
      appVersion: '1.6.5',
      channelSource: 'CH_001',
      custNo: userInfo.custNo,
      deviceInfo: JSON.stringify(deviceInfo),
      h5Version: '1010100001',
      hostApp: '360LOAN',
      openCrawlFlag: 'Y',
      pageName: Config.pageName + '.html',
      productCode: '360JIETIAO',
      sourceType: 'APK',
      timestamp: '1589875920190',
      token: userInfo.token,
      userNo: userInfo.userNo,
      version: '1.6.5'
    }
  },
  async request (option) {
    const newOption = { ...option }
    const { url } = newOption
    delete newOption.url
    const response = await axios[newOption.type](url, newOption)
    return response.data
  },
  requestCommonOption: {
    version: '1.6.5',
    appVersion: '1.6.5', // ios&安卓      接口版本号   Y
    h5Version: '1010100001',
    channelSource: 'CH_001', //   ios 安卓可以加   宿主渠道编号  Y
    hostApp: '360LOAN',
    // sourceType: "APKFQ",
    sourceType: 'APK',
    deviceInfo: JSON.stringify(deviceInfo),
    staffNo: 'SN5869572491271234753',
    pageName: 'index.html',
    productCode: '360JIETIAO', // ios&安卓      产品编码    Y
    ...uerInfo
  },
  // 通用ajax
  // wlh内部跳转
  jumpUrl (url, option) {
    option = option || {}
    if (/(.+)\?(.+)/.test(url)) {
      url = RegExp.$1
      const paramstr = RegExp.$2
      Object.assign(option, getQueryObject(paramstr))
    }
    Object.assign(Config.query, option)
    const nurl = url + '?' + getQueryString(Config.query)
    router.push(nurl)
  },
  // 验证交易密码
  async verifyTradersPwd (option) {
    const pwd = window.prompt(option.title)
    // eslint-disable-next-line no-throw-literal
    if (!pwd) throw { code: 'F', msg: '密码不能为空' }
    console.log(`输入的密码为: ${pwd}`)
    console.log('请求参数为: ', option.businessParams)
    return { flag: 'S', code: null, data: { verifyToken: 'PWD5900408020759752704' }, msg: null, type: 'verifyFinish' }
    // return {"flag":"F","code":"BLPS1204","data":null,"msg":"密码错误，请重新输入","type":"verifyFinishError"};
  },
  /**
   * 获取设备指纹信息，android需要检查imei权限，数据项较多
   * @param options {object} 入参
   * @param options.isMust Y 强制获取IMEI,权限拒绝时弹窗开启权限，回调 F，旧版本默认强制（android）
   * @param callback {function} 回调函数
   * */
  getDeviceFingerPrintParams (options, callback) {
    const data = { isMust: 'Y' }
    if (typeof options !== 'function') {
      _.extend(data, options)
    } else {
      callback = options
    }
    // eslint-disable-next-line standard/no-callback-literal
    callback({ flag: 'S', data: { verifyToken: 'PWD5900408020759752704' } })
  },
  async authorization () {
    await sleep(3000)
    return { flag: 'S', data: { authStatus: 'authorized' } }
  },
  async checkCalenderPermission () {
    await sleep(3000)
    return { flag: 'S', data: { authStatus: 'authorized' } }
  },
  async bankCardRecognition () {
    await sleep(2000)
    return { flag: 'S', data: { bankCardNumber: 12321312312312313123 } }
  },
  async openPermissionSet (data) {
    await sleep(1000)
    return { flag: 'S' }
  },
  // 添加联系人、获取通讯录
  async getContactsInfo (option) {
    await sleep(1000)
    return {
      flag: 'S',
      data: {
        contactsList: [
          'test1,15986815918',
          'test2,15889526031',
          'test3,13451102271',
          'test4,13760489039']
      }
    }
  },
  // 获取定位信息
  async getAddressInfo (option) {
    await sleep(1000)
    return {
      flag: 'S',
      data: {
        district: '福田区',
        city: '深圳市',
        country: '中国',
        longitude: '114.067445',
        latitude: '22.532338',
        coordtype: 'gcj02ll',
        addrInfo: '广东省深圳市福田区福华三路靠近京地大厦',
        altitude: '48.146439',
        province: '广东省'
      },
      msg: ''
    }
  },
  // 禁止原生可以拉动
  setPullAble (arg) {
  },
  compareVersion (version, fun) {
    fun(1)
  },
  async faceRecognition () {
    await sleep(2555)
    return {
      flag: 'S',
      msg: '',
      data: {
        jumpUrl: '/complement_live_address.html',
        image: '111111'
      }
    }
  },
  async authorizations () {
    await sleep(2555)
    return { flag: 'S', msg: '', data: { authStatus: 'authorized' } }
  },
  async calenderHandle () {
    await sleep(2555)
    return { flag: 'S', msg: '', data: { authStatus: 'authorized' } }
  },
  async getAppVersion () {
    await sleep(2555)
    return {
      flag: 'S',
      msg: '',
      data: {
        version: '1.12.0'
      }
    }
  },
  async getIDPhotos () {
    await sleep(2555)
    return {
      flag: 'S',
      msg: '',
      data: {
        photoData: ''
      }
    }
  },
  showCustomerTip (options) {
    console.log(options)
    const json = {
      data: typeof options === 'string' ? {
        message: options || '',
        time: 999
      } : {
        message: options.message || options.text || '',
        time: options.time || 999
      }
    }
    if (options.type && options.type === 'loading') {
      return Toast.loading({
        message: json.data.message || '加载中...',
        loadingType: 'spinner',
        forbidClick: true,
        duration: 0
      })
    }
    if (json.data.message === '') {
      return false
    }
    if (options.type && options.type === 'fail') {
      return Toast({
        type: 'fail',
        message: json.data.message,
        duration: json.data.time
      })
    }
    if (options.type && options.type === 'warning') {
      return Toast({
        type: 'text',
        message: json.data.message,
        duration: json.data.time
      })
    }
    Toast({
      type: 'success',
      ...json.data
    })
  },
  clearToast () {
    Toast.clear()
  },
  // 公共头部左边点击
  commonLeftClick () {
    if (Config.firstName === Config.pageName) {
      // 从登录页过来的
      if (Config.query.isBack === 'index') {
        this.back({ url: 'index.html' })
      } else {
        this.back()
      }
    } else {
      window.history.length > 1 ? this.router.go(-1) : this.back({ url: 'index.html' })
    }
  },
  // 本地存储 自动带上userNo
  localData: null
}
