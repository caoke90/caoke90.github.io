//环境变量
const getQueryObject = require('../utils/getQueryObject')
import localData from '../utils/localData';
const query = getQueryObject()
query.appChannel = query.appChannel || 'app'
query.serverEnv = query.serverEnv || 'PRD'
query.userNo = query.userNo || ''

const Config = {
  UrlNode: process.env.UrlNode,
  isApp: process.env.NODE_ENV!=='development' && query.appChannel !== 'dev',
  query: query,
  firstData: {},
  firstName: '',//第一次进入的页面
  prePageName: '',//上一个页面
  pageName: '',//当前进入页面的name
  introName:  'wlh_intro_v2',//介绍页
  indexName:  localData('indexName')||'wlh_index_v2',//首页
  userInfo: {},//用户信息
  morecardInfo: null, //一户多卡信息
}
export default Config

export const Msg = {
  loading: '加载中...',
  defaultErr: '服务器开小差了，请稍后重试～',
  geoLocation: '定位中...',
  verification: '正在为您拼命请求校验中...',
}

export const Bank = {
  '0001': {
    name: '中国银行',
    className: 'bk_0001'
  },
  '0002': {
    name: '农业银行',
    className: 'bk_0002'
  },

  '0003': {
    name: '工商银行',
    className: 'bk_0003'
  },
  '0004': {
    name: '建设银行',
    className: 'bk_0004'
  },
  '0005': {
    name: '交通银行',
    className: 'bk_0005'
  },
  '0006': {
    name: '光大银行',
    className: 'bk_0006'
  },
  '0007': {
    name: '民生银行',
    className: 'bk_0007'
  },
  '0008': {
    name: '平安银行',
    className: 'bk_0008'
  },
  '0009': {
    name: '邮储银行',
    className: 'bk_0009'
  },
  '0010': {
    name: '广发银行',
    className: 'bk_0010'
  },
  '0011': {
    name: '中信银行',
    className: 'bk_0011'
  },
  '0012': {
    name: '华夏银行',
    className: 'bk_0012'
  },
  '0013': {
    name: '浦发银行',
    className: 'bk_0013'
  },
  '0014': {
    name: '兴业银行',
    className: 'bk_0014'
  },

  '0015': {
    name: '招商银行',
    className: 'bk_0015'
  },
  '0016': {
    name: '浙商银行',
    className: 'bk_0016'
  },
  '0017': {
    name: '杭州银行',
    className: 'bk_0017'
  },
  '0018': {
    name: '上海银行',
    className: 'bk_0018'
  },
  '0019': {
    name: '北京银行',
    className: 'bk_0019'
  }
}

