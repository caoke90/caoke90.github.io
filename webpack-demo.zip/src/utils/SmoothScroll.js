/**
 * 平滑滚动工具类
 * 构造函数参数：
 * @param  {string | HTMLElement} selector
 * @param  {object} option
 * @param  {number} option.duration
 * @param  {'easeInCubic'|'easeOutCubic'|'easeInOutCubic'} option.easing
 * 该工具主要依赖requestAnimationFrame API完成每一帧滚动的位置计算
 */
export default class SmoothScroll {
  scrollElement = document.body

  option = {
    // 滚动完成时间，单位ms
    duration: 300,
    // 滚动动画函数类型
    easing: 'easeOutCubic'
  }

  /**
   * @param  {string | HTMLElement} selector 滚动容器选择器或dom对象，可选，默认body对象
   * @param  {object} option                 平滑滚动参数，可选
   * @param  {number} option.duration        平滑滚动完成时间
   * @param  {'easeInCubic'|'easeOutCubic'|'easeInOutCubic'} option.easing 平滑滚动曲线函数
   */
  constructor (selector, option) {
    if (selector) {
      this.scrollElement = typeof selector === 'object' ? selector : document.querySelector(selector)
    }

    this.option = Object.assign({}, this.option, option)
  }

  /**
   * Tween 动画函数
   * t: current time（当前时间）
   * b: beginning value（初始值）
   * c: change in value（变化量）
   * d: duration（持续时间）
   */
  Tween = {
    easeInCubic: function (t, b, c, d) {
      return c * (t /= d) * t * t + b
    },
    easeOutCubic: function (t, b, c, d) {
      return c * ((t = t / d - 1) * t * t + 1) + b
    },
    easeInOutCubic: function (t, b, c, d) {
      if ((t /= d / 2) < 1) return c / 2 * t * t * t + b
      return c / 2 * ((t -= 2) * t * t + 2) + b
    }
  }

  scrollTo (x, y) {
    let start = 0
    const { duration: durationTime, easing } = this.option
    const duration = durationTime / 10
    const scrollerContainer = this.scrollElement
    const startTop = scrollerContainer.scrollTop
    const startLeft = scrollerContainer.scrollLeft
    const endTop = y - startTop
    const endLeft = x - startLeft
    const run = () => {
      start++
      const top = this.Tween[easing](start, startTop, endTop, duration)
      const left = this.Tween[easing](start, startLeft, endLeft, duration)
      scrollerContainer.scrollTop = top
      scrollerContainer.scrollLeft = left
      if (start < duration) window.requestAnimationFrame(run)
    }
    run()
  }
}
