module.exports=function getQueryString(paramObj) {
  let paramStr;
  for(let k in paramObj){
    if(paramStr){
      paramStr=paramStr+'&'+k+'='+paramObj[k]
    }else{
      paramStr=k+'='+paramObj[k]
    }
  }
  return paramStr;
}
