const sleep=require('./sleep')
export async function scrollToTop (ele,end,num,limit) {
  let start=ele.scrollTop
  if(end>start){
    if(limit>0&&num*limit<end-start){
      num=parseInt((end-start)/limit)
    }
    while (end>start){
      start+=num;
      await sleep(0)
      ele.scrollTop=start;
    }
  }else{
    if(limit>0&&num*limit<start-end){
      num=parseInt((start-end)/limit)
    }
    while (end<start){
      start-=num;
      await sleep(0)
      ele.scrollTop=start;
    }
  }
  ele.scrollTop=end;
}