export default class StateCache {
  /**
   * 缓存vue data数据，可以解决数据初始化导致的文字抖动问题
   * @param  {string} stateKey 缓存数据的key，保持唯一性原则
   */
  constructor (stateKey) {
    this.globalState = {}
    this.stateKey = stateKey
  }

  /**
   * 映射State
   * @param  {any} value 需要缓存的数据，该值直接用作data的返回值
   */
  mapState (value) {
    const state = this.globalState[this.stateKey]
    if (state) {
      return state
    }

    this.globalState[this.stateKey] = value
    return value
  }

  /**
   * 删除映射State
   * @param  {string} stateKey 需要删除缓存对应的key
   */
  delState (stateKey) {
    this.globalState[stateKey] = undefined
  }
}
