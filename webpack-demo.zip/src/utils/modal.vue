<template>
  <div :key="mkey">
    <component v-for="name in modalMap[mkey]" :ref="name" :is="mkey+'-'+name" :key="name"></component>
  </div>
</template>
<script>
  import Vue from 'vue'
  import BModal from 'BModal';

  /*
    增加服务的接口
  * */
  BModal.modalMap={
    header:[],
    footer:[]
  };
  BModal.addModalComponent = function (model,mkey) {
    if(!BModal.modalMap[mkey]){BModal.modalMap[mkey]=[]}

    if (BModal.modalMap[mkey].indexOf(model.name) === -1) {
      BModal.modalMap[mkey].push(model.name);
      Vue.component(mkey+"-" + model.name, model);
    }
  }

  export default {
    name: 'modal',
    data: function () {
      if(!BModal.modalMap[this.mkey]){
        BModal.modalMap[this.mkey]=[]
      }
      return {
        "modalMap": BModal.modalMap
      }
    },

    props: ['mkey'],
    mounted(){
      BModal[this.mkey+'Refs']=this.$refs
    },
  };
</script>
