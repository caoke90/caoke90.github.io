/*
缓存加载函数
cacheLen：最多缓存多少个接口
id：唯一值
name：方法名
syncFunc：加载函数
 */
// 缓存最近的20个接口
import localData from './localData'
import _ from 'lodash'
const methodCacheArr = []
export function initCache () {
  const arr=localData('queryStore');
  if(_.isArray(arr)){
    arr.forEach(function (item) {
      methodCacheArr.push(item)
    })
  }
}

function getCacheIndex (val, key,useCache) {
  let has = -1
  for (let i = methodCacheArr.length - 1; i >= 0; i--) {
    if (val === methodCacheArr[i][key]) {
      if (useCache) {
        if(useCache * 1000 + methodCacheArr[i].time > +new Date()){
          has = i
        }
      }else{
        has = i
      }
      break
    }
  }
  return has
}

export function getCache (name,useCache) {
  const has = getCacheIndex(name, 'name',useCache)
  if (has > -1) {
    return methodCacheArr[has].res
  } else {
    return null
  }
}
export function getCacheData (name,useCache) {
  const has = getCacheIndex(name, 'name',useCache)
  if (has > -1) {
    return methodCacheArr[has].res.data
  } else {
    return null
  }
}
export function delCache (name) {
  let has = getCacheIndex(name, 'name')
  while (has > -1) {
    let store=methodCacheArr[has].store;
    methodCacheArr.splice(has, 1)
    if(store){
      updateCache()
    }
    has = getCacheIndex(name, 'name')
  }
}
export function updateCache () {
  const arr=methodCacheArr.filter(function (item) {
    //只缓存60天
    if(item.store&&5184000000+item.time > +new Date()){
      return true
    }
    return false;
  })
  if(arr.length>10){
    arr.splice(0,1)
  }
  localData('queryStore',arr)
}
export async function limitCache ({id, name, useCache,store,queryNoError}, syncFunc) {
  let has=-1;
  if (useCache) {
    if(typeof useCache !== 'number'){
      useCache = 300;
    }
    has = getCacheIndex(id, 'id',useCache)
  }
  if(has>-1){
    return methodCacheArr[has].res
  }
  let res = await syncFunc()
  //更新缓存
  if (res && res.flag === 'S') {
    if (has > -1) {
      methodCacheArr.splice(has, 1)
    }
    methodCacheArr.push({
      id: id,
      store:store,
      name: name,
      time: +new Date(),
      res: res
    })
    if (methodCacheArr.length > 100) {
      methodCacheArr.splice(0, 1)
    }
    if(store){
      updateCache()
    }
  }else if(has > -1&&queryNoError){
    //兼容查询失败的情况
    return methodCacheArr[has].res;
  }
  return res
}
