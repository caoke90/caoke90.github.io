import _ from 'lodash';

/**
 * 小数，最小位数
 * @param val 值
 * @param digit 小数位数
 * @returns {number}
 */
export default function round(val, digit= 2){
  val = _.isNaN(val) ? 0 : val;
  const pow= Math.pow(10, digit);
  val = Math.round(val * pow);
  val /= pow;
  return val;
}
