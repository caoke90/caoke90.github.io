/*
 * @Author: your name
 * @Date: 2021-05-26 17:53:54
 * @LastEditTime: 2021-05-26 18:11:33
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \360jr-wlh\src\utils\bus.js
 */
import Vue from 'vue'
const Bus = new Vue({})
export default Bus
