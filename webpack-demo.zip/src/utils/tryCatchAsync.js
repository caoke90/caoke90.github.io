import Native from 'native';
/**
 * @function tryCatchCall
 * @name promise回传包裹
 * @return [Data, error]
 */
export default async function (options) {
  console.log(options);
  let resData = [null, null];
  try {
    resData[0] = await Native.ajax(options);
    if (resData[0].flag !== 'S') {
      throw resData[0];
    }
  } catch (e) {
    resData[1] = {
      msg: e.message || e.msg,
      data: e.data || ''
    };
  }
  return resData;
}
