export const statusMap = {
  MNO: '未开通',
  MNS: '未设置分期',
  MNBC: '未绑卡',
  MNDZ: '未动支',
  MDZ: '已动支'
}
