class Storage {
  constructor (storageType) {
    this.storageType = storageType
    this.storage = window[this.storageType] || {}
  }

  /**
   * 本地缓存
   * @param  {string | number} key 缓存的唯一key值
   * @param  {any} value 需要缓存的内容
   */
  data (key, value) {
    // 如果没有传value，意味着是取值
    if (value === undefined) {
      const result = this.storage[key]
      try {
        return JSON.parse(result)
      } catch (error) {
        return result
      }
    }

    this.storage[key] = typeof value === 'object' ? JSON.stringify(value) : value
  }

  /**
   * @param  {string | number} 需要删除的唯一key值
   */
  remove (key) {
    try {
      this.storage.removeItem(key)
    } catch (error) {
      delete this.storage[key]
    }
  }

  /**
   * 删除缓存所有内容
   */
  clear () {
    try {
      this.storage.clear()
    } catch (error) {
      this.storage = {}
    }
  }
}

const local = new Storage('localStorage')
const session = new Storage('sessionStorage')

export { local, session }
