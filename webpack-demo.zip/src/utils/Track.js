import Native from 'native'

export class Track {
  constructor (type = 'bizData') {
    this.type = type
  }

  report (eventCode, props) {
    if (!eventCode) return
    try {
      const data = { eventCode }
      if (props) {
        data[this.type] = props
      }
      Native.reportUbas(data)
    } catch (err) {
      console.log(err)
    }
  }
}

export default new Track()
