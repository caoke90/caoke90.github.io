import Native from 'native';
import Api from '@/common/api'
import { Dialog } from 'vant';
import Flag from '@/constant/flag';
import _ from 'lodash';

const C = {
  Constant: {
        // H5轻授信
    // 开启相机权限
    PERMISSION: {
      CONFIRM_BTN: '去开启',
      CANCEL_BTN: '取消',
      CONTACT_TITLE: '请开启通讯录权限',
      CONTACT_MESSAGE: '请允许我们在借款授信等业务场景中获取通讯录信息，以便落实反欺诈风险，防止您的贷款资金被不法分子获取，同时为准确评估您的信贷资格等。<br>我们仅单次获取，您可以进入“我的”-“设置”-“权限管理”中管理该权限。',
      CAPTURE_TITLE: '请开启相机权限',
      CAPTURE_MESSAGE: '为了确保您能顺利完成人脸识别、身份证件识别等操作，请进入系统设置开启相机权限'
    }
  }
};

const AuthStatus = {
  Authorized: 'authorized',
  Denied: 'denied'
};

class OCR {
  constructor () {
    this.partCode = {
      FACEAA: 'FACEAA', // face++
      SENSETIME: 'SENSETIME' // 新版商汤
    }
    this.type = {
      front: 'f',
      back: 'b'
    }
    this.isIOS = Native.IS_IOS
    this.defaultPart = this.partCode.FACEAA
    this.fileKeys = []
  }
  /**
   * 调用OCR
   * @param type {string} f|b
   * @param partCode {string} SDK code 默认defaultPart
   * @return Promise
   * */
  invoke (type, partCode) {
    const obj = {
      flag: Flag.FAIL, // 状态
      failStep: '', // 失败节点
      authInfo: {}, // 权限检查信息
      ocrInfo: {}, // ocr执行信息
      uploadInfo: {}, // 文件上传信息
      queryInfo: {}, // ocr解析信息
      operationTime: '' // 识别操作时间
    }
    let startTime = null;
    let endTime = null;
    return new Promise((resolve, reject) => {
      Native.showCustomerTip({type: 'loading'})
      startTime = new Date().getTime() // 开始识别时间
      /* if (process.env.NODE_ENV === 'development') {
        const isFront = type === this.type.front // 是否正面识别
        queryOCRParse({
          assayType: partCode,
          ocrMode: isFront ? '1' : '2',
          ocrImage: isFront ? 'GFSe0c134bca48e4c57aa54c9867a03aaad' : 'GFS2c10e905ba41482884793f9497064ca3',
          mugShot: ''
        }).then(res => {
          console.log(res)
          obj.flag = Flag.SUCCESS
          obj.queryInfo = res
          Native.clearToast()
          return resolve(obj)
        }, err => {
          obj.failStep = 'query'
          obj.queryInfo = err
          Native.clearToast()
          return reject(obj)
        })
        return
      } */
      this.checkAuthorization().then(() => {
        return this.invokeOcr(type, partCode || this.defaultPart)
      }, err => {
        obj.failStep = 'auth'
        obj.authInfo = err
        obj.operationTime = ''
        Native.clearToast()
        return reject(obj)
      }).then(res => {
        obj.ocrInfo = res
        endTime = new Date().getTime()
        return this.uploadOCRFile(res.data.fileMap)
      }, err => {
        obj.failStep = 'ocr'
        obj.ocrInfo = err
        obj.operationTime = endTime - startTime
        Native.clearToast()
        return reject(obj)
      }).then(res => {
        const success = res.flag && res.flag === Flag.SUCCESS;
        if (!success) throw res;
        const fileNameCodes = res.data.fileNameCodes;
        const ocrInfo = obj.ocrInfo.data;
        obj.uploadInfo = res;
        Native.clearToast();
        if (success) {
          const noFileCode = _.some(this.fileKeys, (item) => {
            return !fileNameCodes[item];
          })
          if (noFileCode) {
            obj.failStep = 'upload';
            obj.operationTime = endTime - startTime;
            return reject(obj)
          } else {
            const isFront = type === this.type.front; // 是否正面识别
            const options = {
              ocrType: '1',
              ocrMode: isFront ? '1' : '2',
              ocrImage: isFront ? fileNameCodes.idCardImg : fileNameCodes.idCardBackImg,
              mugShot: isFront && fileNameCodes.portraitImg ? fileNameCodes.portraitImg : '',
              facePartner: partCode,
              // 商汤sdk字段增加
              ocrInfo: partCode === 'LINKFACE' ? JSON.stringify(ocrInfo.scanResult) : ''
            }
            return this.ocrQuery(options)
          }
        } else {
          obj.failStep = 'upload'
          obj.operationTime = endTime - startTime;
          return reject(obj)
        }
      }, err => {
        obj.failStep = 'upload';
        obj.uploadInfo = err;
        obj.operationTime = endTime - startTime;
        Native.clearToast();
        return reject(obj);
      }).then(res => {
        obj.flag = Flag.SUCCESS
        obj.queryInfo = res
        obj.operationTime = endTime - startTime
        Native.clearToast()
        return resolve(obj)
      }, err => {
        obj.failStep = 'query'
        obj.queryInfo = err
        obj.operationTime = endTime - startTime
        Native.clearToast()
        return reject(obj)
      })
    })
  }
  invokeOcr (type, partCode) {
    return new Promise((resolve, reject) => {
      Native.getIDPhotos({
        type: type,
        sdkType: partCode
      }, res => {
        if (res && res.flag === Flag.SUCCESS) {
          let data = res.data
          let fileMap = []
          // 进行数据加工
          if (type === this.type.front) {
            data.idcardImgID && fileMap.push({
              fileKey: 'idCardImg',
              fileId: data.idcardImgID
            })
            data.portraitImgID && fileMap.push({
              fileKey: 'portraitImg',
              fileId: data.portraitImgID
            })
          } else {
            data.idcardImgID && fileMap.push({
              fileKey: 'idCardBackImg',
              fileId: data.idcardImgID
            })
          }
          let img = data.idcardImg
          data.img = ['data:image/jpeg;base64,', img.replace(/\r\n/g, '').replace('\\/', '/')].join('')
          data.type = type
          data._sdkType = partCode
          data.fileMap = fileMap
          resolve(res)
        } else {
          reject(res)
        }
      })
    })
  }
  checkAuthorization () {
    return new Promise((resolve, reject) => {
      if (this.isIOS) {
        Native.authorizations({
          authType: 'capture',
          callback: res => {
            if (res && res.flag === Flag.SUCCESS) {
              const data = res.data
              const authStatus = data.authStatus
              if (authStatus === AuthStatus.Authorized) {
                return resolve()
              } else if (authStatus === AuthStatus.Denied) {
                this.permissionDialogCapture()
              }
              // eslint-disabled-next-line
              return reject(res)
            } else {
              res.msg && Native.tip(res.msg)
              // eslint-disabled-next-line
              reject(res)
            }
          }
        })
      } else {
        resolve()
      }
    })
  }
  permissionDialogCapture () {
    Dialog.alert({
      title: C.Constant.PERMISSION.CAPTURE_TITLE,
      message: C.Constant.PERMISSION.CAPTURE_MESSAGE,
      okText: C.Constant.PERMISSION.CONFIRM_BTN,
    }).then(() => {
      if (Native.IS_IOS) {
        Native.openURLS('prefs:root=Privacy&path=CAMERA')
      } else {
        Native.openPermissionSet()
      }
    })
  }
  /**
   * OCR照片上传
   * @param fileMapList {array} 文件map，每一项为一个fileKey和fileId组成的map
   * @return Promise
   * */
  uploadOCRFile (fileMapList = []) {
    return new Promise((resolve, reject) => {
      const fileKeys = []
      _.each(fileMapList, item => {
        fileKeys.push(item.fileKey)
      })
      console.log('fileKeys ', fileKeys)
      this.fileKeys = fileKeys
      console.log('this.fileKeys ', this.fileKeys)
      this.uploadFileMulti({
        bizType: 'OCR',
        fileSuffix: 'jpg',
        fileKeys
      }, fileMapList)
      .then(res => resolve(res))
      .catch(err => reject(err))
    })
  }
  /**
   * 通用多文件上传接口
   * @param bizContent {object|jsonString} 上传附带的业务信息
   * @param autermostParams {object} 最外围的参数 用于调用native接口上传时，直接使用fileId由native进行加工使用
   * @return Promise
   * */
  uploadFileMulti (bizContent, fileMapList) {
    return Native.ajax({
      url: Api('LPS'),
      data: {
        method: Api('COMMON_MULTI_FILE_UPLOAD'),
        bizContent: JSON.stringify(bizContent)
      },
      fileMap: fileMapList
    })
  }
  ocrQuery (bizContent) {
    return Native.ajax({
      url: Api('LPS'),
      data: {
        method: Api('USER_OCRINFO_QUERY'),
        bizContent: JSON.stringify(bizContent)
      }
    })
  }
}
let mInstance
const getInstance = () => {
  if (!mInstance) {
    mInstance = new OCR()
  }
  return mInstance
}
export default getInstance()