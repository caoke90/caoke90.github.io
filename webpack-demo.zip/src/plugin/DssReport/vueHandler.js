import Vue from 'vue'

export default function vueErrorHandler (callback) {
  Vue.config.errorHandler = function (err, vm, info) {
    const { message, stack } = err

    // Processing error
    let resourceUrl, col, line
    let errs = stack.match(/\(.+?\)/)
    if (errs && errs.length) errs = errs[0]
    errs = errs.replace(/\w.+js/g, $1 => { resourceUrl = $1; return '' })
    errs = errs.split(':')
    if (errs && errs.length > 1) {
      line = parseInt(errs[1] || 0)
      col = parseInt(errs[2] || 0)
    }

    const componentName = vm.$options.name
    const resourceName = componentName ? `[${componentName}]` : ''

    // Fixed parameters
    // Call the Performance.addError method
    // eslint-disable-next-line standard/no-callback-literal
    callback({
      msg: message,
      msgText: stack,
      col: col,
      line: line,
      resourceUrl: resourceUrl + resourceName
    })

    console.error(err)
  }
}
