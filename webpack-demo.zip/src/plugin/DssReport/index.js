import DssReport from './DssReport'
import vueErrorHandler from './vueHandler'

const isDev = process.env.NODE_ENV === 'development'
// 取buildEnv用于区分测试环境与生产环境
const isProd = process.env.NODE_ENV === 'production' && process.env.buildEnv !== 'test'

export { DssReport, vueErrorHandler }
export default new DssReport({
  appId: isProd ? 'pW6MN3B1610526891041' : 'eawZkRm1610528555588',
  domain: isProd ? 'https://dss.daikuan.360.cn/dss-data/api/v1/report/web' : 'http://123.125.52.115/dss-data/api/v1/report/web',
  isDev
})
