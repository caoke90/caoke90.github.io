/**
 * DSS 前端监控
 * 目前上报了
 * 1.页面级首次进来性能
 * 2.页面内错误信息
 * 3.接口统计信息
*/
import Config from '@/common/Config'

export default class DssReport {
  /**
   * @param {object} option
   * @param {string} option.appId
   * @param {string} option.domain
   * @param {boolean} option.isDev
   */
  constructor (option) {
    this.appId = option.appId
    this.domain = option.domain
    this.isDev = option.isDev
    this.errorList = []
    this.resourceList = []
  }

  /**
   * performance这个全局对象，打点时间
   * @returns {{}}
   */
  getPerformanceMsg () {
    let result = {}
    if (window.performance) {
      const { timing } = window.performance
      const lodt = timing.loadEventEnd - timing.navigationStart
      result = {
        // DNS解析时间
        dnst: timing.domainLookupEnd - timing.domainLookupStart || 0,
        // TCP建立时间
        tcpt: timing.connectEnd - timing.connectStart || 0,
        // 白屏时间
        wit: timing.responseStart - timing.navigationStart || 0,
        // dom渲染完成时间
        domt: timing.domContentLoadedEventEnd - timing.navigationStart || 0,
        // 页面onload时间
        lodt: lodt > 0 ? lodt : 1,
        // 页面准备时间
        radt: timing.fetchStart - timing.navigationStart || 0,
        // 页面重定向时间
        rdit: timing.redirectEnd - timing.redirectStart || 0,
        // unload时间
        uodt: timing.unloadEventEnd - timing.unloadEventStart || 0,
        // request请求耗时
        reqt: timing.responseEnd - timing.requestStart || 0,
        // 页面解析dom耗时
        andt: timing.domComplete - timing.domInteractive || 0
      }
    }
    return result
  }

  /**
   * 生产url
   * @returns {string}
   */
  createUrl () {
    const { href, hash } = window.location
    const end = href.indexOf('?')
    const url = href.substring(0, end > 0 ? end : undefined)
    return `${url}${hash ? '#' + hash : ''}`
  }

  /**
   * 生成上报的数据
   * @param type 1:页面级首次进来性能上报  2:页面ajax性能上报  3：页面内错误信息上报,
   */
  createReportData (type = 1) {
    const userId = Config.userInfo && Config.userInfo.userNo
    const result = {
      time: Date.now(),
      markUser: userId, // pv标识
      markUv: userId, // uv标识
      type,
      errorList: this.errorList,
      resourceList: this.resourceList,
      appId: this.appId,
      url: this.createUrl(),
      preUrl: '',
      screenwidth: document.documentElement.clientWidth || document.body.clientWidth,
      screenheight: document.documentElement.clientHeight || document.body.clientHeight
    }

    switch (type) {
      case 1: {
        // 页面级首次进来性能上报
        result.performance = this.getPerformanceMsg()
        result.isFristIn = true
        break
      }
      case 2:
      case 3: {
        // 页面内错误信息上报
        result.performance = {}
        result.isFristIn = false
        break
      }
    }

    return result
  }

  /**
   * 上传到dss
   * @param postData
   */
  reportToDss (postData) {
    if (this.isDev) return false // 本地开发环境不上报

    if (window.fetch) {
      window.fetch(this.domain, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        type: 'report-data',
        body: JSON.stringify(postData)
      })
    } else {
      const xhr = new window.XMLHttpRequest()
      xhr.open('POST', this.domain)
      xhr.setRequestHeader('Content-Type', 'application/json')
      xhr.send(JSON.stringify(postData))
    }
  }

  /**
   * 上报页面级首次进来性能
   */
  reportFirstPage (page) {
    // console.log('load-before')
    window.addEventListener('load', () => {
      // console.log('load-after')
      if (window.performance) {
        const postData = this.createReportData(1)
        this.reportToDss(postData)
      }
    })
  }

  /**
   * 往errorList，增加错误的信息
   * @param {object} item
   * @param {string} item.msg 错误信息
   * @param {string} item.resourceUrl 错误路径
   * @param {string} item.msgText 错误内容
   * @param {string} item.line 错误行
   * @param {string} item.col 错误列
   */
  addError (item) {
    this.errorList.push({
      t: Date.now(),
      n: 'js',
      msg: item.msg || item.message,
      data: {
        resourceUrl: item.resourceUrl,
        text: item.msgText,
        line: item.line,
        col: item.col,
        status: 0
      }
    })
  }

  /**
   * 发送错误的列表
   * @param page
   */
  reportErrorList (page = window.location.href) {
    const postData = this.createReportData(3, this.errorList)
    this.reportToDss(postData)
    this.errorList = []
  }
}
