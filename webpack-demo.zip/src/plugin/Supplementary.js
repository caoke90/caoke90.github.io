import _ from 'lodash';
import Flag from '@/constant/flag';
import Router from '@/router/index';
import Api from '@/common/api';
import Config from './../common/Config';
import Native from 'native';
//设置合同Popup
import BModal from 'BModal';
import contractPopup from '@/componets/modal/contractPopup.vue';
import { Dialog, Toast } from 'vant';
import CreditRequest from './../common/CreditRequest'




let $UserInfo = null;
let $LastStepInfo = null;
let AppList = null; // app列表
let Contacts = null; // 联系人
let CallLogInfo = null; // 通话记录
let DeviceInfo = null; // 设备信息
let GeoInfo = null; // 定位信息
const FINISH_PAGE = Api('wlh_audit_setpart');

const Utils = {
  Constant: {
    APPLY_PROGRESS_WLH: {
      BIND_CARD_NO: 'APPL_BIND_CARD_NO_WLH',
      BIND_CARD_NAME: 'APPL_BIND_CARD_NAME_WLH',
      BIND_CARD_MOBILE: 'APPL_BIND_CARD_MOBILE_WLH',
      BIND_CARD_CDKEY: 'APPL_BIND_CARD_CDKEY_H5',
      BIND_CARD_CERT_NO: 'APPL_BIND_CARD_CERT_NO_WLH',
      BIND_CARD_SMS_CHANNEL: 'APPL_BIND_CARD_SMS_CHANNEL_WLH',
      BIND_CARD_SMS_TIME: 'APPL_BIND_CARD_SMS_TIME_WLH',
      BIND_CARD_FILE_NAME: 'APPL_BIND_CARD_FILE_NAME_WLH',
      LAST_STEP_DATA: 'APPL_LAST_STEP_DATA_WLH',
      ALL_STEP_DATA: 'APPL_ALL_STEP_DATA_WLH'
    },
    PERMISSION: {
      CONFIRM_BTN: '去开启',
      CANCEL_BTN: '取消',

      CONTACT_TITLE: '请开启通讯录权限',
      CONTACT_MESSAGE: '请允许我们在借款授信等业务场景中获取通讯录信息，以便落实反欺诈风险，防止您的贷款资金被不法分子获取，同时为准确评估您的信贷资格等。<br>我们仅单次获取，您可以进入“我的”-“设置”-“权限管理”中管理该权限。',

      CAPTURE_TITLE: '请开启相机权限',
      CAPTURE_MESSAGE: '为了确保您能顺利完成人脸识别、身份证件识别等操作，请进入系统设置开启相机权限'
    },
    USER_LOGIN_INFO: 'USER_LOGIN_INFO',
    TITLE: {
      CARS_MANAGE: '银行卡管理',
      BIND_CARD: '收款银行卡',
    },
    CONTACT_CHOOSE_OPEN_TEST: ['4', '8'],
    CONTACT_CHOOSE_OPEN_TEST_2: ['3'],
    // 优选时候是否上传用户通讯录数据
    IS_CONTACT_CHOOSE_TYPE_UPLOAD: 'Y',
    // 调用native选择联系人的类型入参
    CONTACT_CHOOSE_TYPE: 'optimum',
    CONTACT_CHOOSE_TYPE_2: 'optimumModel',
    // A 为提交时通话记录，通讯录免爬取
    CRAWL_INFO_SWITCH: '',
    // 关系
    RELATIONSHIP: {
      URGENT_RELATION: [{
        value: 'FRIEND',
        name: '朋友'
      }, {
        value: 'COLLEAGUE',
        name: '同事'
      }, {
        value: 'FAMILY',
        name: '家人'
      }],
      // 紧急联系人
      EMERGENCY_CONTACTS: [{
        value: 'FAMILY',
        name: '家人'
      }, {
        value: 'FRIEND',
        name: '朋友'
      }, {
        value: 'COLLEAGUE',
        name: '同事'
      }, {
        value: 'OTHER',
        name: '其他'
      }],
      // 其他联系人
      OTHER_CONTACTS: [{
        value: 'FRIEND',
        name: '朋友'
      }, {
        value: 'COLLEAGUE',
        name: '同事'
      }, {
        value: 'OTHER',
        name: '其他'
      }],
      // 其他联系人2
      OTHER_CONTACTS2: [{
        value: 'FAMILY',
        name: '家人'
      }, {
        value: 'FRIEND',
        name: '朋友'
      }, {
        value: 'COLLEAGUE',
        name: '同事'
      }, {
        value: 'OTHER',
        name: '其他'
      }],
      DIRECT_RELATION: [{
        value: 'PARENT',
        name: '父母'
      }, {
        value: 'MATE',
        name: '配偶'
      }, {
        value: 'CHILD',
        name: '子女'
      }],
      NORMAL_RELATION: [{
        value: 'COLLEAGUE',
        name: '同事'
      }, {
        value: 'CLASSMATE',
        name: '同学'
      }, {
        value: 'FRIEND',
        name: '朋友'
      }, {
        value: 'OTHER',
        name: '其他'
      }],
      RELATION_TYPE: {
        OTHER: '其他联系人',
        DIRECT: '直系联系人'
      },
      RELATION_TYPE_CODE: {
        OTHER: 'OTHER',
        DIRECT: 'DIRECT',
        URGENT: 'URGENT'
      }
    },
    GEO_LOCATION: {
      // 错误语句提示
      ERROR_MSG: {
        // 获取地理位置信息错误
        GETLOCATION_ERROR: '定位信息获取失败！为了保障您的账户安全，请您检查设备定位服务是否已打开，并确保已安装SIM卡并开启移动网络、打开WIFI和蓝牙开关',
        // 获取设备指纹信息超时  getDeviceFingerPrintParams
        GETDEVICEFINGERPRINTPARAMS_ERROR: '您的网络不通畅，请检查您的网络或重试！(A1)'
      }
    },
    MSG: {
      COMMON: {
        GPS_FAIL: '定位信息获取失败！为了保障您的账户安全，请您检查设备定位服务是否已打开，并确保已安装SIM卡并开启移动网络、打开WIFI和蓝牙开关',
        GPS_TIMEOUT: '定位信息获取超时',
        YUAN: '元',
        GOT_IT: '知道了',
        PLS_CHOOSE: '请选择',
        NO_INCOME: '暂无收入',

        VERSION_NO_SUPPORT: '当前版本不支持，请升级后再试',

        GO_FINISH: '去完成',

        CONTACTS_AUTH: '请允许我们在借款授信等业务场景中获取通讯录信息，以便落实反欺诈风险，防止您的贷款资金被不法分子获取，同时为准确评估您的信贷资格等。<br>我们仅单次获取，您可以进入“我的”-“设置”-“权限管理”中管理该权限。',
        CONTACTS_AUTH_IOS: '请允许我们在借款授信等业务场景中获取通讯录信息，以便落实反欺诈风险，防止您的贷款资金被不法分子获取，同时为准确评估您的信贷资格等。<br>我们仅单次获取，您可以进入“我的”-“设置”-“权限管理”中管理该权限。',
        CALENDAR_AUTH: '小主儿，为了方便我们及时通知您活动提醒等消息，需要您允许我们获取日历权限。',

        PHONE_VERIFY_TIP: '确定后您的注册手机号将收到电话并播报验证码，请准备记录',
        // capture
        SHOP_ORDER_CAPTURE: '为了确保您能顺利完成人脸识别、身份证件识别等操作，请进入系统设置开启相机权限',
        DEFAULTS_ERROR: '系统繁忙，请稍后再试！',
        ACT_DEFAULTS_ERROR: '活动太火爆了，请稍后再试！'
      }
    }
  },
  RegexMap: {
    // 身份证
    idCard: /^\d{15}$|^\d{18}$|^\d{17}(\d|X|x)$/,
    // 手机号码
    MobileNo: /^1((3[0-9])|(4[57])|(5[012356789])|(7[0135678])|(8[0-9])|(66)|(9[189]))\d{8}$/, // /^1[34587]\d{9}$/,166、198、199
    // 屏蔽17开头的
    LoginMobileNo: /^1((3[0-9])|(4[57])|(5[012356789])|(8[0-9])|(66)|(9[189]))\d{8}$/, // /^1[34587]\d{9}$/,166、198、199
    // 银行卡号（大于或等于16位的数字）
    CardNo: /^\d{16,19}$/,
    // 短验证码（6位数字以上）
    MobileCode: /^\d{6,}$/,
    // 交易密码(6-16位数字或字母)
    OrderPassword: /^\S{6,16}$/,
    // 千分位正则
    parseThousands: /(\d{1,3})(?=(\d{3})+(?:$|\.))/g,
    // 每4位字符用空格隔开
    bankCardNo: /(\d{4})(?=\d)/g,
    // 卡号屏蔽
    parseToStarNumber: /^(\d{4})(\d+)(\d{4})$/,
    // 后四位屏蔽
    parseRightFourStar: /^(\w+)(\w{4})$/,
    // 手机号码中间四位屏蔽
    parseMiddleFourStar: /^(\d{3})(\d{4})(\d{4})$/,
    // 日期格式检测
    parseDateFormat: /\b(\d{4})\b[^\d]+(\d{1,2})\b[^\d]+(\d{1,2})\b(\s(\d{1,2})\:(\d{1,2})\:(\d{1,2}))?[^\d]?/,
    // 出生日期掩码，显示格式（"19**年**月*2日")
    userBirthdayStarRegex: /(\d{2})\d{2}([^\d]+)\d+([^\d]+)\d?(\d)([^\d]+)?/,
    // 金额转换
    moneyReplace: /[^0-9\.]/g,
    // POS机编号
    posNumberREG: /^[0123456789]\d{14}$/,
    // 服务端异常code
    serverCode: /^S/,
    // 登录密码
    loginPw: /^[0-9a-zA-Z]{6,18}$/,
    // 中文姓名
    chineseName: /^[\u4e00-\u9fa5|\u3400-\u4db5]{1,}\·{0,1}[\u4e00-\u9fa5|\u3400-\u4db5]{1,}$/,
    // 授信流程-联系人-中文姓名
    newChineseName: /^[\u4e00-\u9fa5|\u3400-\u4db5]{1,}[·•]{0,1}[\u4e00-\u9fa5|\u3400-\u4db5]{1,}$/,
    // 授信流程-联系人-优选
    newChineseName2: /^[\u4e00-\u9fa5|\u3400-\u4db5|\·\•|a-z|A-Z]{1,20}$/,
    // 签发机关
    chineseAgency: /^[\u4e00-\u9fa5|\·]{1,30}$/,
    // 邀请码规则
    cord: /^[0-9a-zA-Z]{4,15}$/,
    // 公积金,社保认证，密码和公积金账号4-20位
    creditCommonInput: /^\S{4,20}$/,
    // 公积金,社保认证,验证码3到8位
    creditVerifyCode: /^[0-9a-zA-Z]{3,8}$/,
    // 匹配emoji
    emoji: /[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/i,
    normalString: /^[\u4e00-\u9fa5\u3400-\u4db5a-zA-Z0-9]+$/,
    // 公司名称，只允许输入中文、空格、数字、字母、括号、点
    companyName: /^[\u4e00-\u9fa5\u3400-\u4db5a-zA-Z0-9\s\.\(\)\（\）]+$/
  },
  /**
   * 获取填写身份证相关的信息
   * @ param str 截取的出生日期字符串 或 身份证号
   * @ param type 传入第二个值是证明需返回的是string，否则是boolean
   * 检测身份证中的日期是否有效
   *
   */
  strDateTime (str, type) {
    var type = type || true
    // 如果传入的是身份证号时，从第6位开始截取8个字符
    if (str.length == 18) {
      str = str.substr(6, 8)
    }
    var r = str.match(/^(\d{1,4})(-|\/)?(\d{1,2})\2(\d{1,2})$/)
    if (r == null) return false
    var d = new Date(r[1], r[3] - 1, r[4])
    var now = new Date()
    var minDate = new Date('1900-01-01')

    var maxDate = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    // 如果不符合最大当前日期，最小1900年1月1日，则不通过日期校验
    if (d < minDate || d > maxDate) {
      return false
    }
    if (type) {
      return d.getFullYear() + '年' + (d.getMonth() + 1) + '月' + d.getDate() + '月'
    }

    return (d.getFullYear() == r[1] && (d.getMonth() + 1) == r[3] && d.getDate() == r[4])
  },
  Validator: {
    idNo: function (idType, idNo) {
      var checkResult = {
        result: true
      };
      var formatErrorResult = {
        result: false,
        error: '证件号码格式错误'
      };
      if (idNo == '') {
        checkResult = {
          result: false,
          error: '证件号码不能为空'
        };
      } else {
        switch (idType) {
          // 身份证：15或18位字符
          case '01':
            if (idNo.length == 15) {
              checkResult = {
                result: false,
                error: '请输入18位身份证号'
              };
            } else if (!(Utils.RegexMap.idCard.test(idNo) && Utils.strDateTime(idNo.substr(6, 8)))) {
              checkResult = formatErrorResult;
            }
            break;
            // 护照 2
            // 士兵证
            // 军官证：6-50位字符(可输中文)
          case '02':
          case '03':
          case '04':
            if (!/^[\u4e00-\u9fa5a-zA-Z\d]{6,50}$/.test(idNo)) {
              checkResult = formatErrorResult;
            }
            break;
            // 港澳台回乡证或台胞证: 5-50位字符，只允许大写字母和数字，最多输入50位
          case '05':
          case '06':
            if (!/^[A-Z\d]{5,50}$/.test(idNo)) {
              checkResult = formatErrorResult;
            }
            break;
          default:
            // 其他：3-50位字符，最多输入50位
            if (!/^[a-zA-Z\d]{3,50}$/.test(idNo)) {
              checkResult = formatErrorResult;
            }
            break;
        }
      }
      return checkResult;
    },
    identityCodeValid: function (code) {
      var _code = code;
      var city = {
        11: '北京',
        12: '天津',
        13: '河北',
        14: '山西',
        15: '内蒙古',
        21: '辽宁',
        22: '吉林',
        23: '黑龙江 ',
        31: '上海',
        32: '江苏',
        33: '浙江',
        34: '安徽',
        35: '福建',
        36: '江西',
        37: '山东',
        41: '河南',
        42: '湖北 ',
        43: '湖南',
        44: '广东',
        45: '广西',
        46: '海南',
        50: '重庆',
        51: '四川',
        52: '贵州',
        53: '云南',
        54: '西藏 ',
        61: '陕西',
        62: '甘肃',
        63: '青海',
        64: '宁夏',
        65: '新疆'
        // 71: "台湾",
        // 81: "香港",
        // 82: "澳门",
        // 91: "国外"
      };
      var tip = '';
      var pass = true;
      if (!code || !/^[1-9]\d{5}((1[89]|20)\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dx]$/i.test(code)) {
        pass = false;
      } else if (!city[code.substr(0, 2)]) {
        pass = false;
      } else {
        // 18位身份证需要验证最后一位校验位
        if (code.length == 18) {
          code = code.split('');
          // ∑(ai×Wi)(mod 11)
          // 加权因子
          var factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
          // 校验位
          var parity = [1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2];
          var sum = 0;
          var ai = 0;
          var wi = 0;
          for (var i = 0; i < 17; i++) {
            ai = code[i];
            wi = factor[i];
            sum += ai * wi;
          }
          var last = parity[sum % 11];
          if (parity[sum % 11] != code[17].toUpperCase()) {
            pass = false;
          }
        }
      }
      if (pass) {
        // 出生日期检验
        var birth = _code.substr(6, 8);
        var year = birth.substr(0, 4);
        var isLeapYear = year % 400 == 0 || (year % 100 != 0 && year % 4 == 0);
        if (isLeapYear) {
          pass = /((19[0-9]{2})|(200[0-9]))((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))/i.test(birth);
        } else {
          pass = /((19[0-9]{2})|(200[0-9]))((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))/i.test(birth);
        }
      }
      return pass;
    },
    // 银行卡号
    bankCard (cardNo) {
      cardNo = cardNo + ''
      var len = cardNo.length
      var oddDesc = []
      var evenDesc = []
      var oddSum = 0
      var evenSum = 0
      for (var i = len - 1, j = 1; i >= 0; i--, j++) {
        var no = parseInt(cardNo[i])
        if (j % 2 == 0) {
          evenDesc.push(no)
          evenSum += no * 2 >= 10 ? (no * 2) - 9 : no * 2
        } else {
          oddDesc.push(no)
          oddSum += no
        }
      }
      return (oddSum + evenSum) % 10 == 0
    }
  },
  getUserLoginInfo: function () {
    if ($UserInfo && $UserInfo.flag && $UserInfo.flag == Flag.SUCCESS) {
      return $UserInfo;
    }
    $UserInfo = Utils.data(Utils.Constant.USER_LOGIN_INFO);
    return $UserInfo;
  },
  getLastStepInfo () {
    $LastStepInfo = Utils.data(Utils.Constant.APPLY_PROGRESS_WLH.LAST_STEP_DATA);
    return $LastStepInfo;
  },
  setLastStepInfo: function (lastStepInfo, allStepInfo) {
    Utils.data(Utils.Constant.APPLY_PROGRESS_WLH.LAST_STEP_DATA, lastStepInfo[0]);
    Utils.data(Utils.Constant.APPLY_PROGRESS_WLH.ALL_STEP_DATA, allStepInfo);
  },
  data (key, value, type) {
    var storage = localStorage
    if (type && type == '1') {
      storage = sessionStorage
    }
    var getItemValue = function () {
      var data = storage.getItem(key)
      try {
        data = JSON.parse(data)
      } catch (e) {
        Utils.logs(e.message)
      }
      return data
    }
    if (key && value === undefined) {
      return getItemValue()
    } else if (key && value === null) {
      // ios的时候，fix removeItem后，再马上getItem的时候，能获取到数据
      storage.setItem(key, '')
      storage.removeItem(key)
    } else {
      storage.setItem(key, JSON.stringify(value));
    }
  },
  getAuthListData () {
    const userInfo = Utils.getUserLoginInfo();
    const lastStep = Utils.getLastStepInfo();
    return _.extend(userInfo, lastStep)
  },
  getParameter (param, url) {
    var reg = new RegExp('[&,?]' + param + '=([^\\&]*)', 'i');
    var value = reg.exec(url || location.search);
    return value ? value[1] : '';
  },
  getVal (obj, path, defaultVal) {
    return _.get(obj, path, defaultVal);
  },
  isLastNode (res) {
    const allStepInfo = res.data.suppNodeList || Utils.data(Utils.Constant.APPLY_PROGRESS_WLH.ALL_STEP_DATA);

    const restNodeListData = _.filter(allStepInfo, item => {
      return item.finishFlag === Flag.NO;
    })
    Utils.setLastStepInfo(restNodeListData, res.data.suppNodeList);

    return !restNodeListData.length;
  },
  async goNextStep (res, start) {
    if (res && !res.data) {
      return this.openWlh({});
    }

    if (this.isLastNode(res)) {
      if(Config.query.channelH5 !== 'channelH5'){
        return this.openWlh({geoInfo: '', creditOrg: ''});
      }
      await BModal.addModalComponent(contractPopup,'footer');
      const agreementRes = await BModal.contractPopup.showPopup();
      Native.showCustomerTip({type: 'loading'});
      console.log('agreementRes', agreementRes);
      if (agreementRes && agreementRes.data && agreementRes.data.crawlFlag === Flag.YES) {
        const deviceData = await this.crawlingDeviceInfo();
        if (deviceData && deviceData.flag === Flag.SUCCESS) {
          console.log('crawMap ---->', deviceData)
          const crawMap = deviceData.data
          let fileMap = [];
          const bizContent = {
            encryption: 'N',
            ocFlowNo: agreementRes.data.ocFlowNo || '',
            appList: crawMap.appList.data.appList,
            geoInfo: JSON.stringify(crawMap.geoInfo.data || {}),
            contactList: crawMap.contacts.data.contactsList,
            callRecords: crawMap.callLogInfo.data.callLogs || [],
          }
          if (crawMap.appList.data.fileId) {
            bizContent.appList = ''
            fileMap.push({
              fileId: crawMap.appList.data.fileId,
              fileKey: 'appList'
            })
          }
          if (crawMap.contacts.data.fileId) {
            bizContent.contactList = ''
            fileMap.push({
              fileId: crawMap.contacts.data.fileId,
              fileKey: 'contactList'
            })
          }
          if (crawMap.callLogInfo.data.fileId) {
            bizContent.callRecords = ''
            fileMap.push({
              fileId: crawMap.callLogInfo.data.fileId,
              fileKey: 'callRecords'
            })
          }
          Native.showCustomerTip({type: 'loading'});
          const drawResponse = await Native.ajax({
            url: Api('IPAYLPS'),
            data: {
              method: Api('DRAW_CRAWL_USER_DATA'),
              bizContent: JSON.stringify(bizContent),
            },
            fileMap: fileMap
          })
          console.log('drawResponse', drawResponse)
          if (drawResponse && drawResponse.flag === Flag.SUCCESS) {
            return this.openWlh({ geoInfo: bizContent.geoInfo, creditOrg: agreementRes.creditOrg || '' });
          }
          Native.clearToast();
          return Native.showCustomerTip({type: 'warning', message: drawResponse.msg || drawResponse.message || '请求失败，请重试~'})
        }
      }
      return this.openWlh({geoInfo: '', creditOrg: ''});
    }

    let { nodeCode } = this.getLastStepInfo();

    if (Utils.Constant.CRAWL_INFO_SWITCH === 'A' && nodeCode === 'CONTACT') {
      nodeCode = 'CONTACTS';
    }

    const routerConfig = {
      path: Api('wlh_' + nodeCode.toLowerCase()),
      query: Object.assign(Config.query, {
        refBizNo: res.data.refBizNo || '',
        nodeCode: nodeCode || Utils.getParameter('nodeCode') || '',
        custName: res.data.custName || ''
      })
    }
    setTimeout(() => {
      start ? Router.push(routerConfig) : Router.replace(routerConfig);
    })
  },
  // 静默开通微零花
  openWlh (bizParam) {
    Native.showCustomerTip({type: 'loading', message: '正在为您开通'});
    Native.ajax({
      url: Api('IPAYLPS'),
      data: {
        method: Api('ACTIVATION_BANK_CARD'),
        bizContent: JSON.stringify(bizParam)
      }
    }).then(async response => {
      Native.clearToast();
      console.log('ACTIVATION_BANK_CARD', response);
      if (response.flag === Flag.SUCCESS) {
        if (response.data === 'F') {
          Router.replace({
            path:Api('wlh_audit_bankfail'),
            query: Config.query
          });
        } else if(response.data === 'G'){
          Router.replace({
            path:Api('wlh_audit_failed'),
            query: Config.query
          });
        } else {
          const bizContent={
            productCode:'360PAY',
            openCardDataUploadFlag:"Y",
            geoInfo:'',
            appList:[],
            contactList:[],
            callRecords:[],
          }
          const resData = await Native.ajax({
            url:Api('LPS'),
            data:{
              method:Api('WLH_iPayCommit'),
              bizContent:JSON.stringify(bizContent)
            }
          })
          if(resData&&resData.flag==='S'){
            CreditRequest.solveTheNode(resData.data);
          }else if(resData&&resData.flag==='F'&&resData.msg){
            Toast(resData.msg);
          }
        }
        return false;
      }
      throw response;
    }).catch(err => {
      console.log('ACTIVATION_BANK_CARD ERR', err)
      Native.clearToast();
      Native.showCustomerTip({message: err.msg || err.message || '请求发生错误，请重试~', type: 'warning'});
    })
  },
  report (params) {
    console.log({
      eventId: params.id,
      customAttributes: params.data
    })
  },
  // 逆地理编码
  getLocations (callback, notRealTime, isMust) {
    Native.getAddressInfo({
      realTime: !notRealTime ? 'true' : 'false',
      isMust: isMust || 'Y',
      callback: function (data) {
        callback(data)
      }
    }).then((res) => {
      callback(res)
    });
  },
  usePhoneOpenTest: function (numbers, type) {
    if (type) return true
    var userInfo = Utils.data(Utils.Constant.USER_LOGIN_INFO) || {}
    var mobileNo = (userInfo && String(userInfo.flag).toUpperCase() === 'S' && userInfo.data && userInfo.data.mobileNo) || ''
    var isTest = false
    if (mobileNo) {
      var no = mobileNo.substring(mobileNo.length - 1)
      isTest = numbers.indexOf(no) !== -1
    }
    return isTest
  },
  // 联系人优选的参数
  getUserChooseInfoOption: function () {
    var userInfo = Utils.data(Utils.Constant.USER_LOGIN_INFO) || {}
    var type = ''; var optimumModel = {}
    if (Utils.usePhoneOpenTest(Utils.Constant.CONTACT_CHOOSE_OPEN_TEST_2)) {
      type = Utils.Constant.CONTACT_CHOOSE_TYPE_2
      optimumModel = {
        contactRange: '1500',
        uploadUserInfo: Utils.Constant.IS_CONTACT_CHOOSE_TYPE_UPLOAD,
        uploadInputData: Utils.Constant.IS_CONTACT_CHOOSE_TYPE_UPLOAD,
        idCard: userInfo.idNo || '',
        userName: userInfo.custName || userInfo.userName || '',
        userPhone: userInfo.mobileNo || ''
      }
    } else if (Utils.usePhoneOpenTest(Utils.Constant.CONTACT_CHOOSE_OPEN_TEST)) {
      type = Utils.Constant.CONTACT_CHOOSE_TYPE
    }
    return {
      type: type,
      optimumModel: optimumModel
    }
  },
  // 提交申请前爬取动作
  crawlingDeviceInfo: function (deviceMust = Flag.NO, isGetGeo = Flag.YES) {
    return new Promise(function (resolve, reject) {
      var map = {}
      Utils.authorization().then(function () {
        return Utils.getApp()
      }).then(function (res) {
        map.appList = res
        return Utils.getContactsInfo()
      }).then(function (res) {
        map.contacts = res
        return Utils.getCallLogInfo()
      }).then(function (res) {
        map.callLogInfo = res
        return Utils.getDeviceInfo(deviceMust)
      }).then(function (res) {
        map.deviceInfo = res
        if (isGetGeo === Flag.NO) {
          return null
        }
        return Utils.getLocation()
      }).then(function (res) {
        map.geoInfo = res
        return resolve({
          flag: 'S',
          data: map,
          msg: ''
        })
      }).catch(function (err) {
        Native.clearToast();
        if (err.flag && String(err.flag).toUpperCase() === Flag.ENABLE && err.msg) {
          Dialog.alert({
            confirmButtonText: '知道了',
            message: err.msg
          })
        } else if (err.msg) {
          // Native.showCustomerTip({
          //   type: 'warning',
          //   message: err.msg
          // })
          if (err.data && err.data.handled === Flag.YES) {
            console.log('Native已经处理过了', err)
            return reject(err)
          }
        }

        return reject(err)
      })
    })
  },
  // 检查联系人权限
  authorization: function () {
    return new Promise(function (resolve, reject) {
      // 如果开启了免爬取开关，直接resolve
      if (Utils.Constant.CRAWL_INFO_SWITCH === 'A') {
        return resolve()
      }
      Native.IS_IOS && Native.authorizations({
        authType: 'contact',
        callback: function (data) {
          var _authStatus = data && data.data && data.data.authStatus || ''
          _authStatus = String(_authStatus).toUpperCase()
          if (_authStatus == 'DENIED') {
            Native.clearToast();
            Dialog.confirm({
              title: '请开启通讯录权限',
              message: Utils.Constant.MSG.COMMON.CONTACTS_AUTH_IOS,
              confirmButtonText: '去开启',
              cancelButtonText: '取消',
              className: 'wlh',
            }).then(() => {
              Native.openURLS('prefs:root=Privacy&path=CONTACTS')
            })
            return reject(_.extend(data, { msg: '', flag: Flag.FAIL }))
          }
          if (!data || String(data.flag).toUpperCase() == Flag.FAIL) {
            return reject(data)
          }
          // not 情况不处理
          _authStatus == 'AUTHORIZED' ? resolve(data) : (_authStatus != 'NOT' && reject(data))
        }
      })

      Native.IS_ANDROID && resolve()
    })
  },
  // 获取定位信息
  getLocation () {
    return new Promise(function (resolve, reject) {
      Utils.getLocations(function (res) {
        var _flag = String(res.flag).toUpperCase()
        if (_flag === Flag.SUCCESS) {
          var _addressInfo = res.data

          var _geoInfo = {
            latitude: _addressInfo.latitude,
            longitude: _addressInfo.longitude,
            country: _addressInfo.country,
            province: _addressInfo.province,
            city: _addressInfo.city,
            area: _addressInfo.district,
            addrInfo: _addressInfo.addrInfo
          }
          if (!_geoInfo.latitude || !_geoInfo.longitude || !_geoInfo.city) {
            Native.clearToast();
            Native.showCustomerTip({message: '获取定位信息失败', type: 'warning'});
            return reject({
              flag: Flag.ENABLE,
              category: 'GPS',
              msg: Utils.Constant.GEO_LOCATION.ERROR_MSG.GETLOCATION_ERROR
            })
          }
          return resolve({
            flag: Flag.SUCCESS,
            msg: '',
            data: _geoInfo
          })
        }
        Native.clearToast();
        if (_flag === Flag.ENABLE) {
          Native.showCustomerTip({ message: Utils.Constant.GEO_LOCATION.ERROR_MSG.GETLOCATION_ERROR, type: 'warning' })
          return reject({
            flag: _flag,
            category: 'GPS',
            msg: Utils.Constant.GEO_LOCATION.ERROR_MSG.GETLOCATION_ERROR
          })
        }
        Native.showCustomerTip({message: res.msg || Utils.Constant.GEO_LOCATION.ERROR_MSG.GETLOCATION_ERROR, type: 'warning'})
        return reject(_.extend({}, res, { category: 'GPS' }))
      })
    })
  },
  // 获取APP列表
  getApp () {
    return new Promise(function (resolve) {
      if (Native.IS_ANDROID) {
        Native.getInstalledApps().then((res) => {
          console.log('getInstalledApps res', res)
          if (res && res.flag === Flag.SUCCESS) {
            AppList = res
            return resolve(res)
          } else {
            return resolve({ flag: Flag.SUCCESS, msg: '', data: { appList: [] } })
          }
        })
      } else {
        return resolve({ flag: Flag.SUCCESS, msg: '', data: { appList: [] } })
      }
    })
  },
  // 获取联系人信息
  getContactsInfo () {
    return new Promise(function (resolve, reject) {
      // 如果开启了免爬取开关
      if (Utils.Constant.CRAWL_INFO_SWITCH === 'A') {
        return resolve({
          flag: 'S',
          data: {
            contactsList: []
          }
        })
      }
      Native.getContactsInfo('0', function (res) {
        try {
          res && typeof res === 'string' && JSON.parse(decodeURIComponent(res))
          if (res && String(res.flag).toUpperCase() === Flag.SUCCESS) {
            Contacts = res
            return resolve(res);
          }
        } catch (e) {
          Native.clearToast()
          return reject({ flag: Flag.FAIL, msg: '获取联系人异常', category: 'contacts' })
        }
        Native.clearToast()
        if (Native.IS_ANDROID) {
          if (res.data.handled !== Flag.YES) {
            Dialog.confirm({
              title: '请开启通讯录权限',
              className: 'wlh',
              cancelButtonText: '取消',
              confirmButtonText: '去开启',
              message: Utils.Constant.MSG.COMMON.CONTACTS_AUTH,
            }).then(() => Native.openPermissionSet())
          }
        } else {
          Dialog.alert({
            title: '请确保通讯录不为空',
            confirmButtonText: '确定',
            message: '为了保障您的信息安全，请确保通讯录不为空'
          })
        }
        reject(_.extend(res, { msg: '', category: 'contacts' }))
      })
    })
  },
  //　获取通话记录
  getCallLogInfo: function () {
    return new Promise(function (resolve, reject) {
      // 如果开启了免爬取开关
      if (Native.IS_IOS || Utils.Constant.CRAWL_INFO_SWITCH === 'A') {
        return resolve({
          flag: 'S',
          data: {
            callLogs: []
          }
        })
      }

      Native.getInfoLogs({
        limit: '0',
        dateRange: '0',
        type: 'call'
      }, function (res) {
        Native.clearToast()
        if (typeof res === 'string') {
          res = JSON.parse(decodeURIComponent(res))
        }

        if (res && res.flag === Flag.SUCCESS) {
          CallLogInfo = res
          return resolve(res)
        } else {
          var handled = res.data && res.data.handled || Flag.NO
          return reject({ flag: Flag.FAIL, msg: res.msg, category: 'callLog', data: { handled: handled } })
        }
      })
    })
  },
  // 获取设备信息
  getDeviceInfo (isMust = Flag.NO) {
    var self = this
    return new Promise(function (resolve, reject) {
      if (self._deviceInfo) {
        return resolve(self._deviceInfo)
      }
      Native.getDeviceFingerPrintParams({ isMust: isMust }, function (res) {
        if (res && res.flag == Flag.SUCCESS) {
          self._deviceInfo = res
          return resolve(res)
        } else {
          return isMust === Flag.YES ? reject(res) : resolve({ flag: 'S', data: {} })
        }
      })
    })
  },

  // 金额千分位
  numFormat (num){
    if(!num) return 0;
    var res=num.toString().replace(/\d+/, function(n){ // 先提取整数部分
      return n.replace(/(\d)(?=(\d{3})+$)/g,function($1){
        return $1+",";
      });
    });
    return !!res ? res : 0;
  },
};

export default Utils;
