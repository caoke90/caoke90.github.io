import _ from 'lodash';
import Flag from '@/constant/flag';
import Native from 'native';
import Api from '../../common/api';
import { Dialog } from 'vant';
import { Bus } from './Bus';

const getQueryObject = require('../../utils/getQueryObject');
const isApp = getQueryObject('appChannel') === 'app';
const isIOS = Native.IS_IOS;
const checkActiveVersion = isApp ? '1.0.11' : '1.0.13';
const getChannelVersion = isIOS.IS_IOS ? '1.0.9' : '1.0.0';
const iOSMuteCheckVersion = '1.6.2';
// const FaceConfig = Dicts.FACE_TYPE
// const OCRConfig = Dicts.OCR
class FaceRecognition {
  constructor (options = {}) {
    this.constant = {
      partCode: {
        YT: 'YITU', // 依图
        FACE: 'FACEAA', // Face++
        ST: 'SENSETIME' // 商汤
      },
      partCodeList: ['YITU', 'FACEAA', 'SENSETIME'],
      actionType: {
        Face: 'FACE', // 活体检测
        ID: 'ID_OCR' // 身份证OCR
      },
      bizTypeMap: {
        YITU: 'YITU_PACKAGE',
        FACEAA: 'FACEAA',
        SENSETIME: 'SENSETIME'
      }
    }
    this.version = {
      checkActive: checkActiveVersion, // 需要检查活动保留的version
      channel: getChannelVersion, // 有渠道获取接口的version
      checkMute: iOSMuteCheckVersion // ios检查静音version
    }
    this.isApp = isApp;
    this.isIOS = isIOS;
    this.compareVersionCache = {};
    this.channelInfo = null;
    this.config(options || {});
  }
  config (options = {}) {
    this.options = {
      // 无登录标识
      logoutFlag: options.logoutFlag || false,
      // SDK code
      sdkType: options.sdkType && this.constant.partCodeList.indexOf(options.sdkType) > -1 ? options.sdkType : null,
      // 刷脸timeout时间及回调
      faceTimeout: options.faceTimeout || 8000,
      faceTimeoutCall: options.faceTimeoutCall || null,
      // 提交文件timeout时间及回调
      uploadTimeout: options.uploadTimeout || 8000,
      uploadTimeoutCall: options.uploadTimeoutCall || null,
      checkMute: this.isIOS ? (options.checkMute || false) : false, // 是否需要检查静音
      // state: show-展示；close-点击关闭；invoke-点击唤起；autoInvoke-自动唤起
      beforeRecognition: options.beforeRecognition || null,
      afterRecognition: options.afterRecognition || null,
      beforeUpload: options.beforeUpload || null,
      afterUpload: options.afterUpload || null
    }
    return this;
  }
  // actionType: 'FACE' / 'ID_OCR'
  // 暂时只封装FACE, ID_OCR暂不支持
  // step:
  //  1、检查权限
  //  2、获取code
  //  3、调用刷脸/OCR
  // return PromiseObject
  invoke () {
    return this.invokeFaceRecognition()
  }
  // 调用活体检测
  invokeFaceRecognition () {
    return new Promise((resolve, reject) => {
      let result = {
        step: '',
        partCode: '',
        faceRecognition: {},
        preCheck: {},
        uploadFile: {},
        msg: ''
      }
      let startTime = null;
      let endTime = null;
      let timer = null;
      this.getThirdPartCode(this.constant.actionType.Face).then((partCode) => {
        result.partCode = partCode
        result.step = 'partCode'
        console.log('start pre check')
        return this.preCheck()
      }).then((res) => {
        console.log(res)
        result.step = 'preCheck'
        result.preCheck = res || { flag: 'S' }
        // 开始刷脸时间点钩子
        this.options.beforeRecognition && this.options.beforeRecognition(_.extend({}, result))
        startTime = new Date().getTime()
        return this.faceRecognition(result.partCode)
      }, (err) => {
        result.step = 'preCheck'
        result.preCheck = err
        result.msg = '没有权限'
        return reject(result)
      }).then((res) => {
        // 调用native刷脸回调后，需要继续流程
        endTime = +new Date()
        res.useTime = endTime - startTime
        result.step = 'faceRecognition'
        result.faceRecognition = res
        timer = setTimeout(() => {
          this.options.uploadTimeoutCall && this.options.uploadTimeoutCall()
        }, this.options.uploadTimeout)
        // 刷脸结束钩子
        this.options.afterRecognition && this.options.afterRecognition(result)
        if (res && res.flag === Flag.SUCCESS) {
          // 开始上传文件时间钩子
          this.options.beforeUpload && this.options.beforeUpload(result)
          return this.commitFaceRecognitionFile(res)
        } else {
          result.uploadFile = {
            flag: 'S',
            data: {
              fileNameCodes: {}
            }
          }
          return reject(result)
        }
      }, err => {
        // 调用native刷脸回调后，流程结束
        // face++联网授权失败 或者 用户主动取消
        console.log('err faceRecognition', err)
        endTime = +new Date()
        err.useTime = endTime - startTime
        result.step = 'faceRecognition'
        result.faceRecognition = err
        result.reason = err.flag === Flag.CANCEL ? '用户主动取消' : 'face联网授权失败'
        // 刷脸结束钩子
        this.options.afterRecognition && this.options.afterRecognition(result)
        return reject(result)
      }).then(res => {
        console.log('uploadFile res', res)
        // 提交文件成功，整个刷脸流程完结
        clearTimeout(timer)
        result.step = 'uploadFile'
        result.uploadFile = res
        this.options.afterUpload && this.options.afterUpload(result)
        return resolve(result)
      }, (err) => {
        console.log('uploadFile err', err)
        // 提交文件失败，整个刷脸流程完结
        clearTimeout(timer)
        result.step = 'uploadFile'
        result.uploadFile = err
        result.reason = '上传文件失败'
        this.options.afterUpload && this.options.afterUpload(result)
        return reject(result)
      })
    })
  }
  commitFaceRecognitionFile (info) {
    return new Promise((resolve, reject) => {
      // eslint-disable-next-line no-unreachable
      const data = info.data
      const sdkType = data.sdkType
      const bizType = this.constant.bizTypeMap[sdkType]
      const fileKeys = []
      const fileMap = []
      const imageIdMap = {}
      const imageMap = data.imageMap || []
      if (sdkType === this.constant.partCode.YT) {
        fileKeys.push('fileContent')
        fileMap.push({
          fileId: data.fileId,
          fileKey: 'fileContent'
        })
      }
      imageMap.forEach((v, i) => {
        if (!imageIdMap[v.fileKey]) {
          fileKeys.push(v.fileKey)
          fileMap.push(v)
        }
      })
      // eslint-disable-next-line no-unreachable
      if (fileKeys.indexOf('delta') < 0) {
        fileKeys.push('delta')
        fileMap.push({
          fileKey: 'delta',
          fileId: data.delta
        })
      }
      const method = this.options.logoutFlag ? Api('COMMON_MULTI_FILE_UPLOAD_OLD') : Api('COMMON_MULTI_FILE_UPLOAD')
      const options = {
        method: method,
        bizContent: JSON.stringify({
          fileKeys: fileKeys,
          bizType: bizType
        }),
        fileMap: fileMap
      }
      console.log('commitFaceRecognitionFile:', options);
      const startTime = new Date().getTime();
      this.fetch(options).then((res) => {
        console.log('upload insaid', res)
        const endTime = new Date().getTime();
        res.uploadFileTime = endTime - startTime;
        if (res.flag === Flag.SUCCESS) {
          const isSuccess = this.checkObjectKey(res.data.fileNameCodes, fileKeys);
          return isSuccess ? resolve(res) : reject(res);
        } else {
          return reject(res);
        }
      }).catch((err) => {
        const endTime = +new Date()
        err.uploadFileTime = endTime - startTime
        return reject(err)
      })
    })
  }
  fetch (options) {
    return new Promise((resolve, reject) => {
      const o = {}
      options.fileId && (o.fileId = options.fileId)
      options.fileKey && (o.fileKey = options.fileKey)
      options.fileMap && (o.fileMap = options.fileMap)
      Native.ajax({
        url: options.url || Api('LPS'),
        type: options.type || 'post',
        data: {
          method: options.method,
          bizContent: options.bizContent
        },
        outermostParams: o,
        ...o
      }).then(res => resolve(res)).catch(err => reject(err))
    })
  }
  checkObjectKey (obj, keyList) {
    for (let i = 0, len = keyList.length; i < len; i++) {
      if (!obj[keyList[i]]) {
        return false
      }
    }
    return true
  }
  // 调用身份证OCR
  invokeOcrRecognition () {
  }
  // 调用Native刷脸
  faceRecognition (partCode) {
    console.log('faceRecognition start');
    return new Promise((resolve, reject) => {
      Native.faceRecognition({
        sdkType: partCode,
        viewType: 'cancel'
      }, (res) => {
        console.log('faceRecognition res', res);
        if (res && res.flag === Flag.FAIL && res.data && res.data.failCode === '') {
          res.data.failCode = '6'
        }
        if (res && res.flag === Flag.SUCCESS) {
          return resolve(res)
        } else {
          // 直接结束的流程
          // 用户主动取消 或者 face++联网失败
          // 用户主动取消 或者 结果为fail
          if ((res && res.flag === Flag.CANCEL) || (res && res.flag === Flag.FAIL && res.data.sdkType && res.data.sdkType === this.constant.partCode.FACE && res.data.failCode === '7')) {
            return reject(res)
          } else {
            return resolve(res)
          }
        }
      })
    })
  }
  // 权限检查
  // ios 检查相机权限
  // 安卓检查保留活动（开发者选项）
  preCheck () {
    if (this.isIOS) {
      return new Promise((resolve, reject) => {
        let authResult = null
        this.authorization().then((res) => {
          // 相机权限检查成功
          authResult = res
          // 继续检查是否静音
          return this.muteCheck()
        }, (res) => {
          // 相机权限检查失败（拒绝或者需要提示开取权限）
          return reject(res)
        }).then(() => {
          // 完成静音检查
          console.log('完成静音检查')
          return resolve(authResult)
        }, (err) => {
          // 静音检查失败（来自用户的主动取消）
          return reject(err)
        })
      })
    } else {
      return this.checkKeepActive()
    }
  }
  // 获取使用的合作方code
  // actionType: 'FACE' 活体， 'ID_OCR' 身份证OCR
  getThirdPartCode (actionType) {
    return new Promise((resolve) => {
      const { constant } = this
      // APP中默认使用FACE++，SDK中默认使用YITU;
      let type = this.isApp ? constant.partCode.FACE : constant.partCode.YT
      if (this.options.sdkType) {
        // 如果调用时有配置sdkType，则使用配置的
        type = this.options.sdkType
        return resolve(type)
      } else {
        return resolve(type)
      }
    })
  }
  // 获取渠道信息
  getChannelInfo () {
    return new Promise((resolve, reject) => {
      if (this.channelInfo) {
        return resolve(this.channelInfo)
      } else {
        Native.getAndroidChannleInfos((channelInfo) => {
          this.channelInfo = channelInfo
          return resolve(channelInfo)
        })
      }
    })
  }
  // 静音检查
  muteCheck () {
    return new Promise((resolve, reject) => {
      console.log('start muteCheck', this.isIOS, this.options.checkMute)
      if (!this.isIOS || !this.options.checkMute) {
        return resolve()
      } else {
        Native.getVolumeState({
          callback: function (res) {
            console.log('muteCheck res', res)
            // res.flag: S-成功；F-失败；N-不支持；
            // 是否需要提示 (静音标识isMute为1 或者 音量volume小于19%)
            const tipFlag = res && res.flag === 'S' && res.data && (res.data.isMute === '1' || (res.data.volume || '1') < 0.19)
            if (!tipFlag) {
              // 不需要提示
              return resolve()
            } else {
              // 处理静音
              // 展示静音提醒弹窗
              // 是否静音
              const isMute = res && res.flag === 'S' && res.data && (res.data.isMute === '1')
              console.log(Bus)
              Bus.$emit('isMute', isMute)
              Bus.$on('setMute', (type) => {
                if (type === 'close') {
                  // 用户点击关闭，返回失败，flag为CANCEL取消
                  // eslint-disable-next-line
                  reject({ flag: 'C', type: 'MutePrompt' })
                } else if (type === 'invoke' || type === 'autoInvoke') {
                  // 自动倒计时 或者 用户主动点击刷脸
                  return resolve()
                }
              })
            }
          }
        })
      }
    })
  }
  // IOS 检查相机权限
  // 包含受限提示
  authorization () {
    return new Promise((resolve, reject) => {
      console.log('authorization start')
      Native.authorizations({
        authType: 'capture',
        callback: function (d) {
          console.log('authorization res', d)
          if (d && d.flag === Flag.SUCCESS) {
            const authStatus = d.data.authStatus
            if (authStatus === 'authorized') {
              // IOS延迟400毫秒回调，避免face++唤起刷脸后立马关闭
              setTimeout(() => {
                return resolve(d)
              }, 400)
            } else if (authStatus === 'denied') {
              Dialog.confirm({
                message: '请开启相机权限 \n 无法开心的刷脸了，请进入系统设置开启相机权限',
                showCancelButton: true,
                confirmButtonText: '去开启',
                cancelButtonText: '取消'
              }).then(() => {
                Native.openURLS('prefs:root=Privacy&path=CAMERA')
              })
              return reject(_.extend({
                flag: Flag.FAIL,
                type: 'authorization'
              }, d))
            }
          } else {
            d.msg && Native.showCustomerTip({
              message: d.msg,
              type: 'warning'
            })
            return reject(_.extend({
              flag: Flag.FAIL,
              type: 'authorization'
            }, d))
          }
        }
      })
    })
  }
  // 安卓检查是否开启了保留活动
  // 包含关闭提示
  checkKeepActive () {
    console.log('checkKeepActive')
    return new Promise((resolve, reject) => {
      Native.checkIsKeepActivity((res) => {
        console.log('checkKeepActive', res)
        if (res.flag === Flag.SUCCESS && res.data.isKeepActivity === '0') {
          return resolve(res)
        } else {
          Dialog.alert({
            message: '您开启了开发者选项，可能导致刷脸失败，请关闭开发者选项',
            confirmButtonText: '确定'
          }).then(() => {
            Native.setKeepActivity()
          })
          return reject(_.extend({
            flag: Flag.FAIL,
            type: 'checkIsKeepActivity'
          }, res))
        }
      })
    })
  }
  // 版本检查
  compareVersion (version) {
    return new Promise((resolve, reject) => {
      if (this.compareVersionCache[version] !== undefined) {
        // eslint-disable-next-line prefer-promise-reject-errors
        return this.compareVersionCache[version] ? resolve() : reject()
      } else {
        Native.compareVersion(version, (result) => {
          this.compareVersionCache[version] = result >= 0
          // eslint-disable-next-line prefer-promise-reject-errors
          return result >= 0 ? resolve() : reject()
        })
      }
    })
  }
}
let Instance = null
const getInstance = (options) => {
  if (Instance) {
    Instance.config(options || {})
  } else {
    Instance = new FaceRecognition(options || {})
  }
  return Instance
}
export default getInstance