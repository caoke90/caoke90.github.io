import Native from 'native'
import BModal from 'BModal'
import { queryEle } from '@/service/ele'
import Api from '@/common/api'
import _ from 'lodash'
import bindCardFail from '@/componets/modal/bindCardFail.vue'
import { Toast } from 'vant'
BModal.addModalComponent(bindCardFail, 'header')
import { ipayQueryHomeData } from '@/service/home'
/**
 * @param {
 *  initEventCode: string; // 初始化页面埋点
 *  bindChannel: 'WX' | 'ZFB'; // 一键绑卡渠道参数
 * } typeParams
 */
export default function getUseGuideMixin (typeParams) {
  const { initEventCode, bindCardEventCode, bindChannel } = typeParams
  return {
    data () {
      return {
        cardId: this.$route.query.cardId || '0000',
        pageOutputVO: null,
        showNoticeBar: false,
        barText: '',
        linkUrl: '',
        supportFlag: 'N',
        backUrl: '',
        bindStatus: '',
        weixinBindSwitch: '',
        alipayBindSwitch: ''
      }
    },
    methods: {
      initTrackEvent (type) {
        Native.reportUbas({
          eventCode: initEventCode,
          bizData: { type }
        })
      },
      bindCardTrackEvent (result, reason) {
        Native.reportUbas({
          eventCode: bindCardEventCode,
          bizData: { result, reason }
        })
      },
      async queryElements () {
        try {
          const data = await queryEle(['noticeBar'])
          const noticeBars = _.get(data, 'noticeBars[0]', '{}')
          const { linkUrl = '', barText = '' } = noticeBars
          this.barText = barText
          this.linkUrl = linkUrl
          if (barText) this.showNoticeBar = true
          this.initTrackEvent('bindCard')
        } catch (err) {
          this.initTrackEvent('copyCard')
        }
      },
      // 查询是否支持百信银行绑卡
      async queryBaixinStatus () {
        Toast.loading({
          duration: 0,
          forbidClick: true,
          loadingType: 'spinner'
        })
        const res = await Native.ajax({
          url: Api('IPAYLPS_NEW'),
          data: {
            method: Api('BAIXIN_BIND_CARD_QUERY'),
            bizContent: JSON.stringify({})
          }
        })
        Toast.clear()
        if (res && res.flag === 'S') {
          this.supportFlag = _.get(res, 'data.supportFlag', 'N')
          this.weixinBindSwitch = _.get(res, 'data.weixinBindSwitch', 'N')
          this.alipayBindSwitch = _.get(res, 'data.alipayBindSwitch', 'N')
        }
      },
      // 百信银行一键绑卡
      async baixinBindCard () {
        Toast.loading({
          duration: 0,
          forbidClick: true,
          loadingType: 'spinner'
        })
        try {
          const res = await Native.ajax({
            url: Api('IPAYLPS_NEW'),
            data: {
              method: Api('BAIXIN_BIND_CARD'),
              bizContent: JSON.stringify({ bindChannel })
            }
          })
          Toast.clear()
          const flag = _.get(res, 'flag')
          const msg = _.get(res, 'msg')
          this.bindStatus = null
          if (flag === 'S') {
            const { bindStatus, backUrl } = res.data || {}
            this.bindStatus = bindStatus
            if (bindStatus === 'S') {
              this.backUrl = backUrl
              this.bindCardTrackEvent('bindCardSuccess', msg)
              return
            } else if (bindStatus === 'F') {
              // 绑卡失败，弹出绑卡失败弹窗
              BModal.bindCardFail.show(() => {
                this.supportFlag = 'N'
              })
            } else {
              Toast(msg)
            }

            this.bindCardTrackEvent('bindCardFailure', msg)
          } else {
            // 接口报错，弹出错误提示
            Toast(msg)
          }
        } catch (err) {
          Toast.clear()
          const message = _.get(err, 'msg') || _.get(err, 'message')
          Toast(message)
          this.bindCardTrackEvent('bindCardFailure', message)
        }
      },
      closeNoticebar () {
        this.showNoticeBar = false
      },
      goSafeLecture () {
        if (!this.linkUrl) return
        Native.forward({
          data: {
            url: this.linkUrl || ''
          }
        })
      }
    },
    async created () {
      const data =await ipayQueryHomeData(300)
      this.pageOutputVO = data.pageOutputVO
      this.queryElements()
      this.queryBaixinStatus()
    }
  }
}
