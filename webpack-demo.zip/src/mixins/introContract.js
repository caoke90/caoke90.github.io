import _ from 'lodash'
import service from '@/service'

let agsList = []
export default {
  data () {
    return {
      agsList
    }
  },
  methods: {
    // 初始化协议信息
    async fetchContractList () {
      if (agsList.length > 0) return agsList
      const data = await service.ipayAgreementParcelList({
        procedureTypes: ['FQKAUTH', 'TERM','TERM_COMMON', 'ACCOUNT', 'FQKACC', 'FQKSERVE', 'LAUTH'],
        accountFlag: 'Y',
        honourCreditOrgs: ['PARTNER_MSXJ']
      })
      this.agsList = _.get(data, 'agreementTemplateParcelDomains', [])
      agsList = this.agsList
    }
  }
}
