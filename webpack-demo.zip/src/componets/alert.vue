<template>
  <div class="alert" v-show="isShow">
    <div class="info">
      <div class="mess">{{message}}</div>
      <div class="btn" @click="hide">{{btnText}}</div>
    </div>
    <div class="van-overlay"></div>
  </div>
</template>

<script>
  import BModal from 'BModal';
  export default {
    name: 'alert',
    data(){
      return {
        isShow:false,
        message:'',
        callback:null,
        btnText:'我知道了',
      };
    },
    created(){
      BModal.alert=this;
    },
    methods:{
      show(message){
        this.message=message
        this.isShow=true;
        return new Promise((resolve)=> {
          this.callback=resolve;
        })
      },
      hide(){
        this.message='';
        this.isShow=false;
        if(this.callback){
          this.callback();
          this.callback=null;
        }

      }
    }
  }
</script>

<style type="text/css" lang="less" scoped>
.alert{
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  overflow: hidden;
  z-index: 100;
  .info{
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%,-50%);
    transform: translate(-50%,-50%);
    z-index: 102;
    width:580px;
    background:rgba(255,255,255,1);
    border-radius:4px;
    padding: 46px 0;
    .mess{
      text-align: center;
      margin: 0 80px 46px;
      font-size:30px;
      font-family:PingFangSC-Regular,PingFang SC;
      color:rgba(51,51,51,1);
      line-height:42px;
    }
    .btn{
      width:500px;
      height:90px;
      background:rgba(0,135,246,1);
      border-radius:50px;
      font-size:36px;
      font-family:PingFangSC-Medium,PingFang SC;
      font-weight:bold;
      color:rgba(255,255,255,1);
      line-height:90px;
      text-align: center;
      margin: 0 auto;
    }
  }
  .van-overlay{
    z-index: 101;
  }

}
</style>
