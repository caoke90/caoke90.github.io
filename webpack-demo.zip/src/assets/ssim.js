function ssim(s1,s2) {
  var chunk=[]
  var n=s1.length,m=s2.length;//长度
  var n1=0,n2=0;//扫描点
//开始扫描
  while (n1<n&&n2<m){
    //相等
    if(s1[n1]===s2[n2]){
      let nn1=n1+1;
      let nn2=n2+1;
      while (nn1<n&&nn2<m&&s1[nn1]===s2[nn2]){
        nn1++;
        nn2++;
      }
      chunk.push(nn1-n1)
      n1=nn1;
      n2=nn2;
    }else{
      let d1=0;
      let d2=0;
      if(n1+1<n){
        d2=1;
      }
      if(n2+1<m){
        d1=1;
      }
      if(d1===1&&d2===1){
        if(s1[n1+1]!==s2[n2+1]){
          while (n2+d1<m&&s1[n1]!==s2[n2+d1]){
            d1++;
          }
          while (n1+d2<n&&s1[n1+d2]!==s2[n2]){
            d2++;
          }
        }
      }
      if(d1===d2){
        n1=n1+1;
        n2=n2+1;
      }else if(d1<d2){
        n2=n2+1;
      }else{
        n1=n1+1;
      }
    }
  }
  return [chunk,n];
}

var s1="456123712",
  s2="1237456";
const chunk=ssim(s1,s2);
const chunk2=ssim(s2,s1);
console.log(chunk)
console.log(chunk2)
