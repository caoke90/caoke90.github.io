import Api from '../common/api'
import {verifyTradersPwd} from './verifyPwd'
/**
 *  微零花可用券接口
 */
export function queryRepaymentCoupon(){
  return Native.ajaxv2({
    isShowLoading: false,
    url: Api('MMS'),
    data: {
      method: Api('REPAY_COUPON'),
      bizContent: {}
    }
  })
}
/**
 * 单笔订单和还款试算还款试算
 * 账单还款：BR、单笔还款：SR、多笔订单还款：MU
 */
export function orderRepayTrial ({repayType,tranType,repayChannel,loanNo,billMonth,repayAmount,ticketNo,repaySource}) {
  if(repayType==='BR'){
    return Native.ajaxv2({
      isShowToast:false,
      useCache: 60,
      url: Api('IPAYLPS'),
      data: {
        method: 'qihoo.sdk.ipay.repay.trail',
        bizContent: {
          repaySource,
          repayType,
          tranType,
          repayChannel,
          repayAmount,//逾期还款时必填
          billMonth,//帐单还款时必填
          ticketNo
        }
      }
    })
  }else if(repayType==='SR'){
    return Native.ajaxv2({
      isShowToast:false,
      useCache: 60,
      url: Api('IPAYLPS'),
      data: {
        method: 'qihoo.sdk.ipay.repay.trail',
        bizContent: {
          repayType,
          tranType,
          repayChannel,
          repayAmount,//逾期还款时必填
          loanNo,//单笔还款时必填
          ticketNo
        }
      }
    })
  }
}
/**
 * 多笔订单还款试算接口
 * loanNos 订单号列表
 * repayAmount 还款金额
 * ticketNo 优惠券号
 */
export function mu_orderRepayTrial ({loanNos,repayAmount,ticketNo}) {
  return Native.ajaxv2({
    isShowToast:false,
    useCache: 60,
    url: Api('IPAYLPS_NEW'),
    data: {
      method: 'qihoo.sdk.ipay.more.order.repay.trial',
      bizContent: {
        loanNos:loanNos,
        repayAmount,
        ticketNo
      }
    }
  })
}
/**
 *  银行卡限额
 *  repayAmount
 *  bankCode
 */
export function checkAmount(bizContent){
  return Native.ajaxv2({
    url: Api('IPAYLPS'),
    data: {
      method:Api('CHECK_AMOUNT'),
      bizContent: bizContent
    }
  })
}
 /**
 * 是否可信设备： Y-代表可信 N-代表不可信
  */

 let trustStatus;
export async function getTrustStatus(){
  if(trustStatus){
    return trustStatus;
  }
  try {
    const data=await Native.ajaxv2({
      url: Api('IPAYLPS_NEW'),
      data: {
        method: 'qihoo.sdk.ipay.user.device.trust.status',
        bizContent: {}
      }
    })
    trustStatus=data.trustStatus
    return trustStatus;
  }catch (e) {
    return 'N'
  }
}
/**
 * 多订单还款申请接口
 * loanNos 订单号列表
 * cardId 用户选择的银行卡ID
 * repayAmount 还款金额
 * ticketNo 优惠券号
 * transPwd 密码
 * trustStatus Y-可信设备，无需密码，N-非可信设备，transPwd字段必传
 */
export function orderRepayApply (bizContent) {
  if(bizContent.trustStatus === 'Y'){
    return Native.ajaxv2({
      url: Api('LPS'),
      data: {
        method: 'qihoo.sdk.lps2ipay.repay.apply',
        bizContent: bizContent
      }
    })
  }else{
    return verifyTradersPwd({
      requestUrl:Api('LPS'),
      title: '请输入交易密码',
      businessParams: {
        ...bizContent,
        pwdType: 'T',
        authType: 'PWD',
      },
      field: 'transPwd',
      isShowToast: 'F',
      method: 'qihoo.sdk.lps2ipay.repay.apply'
    })
  }
}
/**
 * 多订单还款申请接口
 * loanNos 订单号列表
 * cardId 用户选择的银行卡ID
 * repayAmount 还款金额
 * ticketNo 优惠券号
 * transPwd 密码
 * trustStatus Y-可信设备，无需密码，N-非可信设备，transPwd字段必传
 */
export function mu_orderRepayApply (bizContent) {
  if(bizContent.trustStatus === 'Y'){
    return Native.ajaxv2({
      url: Api('IPAYLPS_NEW'),
      data: {
        method: 'qihoo.sdk.ipay.more.order.repay.apply',
        bizContent: bizContent
      }
    })
  }else{
    return verifyTradersPwd({
      requestUrl:Api('IPAYLPS_NEW'),
      title: '请输入交易密码',
      businessParams: {
        ...bizContent,
        pwdType: 'T',
        authType: 'PWD',
      },
      field: 'transPwd',
      isShowToast: 'F',
      method: 'qihoo.sdk.ipay.more.order.repay.apply'
    })
  }
}
export function alipayLoop (bizContent) {
  return Native.ajaxv2({
    isShowLoading: false,
    isShowToast: false,
    url: Api('IPAYLPS_NEW'),
    data: {
      method: 'qihoo.sdk.ipay.query.alipay.trade.order',
      bizContent: bizContent
    }
  })
}
