import Native from 'native'
import Api from '../common/api'

export function HHB_USER_ACCOUNTCache(){
  return Native.getCacheData(Api('HHB_USER_ACCOUNT'))||{}
}
/**
 * 获取花花比数量
 * @returns {Promise<>} {
      "totalPoint": "花花币数量",
      "month": "月份",
      "vipFlag": "是否vip"
   * }
 */
export function HHB_USER_ACCOUNT () {
  return Native.ajaxv2({
    useCache: 60,
    isShowLoading: false,
    url: Api('INTEGRAL_URL'),
    data: {
      method: Api('HHB_USER_ACCOUNT'),
      bizContent: {}
    }
  })
}
