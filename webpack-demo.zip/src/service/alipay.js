//支付宝还款

/*支付宝支付预验证
qihoo.sdk.trade.repay.alipay.preverify
*/

/*支付宝支付验证
qihoo.sdk.trade.repay.alipay.verify
*/


/*支付宝正常还款申请
qihoo.sdk.trade.repay.alipay.normal
 */

/*支付宝逾期还款申请
qihoo.sdk.trade.repay.alipay.overdue
 */


/*前端唤起支付宝支付后，调用本接口查询支付结果
qihoo.sdk.trade.repay.alipay.query
*/

