import * as service from './instance'
import request from './request'

export { request }
export default service
