/*
queryTxt
请求活动规则的文案
缓存 300秒
 */
import getText from '@/common/getText'
import {limitCache} from '@/utils/limitCache'

export async function queryTxt (url) {
  return limitCache({id:url,name:'queryTxt',useCache:300},()=>{
    return getText(url)
  })
}