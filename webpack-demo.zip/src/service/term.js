// 查询资源位
import { Dialog } from 'vant'
import Api from '../common/api'

let _queryTermCache = null

export function queryTermCache () {
  return _queryTermCache || Native.getCacheData(Api('WLH_iPayQueryTerm')) || {}
}

//查询分期
export async function queryTerm () {
  if (!_queryTermCache) {
    try {
      _queryTermCache = await Native.ajaxv2({
        isShowLoading: false,
        isShowToast: false,
        url: Api('IPAYLPS'),
        data: {
          method: Api('WLH_iPayQueryTerm'),
          bizContent: {}
        }
      })
      const map = {}
      const nObj = _queryTermCache.normalRateDtoList || _queryTermCache.rates
      //常规分润费率
      for (let i = 0; i < nObj.length; i++) {
        const item = nObj[i]
        map[item.term] = item
      }

//折扣费率
      const zObj = _queryTermCache.rates || _queryTermCache.normalRateDtoList
      for (let i = 0; i < zObj.length; i++) {
        const item = zObj[i]
        for (const k in item) {
          if (k !== 'term') {
            if (map[item.term]) {
              map[item.term][k + '2'] = item[k]
            }
          }
        }
        zObj[i] = map[item.term]
      }
      _queryTermCache.userInstallmentVO = Object.assign({}, map[_queryTermCache.term])
    } catch (res) {
      // 此错误码代表用户无定价， 不能进行分期设置，前端不展示分期设置，不需要弹窗报错
      if (res.code !== 'BIPAY8011') {
        Dialog.alert({
          message: res.msg,
          className: 'wlh'
        })
      }
    }

  }
  return _queryTermCache
}

//设置分期
export async function saveTerm (obj) {
  const term = typeof obj === 'object' ? obj.term : obj
  if (_queryTermCache && _queryTermCache.hasTerm === 'Y' && _queryTermCache.term === term) {
    return
  }
  await Native.ajaxv2({
    noCache: true,
    url: Api('IPAYLPS'),
    data: {
      method: Api('WLH_iPaySaveTerm'),
      bizContent: {term}
    }
  })
  if (_queryTermCache) {
    _queryTermCache.term = term
    _queryTermCache.hasTerm = 'Y'
  }
}