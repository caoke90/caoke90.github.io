import Native from 'native'
import Api from '../common/api'
import Config from '../common/Config'
import conCurentLoad from '../utils/conCurentLoad';
// 缓存
const cacheEleData = {}
const timeEleData = {}
let isLoading=false;
let id=0;
let lArr=[]
// 查询资源位
export async function queryEle (eleTypeArr,cacheTime=60) {
  const now=+new Date();
  const neleTypeArr=eleTypeArr.filter(function (eleName) {
    if(cacheEleData[eleName]&&now-timeEleData[eleName]<cacheTime*1000){//资源位数据缓存60秒
      return false;
    }else{
      return true;
    }
  })
  if(neleTypeArr.length>0){
    if(!isLoading){
      isLoading=true;
      lArr=[]
      id++;
      neleTypeArr.forEach(function (name) {
        lArr.push(name)
      })
    }else{
      neleTypeArr.forEach(function (name) {
        lArr.push(name)
      })
    }
    await new Promise((resolve)=>{
      setTimeout(resolve,0)
    })
    const eleType=lArr.join('|')
    isLoading=false;
    const data = await conCurentLoad('eleId'+id,function () {
      return Native.ajaxv2({
        noCache:true,
        isShowLoading:false,
        url: Api('ELE'),
        data: {
          method: Api('queryElements'),
          bizContent: {
            eleType: eleType,
            diTuiQrCodeFlag: Config.query.diTuiQrCodeFlag || 'N'
          }
        }
      })
    })
    neleTypeArr.forEach(function (eleName) {
      cacheEleData[eleName]=data[eleName+'s']
      timeEleData[eleName]=now;
    })
  }

  const resData={}
  eleTypeArr.forEach(function (eleName) {
    const key=eleName+'s'
    resData[key]=cacheEleData[eleName]
  })
  return resData
}

// ele通用点击反馈接口
export function eleFeedback (eleType, elementCode) {
  return Native.ajaxv2({
    noCache:true,
    url: Api('ELE'),
    data: {
      method: Api('ELE_COMMON_CLICK'),
      bizContent: {
        eleType,
        elementCode
      }
    }
  })
}
