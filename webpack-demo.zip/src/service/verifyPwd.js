import Native from 'native'
import {Dialog} from 'vant'

/**
 * 验证交易密码弹窗公共处理
 * option 订单号列表
 * event 事件名 start、success、gologin、needlogin、againerr、again、cancel
 */
export async function verifyTradersPwd (option,event={}) {
  event.start&&Native.reportUbas({
    eventCode: event.start
  })
  const res = await Native.verifyTradersPwd(option)
  if (res && res.flag === 'S') {
    event.success&&Native.reportUbas({
      eventCode: event.success
    })
    return res.data
  } else if (res && res.flag === 'F') {
    // 如果是失败的情况
    if (res.code === 'BLPS0004') {
      event.gologin&&Native.reportUbas({
        eventCode: event.gologin
      })
      Native.forward({
        data: {
          url: 'login.html',
          redirectURL: 'index.html'
        }
      })
      throw res;
    } else if (res.code === 'BLPS1213') { // 需要重新登录
      event.needlogin&&Native.reportUbas({
        eventCode: event.needlogin
      })
      await Dialog.confirm({
        message: res.msg,
        confirmButtonText: '去登录',
        className: 'wlh'
      })
      Native.forward({
        data: {
          url: 'login.html',
          redirectURL: 'index.html'
        }
      })
      throw res;
    } else if (res.msg) {
      if (res.code === 'BLPS1206') { // 交易密码输入错误次数过多，请于明日再试或尝试找回密码
        event.againerr&&Native.reportUbas({
          eventCode: event.againerr
        })
        await Dialog.confirm({
          message: res.msg,
          confirmButtonText: '找回密码',
          cancelButtonText: '明日再试',
          className: 'wlh'
        }).then(function () {
          Native.forward({
            data: {
              url: 'bind_authentication.html',
              redirectURL: 'index.html'
            }
          })
        })
        throw res;
      } else {
        event.again&&Native.reportUbas({
          eventCode: event.again
        })
        try {
          await Dialog.confirm({
            message: res.msg,
            confirmButtonText: '重试',
            cancelButtonText: '忘记密码',
            className: 'wlh'
          })
          const ok=await verifyTradersPwd (option)
          return ok;
        }catch (e) {
          Native.forward({
            data: {
              url: 'bind_authentication.html',
              redirectURL: 'index.html'
            }
          })
        }
      }
    } else {
      event.cancel&&Native.reportUbas({
        eventCode: event.cancel
      })
      throw res;
    }
  }
}