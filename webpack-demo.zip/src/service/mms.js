/* eslint-disable camelcase */
import Native from 'native'
import Api from '../common/api'

/** 微零花领券中心-可领优惠券数(首页)
 *
 qihoo.sdk.marketing.wlh.welfare.center.receive
 */

export function marketing_count () {
  return Native.ajaxv2({
    noCache: true,
    isShowLoading: false,
    url: Api('MMS'),
    data: {
      method: 'qihoo.sdk.marketing.wlh.welfare.center.count',
      bizContent: {}
    }
  })
}

/** 微零花领券中心-福利列表
*
qihoo.sdk.marketing.wlh.welfare.center.list
*/

export function query_marketing_list (useCache) {
  return Native.ajaxv2({
    useCache: useCache,
    isShowLoading: false,
    url: Api('MMS'),
    data: {
      method: 'qihoo.sdk.marketing.wlh.welfare.center.list.v3',
      bizContent: {}
    }
  })
}

/** 微零花领券中心-福利领取
 *
 qihoo.sdk.marketing.wlh.welfare.center.receive
 */

export function marketing_receive (awardCode) {
  return Native.ajaxv2({
    noCache: true,
    isShowLoading: false,
    url: Api('MMS'),
    data: {
      method: 'qihoo.sdk.marketing.wlh.welfare.center.receive',
      bizContent: { awardCode }
    }
  })
}

// 微零花优惠券信息查询
export function couponInfoQuery (couponCode, couponNo) {
  return Native.ajaxv2({
    noCache: true,
    isShowLoading: false,
    url: Api('MMS'),
    data: {
      method: 'qihoo.sdk.marketing.micro.pk.coupon.detail.query',
      bizContent: { couponCode, couponNo }
    }
  })
}

// 微零花首页优惠券信息查询
export function queryIndexCoupon () {
  return Native.ajaxv2({
    noCache: true,
    isShowLoading: false,
    url: Api('MMS'),
    data: {
      method: Api('HOME_COUPON_QUERY'),
      bizContent: {}
    }
  })
}

// 笔笔返首页信息查询
export function queryCashBackIndex () {
  return Native.ajaxv2({
    noCache: true,
    isShowLoading: false,
    url: Api('MMS'),
    data: {
      method: Api('CASH_BACK_INDEX'),
      bizContent: {}
    }
  })
}

// 笔笔返抽奖接口
export function cashBackDraw (bizContent) {
  return Native.ajaxv2({
    noCache: true,
    isShowLoading: true,
    url: Api('MMS'),
    data: {
      method: Api('CASH_BACK_DRAW'),
      bizContent
    }
  })
}

// 笔笔返抽奖列表接口
export function getPrizeList (bizContent = {}) {
  return Native.ajaxv2({
    noCache: true,
    isShowLoading: true,
    url: Api('MMS'),
    data: {
      method: Api('CASH_BACK_AWARD_LIST'),
      bizContent: Object.assign({
        pageSize: 10
      }, bizContent)
    }
  })
}

// 设置优先级券
export function setSingerPriorityCoupon (bizContent = {}) {
  return Native.ajaxv2({
    noCache: true,
    isShowLoading: true,
    url: Api('MMS'),
    data: {
      method: Api('WLH_SET_PRIORITY_COUPON'),
      bizContent
    }
  })
}

export function getActivityCouponInfo (bizContent = {}) {
  return Native.ajaxv2({
    useCache: 1,
    isShowLoading: false,
    isShowToast: false,
    url: Api('MMS'),
    data: {
      method: Api('SERVICE_ACTIVITY_COUPON'),
      bizContent
    }
  })
}