import Native from 'native'
import Api from '@/common/api'
import _ from 'lodash'
import { Toast } from 'vant'
import { Msg } from '@/common/Config'
import { serverErrorCode } from '../common/Dicts'

const handleKickeOut = () => {
  Toast({
    message: '请重新登录',
    onClose: () => {
      Native.forward({
        data: {
          url: 'login.html',
          redirectURL: 'index.html'
        }
      })
    }
  })
}

/**
 * @param {object} options                                                  可选参数对象，必选
 * @param {
 *  'LPS' | 'IPAYLPS' | 'IPAYLPS_NEW' | 'MMS' | 'ELE' | 'HELP' |
 *  'ANALYSLS_URL' | 'OLD_WLH_BILL' | 'CONTRACTCDN' | 'INTEGRAL_URL'
 * } options.url                                                            接口基础路径，非必选，默认 'IPAYLPS'
 * @param {string} options.method                                           接口实际路径，必选
 * @param {object} options.data                                             请求参数，非必选，默认 {}
 * @param {object} options.appendData                                       请求追加参数，跟bizContent同层级，非必选，默认 undefined
 * @param {boolean} options.isShowLoading                                   是否显示loading，非必选，默认 true
 * @param {string} options.loadingText                                      loading加载文本，非必选，默认 Msg.loading
 * @param {boolean} options.isShowToast                                     是否显示错误Toast，非必选，默认 true
 * @returns {object} data | resonpse                                        接口返回信息，如果请求成功，则返回data层级数据，否则返回整个数据
 */
export default async function request (options) {
  const { url, method, data, appendData, isShowLoading, loadingText, isShowToast } = _.merge({
    url: 'IPAYLPS',
    data: {},
    isShowLoading: true,
    loadingText: Msg.loading,
    isShowToast: true
  }, options)
  isShowLoading && Toast.loading({
    message: loadingText,
    forbidClick: true,
    duration: 0
  })

  try {
    const res = await Native.ajaxCache({
      url: Api(url),
      data: {
        method: Api(method),
        bizContent: JSON.stringify(data),
        ...appendData
      }
    })
    isShowLoading && Toast.clear()

    // 处理登录失效
    if (_.includes([serverErrorCode.lps0004, serverErrorCode.lps1213], _.get(res, 'code'))) handleKickeOut()

    const flag = _.get(res, 'flag')
    if (flag === 'S') {
      return _.get(res, 'data', {})
    }

    throw res
  } catch (err) {
    isShowLoading && Toast.clear()
    isShowToast && Toast(_.get(err, 'msg') || Msg.defaultErr)
    return Promise.reject(err)
  }
}
