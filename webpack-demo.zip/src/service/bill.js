import Native from 'native'
import Api from '../common/api'

/**
 * 我的账单-首页
 * @param {string} billDate '账单年月201909，传空默认当前月'
 * @returns {Promise<>} {
      "billDate": "账单日期，毫秒值",
      "billStatus": "账单状态枚举",
      "billStatusDesc": "账单状态描述\t",
      "paidAmt": "已还金额",
      "repaymentAmt": "待还金额",
      "dateDue": "还款日，毫秒值",
      "repaymentDateFlag": "是否为最后还款日标记 Y-是，N-不是",
      "overdueRepaymentAmt": "逾期待还金额",
      "overdueDays": "逾期天数 ",
      "lateFeeAmt": "违约金金额",
      "overdueTotalAmt": "逾期总欠款金额",
      "overdueGrade": "逾期级别 0，1,2,3",
      "frozenFlag": "账户是否冻结 Y-是，N-否"
   * }
 */
export function queryBillPage (billDate ){
  return Native.ajaxv2({
    useCache:60,
    url: Api('IPAYLPS'),
    data: {
      method: Api('BILL_PAGE'),
      bizContent: {
        billDate: billDate||'',
      }
    }
  })
};

/**
 * 年度账单-12月列表
 * @param {array} months [201901,201902...201912]
 * @returns {Promise<>} {
      "year": "年份 2019",
      "monthlyBills|12": [
        {
          "month": "第x月 201909",
          "billStatus": "账单状态 ",
          "billStatusDesc": "账单描述",
          "hasBill": "是否有账单 Y-有，N-没有",
          "repaymentAmt": "待还金额",
          "paidAmt": "已还金额",
          "overdueDays": "逾期天数"
        }
      ]
   * }
 */
export function queryBillMonthList (months) {
  return Native.ajaxv2({
    useCache:60,
    url: Api('IPAYLPS'),
    data: {
      method: Api('BILL_MONTH_LIST'),
      bizContent: {
        months: months,
      }
    }
  })
}


/**
 * 账单明细
 * @param {string} billDate '账单年月201909，传空默认当前月'
 * @returns {Promise<>} {
      "billDate": "账单时间，毫秒值",
      "billStatus": "账单状态枚举",
      "billStatusDesc": "账单状态描述",
      "paidAmt": "已还金额",
      "repaymentAmt": "待还金额",
      "repaymentDate": "还款日 毫秒值",
      "repaymentDateFlag": "是否为最后还款日标记 Y-是，N-否",
      "overdueRepaymentAmt": "逾期待还金额",
      "overdueDays": "逾期天数 ",
      "lateFeeAmt": "违约金金额",
      "contractTerminateFlag": " 合同是否终止Y-是，N-否",
      "entryAmt": "本月入账-有退款情况 ",
      "offsetAmt": "退款冲抵金额-有退款情况",
      "repaymentBills|3": [
        {
          "installment": "期数1",
          "installmentTotal": "总期数3",
          "merchantName": "商户名称",
          "payChannel": "支付渠道",
          "installmentAmt": "分期金额",
          "loanNo": "借据号"
        }
      ],
      "paidBills|3": [
        {
          "installment": "期数1",
          "installmentTotal": "总期数3",
          "merchantName": "商户名称",
          "payChannel": "支付渠道",
          "installmentAmt": "分期金额",
          "loanNo": "借据号",
          "repaymentDate": "应还款日期 毫秒值",
          "actualRepaymentDate": "实际还款日毫秒值",
          "earlyRepaymentFlag": "是否提前还款 Y-是，N-否",
          "orderDeductActAmt": "用户实际还款优惠后金额"
        }
      ],
      "offsetFlag": "退款标识，Y-是，N-否",
      "ointAmount": "罚息",
      "intAmount": "利息",
      "displayButton": "是否展示按钮，Y-是，N-否",
      "overdueGrade": "逾期级别0，1，2，3",
      "frozenFlag": "冻结标识，Y-冻结，N-未冻结",
      "overdueTotalAmt": "逾期时总欠款金额"
   * }
 */
export function queryBillDetail (billDate) {
  return Native.ajaxv2({
    useCache:60,
    store:true,
    url: Api('IPAYLPS'),
    data: {
      method: Api('BILL_DETAIL'),
      bizContent: {
        billDate: billDate||'',
      }
    }
  })
}

/**
 * 订单详情
 * @param {string} loanNo '借据号'
 * @param {string} payResult '该笔流水状态'
 * @param {string} payNo '我方支付流水号 '
 * @returns {Promise<>} {
       loanStatusDesc": "账单当前状态",
      "payChannelCode": "支付渠道",
      "merchantName": "商户名称",
      "payAmt": "消费本金",
      "billGeneratedFlag": "账单是否生成 Y-已生成，N-没",
      "payType": "支付方式",
      "fundsSource": "资金来源",
      "loanNo": "借据号",
      "loanDate": "下单时间 毫秒值",
      "loanStatus": "订单状态"
   * }
 */
export function queryBillLoanDetail (loanNo = '', payResult = '',  payNo = '') {
  return Native.ajaxv2({
    useCache:60,
    url: Api('IPAYLPS'),
    data: {
      method: Api('BILL_LOAN_DETAIL'),
      bizContent: {
        loanNo,
        payResult,
        payNo
      }
    }
  })
}