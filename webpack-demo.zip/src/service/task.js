import Native from 'native'
import Api from '../common/api'



/**
 * 首页任务列表
 * @returns {Promise<>} {
      "forceTaskList": [],
      "taskList": []
   * }
 */

export function query_home_all_task () {
  return Native.ajaxv2({
    useCache: 6,
    isShowLoading: false,
    url: Api('INTEGRAL_URL'),
    data: {
      method: Api('query_home_all_task'),
      bizContent: {activityCode:'i_pay_new'}
    }
  })
}
/*
* 领取任务*/
export function receive_home_task (taskGroupNo) {
  return Native.ajaxv2({
    noCache:true,
    isShowLoading: false,
    url: Api('INTEGRAL_URL'),
    data: {
      method: Api('home_receive_task'),
      bizContent: {taskGroupNo:taskGroupNo}
    }
  })
}
/*
* 领取奖励*/
export function receive_home_award (businessNo) {
  Native.delCache(Api('HHB_USER_ACCOUNT'));//更新花花币
  return Native.ajaxv2({
    noCache:true,
    isShowLoading: false,
    url: Api('INTEGRAL_URL'),
    data: {
      method: Api('home_receive_award'),
      bizContent: {businessNo:businessNo}
    }
  })
}
/**
 * 首页签到一周查询接口
 * @returns {Promise<>} {
      "forceTaskList": [],
      "taskList": []
   * }
 */

export function query_home_user_sign_week () {
  return Native.ajaxv2({
    name:'query_home_user_sign_week',
    useCache: 6,
    isShowLoading: false,
    url: Api('INTEGRAL_URL'),
    data: {
      method: Api('query_home_user_sign_record'),
      bizContent: {
        businessBelong:'i_pay_new',
      }
    }
  })
}
export function query_home_user_sign () {
  Native.delCache('query_home_user_sign_week')
  Native.delCache(Api('HHB_USER_ACCOUNT'))//更新花花币
  return Native.ajaxv2({
    noCache:true,
    isShowLoading: false,
    url: Api('INTEGRAL_URL'),
    data: {
      method: Api('query_home_user_sign'),
      bizContent: {
        businessBelong:'i_pay_new',
      }
    }
  })
}
