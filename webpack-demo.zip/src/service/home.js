import Native from 'native'
import Api from '../common/api'
import Config from '../common/Config'

// 首页 骨架图数据
export function getHomeSkeleton () {
  const data = Native.getCacheData(Api('WLH_iPayHome')) || {
    pageOutputVO: {
      status: Config.firstData.status
    }
  }
  return data
}
// 旧微零花骨架图
export function getOldHomeSkeleton () {
  const data = Native.getCacheData(Api('WLH_iPayOldHome'))|| {
    oldBillOutputVO: {}
  }
  return data
}

// 使用首页数据
export async function ipayQueryHomeData (useCache) {
   const data=await Native.ajaxv2({
    useCache: useCache,
    store: true,
    isShowLoading: false,
    url: Api('IPAYLPS'),
    data: {
      method: Api('WLH_iPayHome'),
      bizContent: {}
    }
  })
  return data||{}
}
// 查询老微零花数据
export async function queryOldHome (useCache) {
  const data=await Native.ajaxv2({
    useCache: useCache,
    isShowLoading: false,
    store: true,
    url: Api('IPAYLPS'),
    data: {
      method: Api('WLH_iPayOldHome'),
      bizContent: {}
    }
  })
  return data||{}
}
