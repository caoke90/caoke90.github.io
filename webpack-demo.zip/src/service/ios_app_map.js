export default {
  V20200618A: [
    {
      appName: '交管12123',
      appCode: 'com.tmri.12123',
      appScheme: 'wx0ea99e425e26f1d4',
    },
    {
      appName: '美团',
      appCode: 'com.meituan.imeituan',
      appScheme: 'wxa552e31d6839de85',
    },
    {
      appName: '58同城',
      appCode: 'com.taofang.iphone',
      appScheme: 'wxc7929cc3d3fda545',
    },
    {
      appName: '大众点评',
      appCode: 'com.dianping.dpscope',
      appScheme: 'wx8e251222d6836a60',
    },
    {
      appName: '汽车之家',
      appCode: 'com.autohome',
      appScheme: 'wxbca640f74160480d',
    },
    {
      appName: '腾讯视频',
      appCode: 'com.tencent.live4iphone',
      appScheme: 'wxca942bbff22e0e51',
    },
    {
      appName: '爱奇艺',
      appCode: 'com.qiyi.iphone',
      appScheme: 'wx2fab8a9063c8c6d0',
    },
    {
      appName: '全民K歌',
      appCode: 'com.tencent.QQKSong',
      appScheme: 'wx2ed190385c3bafeb',
    },
    {
      appName: '小红书',
      appCode: 'com.xingin.discover',
      appScheme: 'wxd8a2750ce9d46980',
    },
    {
      appName: '知乎',
      appCode: 'com.zhihu.ios',
      appScheme: 'wxd3f6cb54399a8489',
    },
    {
      appName: 'MOMO陌陌',
      appCode: 'com.wemomo.momoappdemo1',
      appScheme: 'wx53440afb924e0ace',
    },
    {
      appName: '拼多多',
      appCode: 'com.xunmeng.pinduoduo',
      appScheme: 'wx77d53b84434b9d9a',
    },
    {
      appName: '京东',
      appCode: 'com.360buy.jdmobile',
      appScheme: 'wxe75a2e68877315fb',
    },
    {
      appName: '闲鱼',
      appCode: 'com.taobao.fleamarket',
      appScheme: 'wx24ca05cc7b7a643b',
    },
    {
      appName: '王者荣耀',
      appCode: 'com.tencent.smoba',
      appScheme: 'wx95a3a4d7c627e07d',
    },
    {
      appName: '和平精英',
      appCode: 'com.tencent.tmgp.pubgmhd',
      appScheme: 'wxc4c0253df149f02d',
    },
    {
      appName: '个人所得税',
      appCode: 'cn.gov.tax.its',
      appScheme: 'its',
    },
    {
      appName: '京东金融',
      appCode: 'com.jd.jinrong',
      appScheme: 'wxa3b3f36fcd9df06e',
    },
    {
      appName: 'UC浏览器',
      appCode: 'com.ucweb.iphone.lowversion',
      appScheme: 'wx020a535dccd46c11',
    },
    {
      appName: '腾讯新闻',
      appCode: 'com.tencent.info',
      appScheme: 'wxb10c47503e8c8e01',
    },
    {
      appName: '今日头条',
      appCode: 'com.ss.iphone.article.News',
      appScheme: 'wx50d801314d9eb858',
    },
    {
      appName: '驾考宝典',
      appCode: 'cn.mucang.ios.jiakaobaodianhuoche',
      appScheme: 'sinaweibosso.3090570975',
    },
    {
      appName: '作业帮',
      appCode: 'com.baidu.homework',
      appScheme: 'wxa5677f1877d37b12',
    },
    {
      appName: '滴滴出行',
      appCode: 'com.xiaojukeji.didi',
      appScheme: 'wxd5b252a1660012b4',
    },
    {
      appName: '携程旅行',
      appCode: 'ctrip.com',
      appScheme: 'wx6b1afe00d5ee385d',
    },
    {
      appName: '铁路12306',
      appCode: 'cn.12306.rails12306',
      appScheme: 'wxb84362f15c06b3f2',
    },
    {
      appName: '企业微信',
      appCode: 'com.tencent.ww',
      appScheme: 'wxwork',
    },
    {
      appName: '喜马拉雅',
      appCode: 'com.gemd.iting',
      appScheme: 'wxb9371ecb5f0f05b1',
    },
    {
      appName: '优酷视频',
      appCode: 'com.youku.YouKu',
      appScheme: 'wxa77232e51741dee3',
    },
    {
      appName: '探探',
      appCode: 'com.yaymedialabs.putong',
      appScheme: 'wx67f59443a9c801bb',
    },
    {
      appName: '开心消消乐',
      appCode: 'com.happyelements.1OSAnimal',
      appScheme: 'wx14ab6700bfff2325',
    },
    {
      appName: '云闪付',
      appCode: 'com.unionpay.chsp',
      appScheme: 'wx82582d2ace426da2',
    },
    {
      appName: '学习强国',
      appCode: 'cn.xuexi.qg',
      appScheme: 'wx799e8d865ee93d55',
    },
    {
      appName: '钉钉',
      appCode: 'com.laiwang.DingTalk',
      appScheme: 'wxb7d5fb09a46a5bb8',
    },
    {
      appName: '支付宝',
      appCode: 'com.alipay.iphoneclient',
      appScheme: 'alipays',
    },
    {
      appName: '百度地图',
      appCode: 'com.baidu.map',
      appScheme: 'wx9a08a4f59ce91bf6',
    },
    {
      appName: '微信',
      appCode: 'com.tencent.xin',
      appScheme: 'wexinVideoAPI',
    },
    {
      appName: 'QQ',
      appCode: 'com.tencent.mqq',
      appScheme: 'wxf0a80d0ac2e82aa7',
    },
    {
      appName: '微博',
      appCode: 'com.sina.weibo',
      appScheme: 'wx299208e619de7026',
    },
    {
      appName: '分期乐',
      appCode: 'com.fenqile.phone',
      appScheme: 'wx97d143dfcd43eb9a',
    },
  ],
  B20201210A: [
    {
      appName: '有钱花',
      appCode: 'com.duxiaoman.umoney',
      appScheme: 'wx90086b95d19b9e72',
    },
    {
      appName: '汽车之家',
      appCode: 'com.autohome',
      appScheme: 'wxbca640f74160480d',
    },
    {
      appName: '小红书',
      appCode: 'com.xingin.discover',
      appScheme: 'wxd8a2750ce9d46980',
    },
    {
      appName: '个人所得税',
      appCode: 'cn.gov.tax.its',
      appScheme: 'its',
    },
    {
      appName: '作业帮',
      appCode: 'com.baidu.homework',
      appScheme: 'wxa5677f1877d37b12',
    },
    {
      appName: '铁路12306',
      appCode: 'cn.12306.rails12306',
      appScheme: 'wxb84362f15c06b3f2',
    },
    {
      appName: '企业微信',
      appCode: 'com.tencent.ww',
      appScheme: 'wxwork',
    },
    {
      appName: '喜马拉雅',
      appCode: 'com.gemd.iting',
      appScheme: 'wxb9371ecb5f0f05b1',
    },
    {
      appName: '学习强国',
      appCode: 'cn.xuexi.qg',
      appScheme: 'wx799e8d865ee93d55',
    },
    {
      appName: '分期乐',
      appCode: 'com.fenqile.phone',
      appScheme: 'wx5dd0c378885b7072',
    },
    {
      appName: '壹钱包',
      appCode: 'com.pinganfu.yqb.youqian',
      appScheme: 'wx09a87be488774e6a',
    },
    {
      appName: '融360',
      appCode: 'com.rong360.victor',
      appScheme: 'wx9dd505db3698cd25',
    },
    {
      appName: '平安普惠',
      appCode: 'com.pingan.yidaixian',
      appScheme: 'wx7c9caf15a038b0d8',
    },
    {
      appName: '还呗',
      appCode: 'com.focus-eloan.eloan',
      appScheme: 'wx8c6fa712f7c69610',
    },
    {
      appName: '招联金融',
      appCode: 'com.mucfc.llhapp',
      appScheme: 'wx93026d25c480f3fc',
    },
    {
      appName: '小米贷款',
      appCode: 'com.xiaomi.loan',
      appScheme: 'wx8183bd995772893b',
    },
    {
      appName: '度小满金融',
      appCode: 'com.baidu.wallet',
      appScheme: 'wx9e8876f47ba17e53',
    },
    {
      appName: '小米金融',
      appCode: 'com.xiaomi.jr',
      appScheme: 'wx0d2358702515062e',
    },
    {
      appName: '苏宁金融',
      appCode: 'com.suning.SuningEfubao',
      appScheme: 'wxaf906a45e757d77b',
    },
    {
      appName: '宜人贷借款',
      appCode: 'com.creditease.yirendai.apps',
      appScheme: 'yrdweb',
    },
    {
      appName: '玖富万卡',
      appCode: 'com.jfbank.wanka',
      appScheme: 'wx8c608041be0260ec',
    },
    {
      appName: '拉卡拉收款宝',
      appCode: 'com.lakala.shoudan',
      appScheme: 'wxceb066400c8ab40b',
    },
    {
      appName: '拍拍贷借款',
      appCode: 'com.ppdai.loan',
      appScheme: 'wx97fe7decfe4f8868',
    },
    {
      appName: '捷信金融',
      appCode: 'jiexin.hcc.com',
      appScheme: 'wx0c470cf7f04ce6f5',
    },
    {
      appName: '省呗',
      appCode: 'com.samoyed.creditkuai',
      appScheme: 'wxb7c0071c90e25bf8',
    },
    {
      appName: '安逸花',
      appCode: 'com.msxf.ayh',
      appScheme: 'wxf2b0142a7808f8e3',
    },
    {
      appName: '好分期',
      appCode: 'com.renrendai.haohuan',
      appScheme: 'wxef25308724a7932b',
    },
    {
      appName: '安全教育平台',
      appCode: 'com.SafetyEducationPlatform',
      appScheme: 'wx871e8781f6fed214',
    },
    {
      appName: '小天才',
      appCode: 'com.xtc.callwatch',
      appScheme: 'wx7acb8f450c221419',
    },
    {
      appName: '手机天猫',
      appCode: 'com.taobao.tmall',
      appScheme: 'wx2d1fca14baf41e8c',
    },
    {
      appName: '苏宁易购',
      appCode: 'SuningEMall',
      appScheme: 'wxe386966df7b712ca',
    },
    {
      appName: '米家',
      appCode: 'com.xiaomi.mihome',
      appScheme: 'mijia',
    },
    {
      appName: '去哪儿旅行',
      appCode: 'com.qunar.iphoneclient8',
      appScheme: 'wx065b247a5e4d0ee7',
    },
    {
      appName: 'WiFi万能钥匙',
      appCode: 'com.lantern.wifikey.mobile',
      appScheme: 'wx13f22259f9bbd047',
    },
    {
      appName: 'MOMO陌陌',
      appCode: 'com.wemomo.momoappdemo1',
      appScheme: 'wx53440afb924e0ace',
    },
    {
      appName: '支付宝',
      appCode: 'com.alipay.iphoneclient',
      appScheme: 'alipays',
    },
    {
      appName: '微信',
      appCode: 'com.tencent.xin',
      appScheme: 'wexinVideoAPI',
    },
    {
      appName: 'QQ',
      appCode: 'com.tencent.mqq',
      appScheme: 'wxf0a80d0ac2e82aa7',
    },
    {
      appName: '微博',
      appCode: 'com.sina.weibo',
      appScheme: 'wx299208e619de7026',
    },
    {
      appName: '百度地图',
      appCode: 'com.baidu.map',
      appScheme: 'wx9a08a4f59ce91bf6',
    },
  ],
  F20210429A: [
    {
      appName: '个人所得税',
      appCode: 'cn.gov.tax.its',
      appScheme: 'its',
    },
    {
      appName: '买单吧',
      appCode: 'com.bankcomm.maidanba',
      appScheme: 'wxdb2295f552d546a5',
    },
    {
      appName: 'Study',
      appCode: 'cn.xuexi.qg',
      appScheme: 'wx799e8d865ee93d55',
    },
    {
      appName: '天眼查',
      appCode: 'com.jindidata.SkyEyes',
      appScheme: 'wxb95dc20dcf9fbd0a',
    },
    {
      appName: 'Booking.com缤客',
      appCode: 'com.booking.BookingApp',
      appScheme: 'wxa427cc47ce632290',
    },
    {
      appName: '发现精彩',
      appCode: 'com.cgb.creditcard.iphone',
      appScheme: 'wxe4603ff4b118ac2f',
    },
    {
      appName: 'CamScanner_Lite',
      appCode: 'com.intsig.CamScannerLite',
      appScheme: 'wxd69a7d7420e1c0d7',
    },
    {
      appName: '途虎养车',
      appCode: 'tuhu.cn.main',
      appScheme: 'wx0484d1035f9c2785',
    },
    {
      appName: 'VideoGo',
      appCode: 'com.hikvision.videogo',
      appScheme: 'wx081facf9c1d928c1',
    },
    {
      appName: '肯德基',
      appCode: 'com.yum.kfc.brand',
      appScheme: 'wx1ebb9c41ccbfb6d4',
    },
    {
      appName: '民生银行手机银行',
      appCode: 'com.cmbc.cn.iphone',
      appScheme: 'wx42840ed4e9347932',
    },
    {
      appName: '贝壳找房',
      appCode: 'com.lianjia.beike',
      appScheme: 'wx82cc4b304cdf58c5',
    },
    {
      appName: '东方财富',
      appCode: 'com.eastmoney.iphone',
      appScheme: 'wxb062331269cec15f',
    },
    {
      appName: '小天才',
      appCode: 'com.xtc.callwatch',
      appScheme: 'wx7acb8f450c221419',
    },
    {
      appName: '同花顺',
      appCode: 'cn.com.10jqka.IHexin',
      appScheme: 'wxc30efa39c0191186',
    },
    {
      appName: '小爱音箱',
      appCode: 'com.xiaomi.mico',
      appScheme: 'wxf090e58b058932e0',
    },
    {
      appName: '腾讯会议',
      appCode: 'com.tencent.meeting',
      appScheme: 'wxf80860aa29a91007',
    },
    {
      appName: '分期乐',
      appCode: 'com.fenqile.phone',
      appScheme: 'wx97d143dfcd43eb9a',
    },
    {
      appName: '安逸花',
      appCode: 'com.msxf.ayh',
      appScheme: 'wxf2b0142a7808f8e3',
    },
    {
      appName: '捷信金融',
      appCode: 'jiexin.hcc.com',
      appScheme: 'wx0c470cf7f04ce6f5',
    },
    {
      appName: '王者营地',
      appCode: 'com.tencent.smobagamehelper',
      appScheme: 'wxf4b1e8a3e9aaf978',
    },
    {
      appName: '省呗',
      appCode: 'com.samoyed.creditkuai',
      appScheme: 'wxb7c0071c90e25bf8',
    },
    {
      appName: '好分期',
      appCode: 'com.renrendai.haohuan',
      appScheme: 'wxef25308724a7932b',
    },
    {
      appName: 'QQ飞车',
      appCode: 'com.tencent.tmgp.speedmobile',
      appScheme: 'wx360b06d575d20cc3',
    },
    {
      appName: '国美易卡',
      appCode: 'com.gomejr.icash',
      appScheme: 'wx7f7853ab9a063751',
    },
    {
      appName: '比心陪练',
      appCode: 'com.yitan.bixin',
      appScheme: 'wx0c7bd6f322191f9c',
    },
    {
      appName: '来分期',
      appCode: 'com.laifenqi.fenqiapp',
      appScheme: 'wxe82fd5b1fc761e16',
    },
    {
      appName: '融360',
      appCode: 'com.rong360.victor',
      appScheme: 'wx9dd505db3698cd25',
    },
    {
      appName: '小赢卡贷',
      appCode: 'com.xiaoying.cardloan',
      appScheme: 'wx1fd62d0a6068e18a',
    },
    {
      appName: '掌上道聚城',
      appCode: 'com.tencent.daojucheng',
      appScheme: 'wxb406849bf1dd54fc',
    },
    {
      appName: '掌上穿越火线',
      appCode: 'com.tencent.qtcfapp',
      appScheme: 'wxecd607830cdbb9d9',
    },
    {
      appName: '榕树贷款',
      appCode: 'com.shuqu.banyan',
      appScheme: 'wxcd17b3669dd33f1b',
    },
    {
      appName: 'TT语音',
      appCode: 'com.yiyou.tt',
      appScheme: 'wx4707fa6c043875f3',
    },
    {
      appName: '快手直播伴侣',
      appCode: 'com.kwai.liveMateStore',
      appScheme: 'wxd3daebb9bff0ad67',
    },
    {
      appName: '你我贷借款',
      appCode: 'com.niwodai.jiekuan',
      appScheme: 'QQ420713D9',
    },
  ],
}