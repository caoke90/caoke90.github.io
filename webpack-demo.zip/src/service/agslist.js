import Api from '../common/api'

// 介绍页-合同列表，对一类协议进行了打包
export function ipayAgreementParcelList () {
  return Native.ajaxv2({
    useCache: true,
    isShowLoading: false,
    url: Api('IPAYLPS_NEW'),
    data: {
      method: Api('AGREEMENT_PARCEL_LIST'),
      bizContent: {
        procedureTypes: ['FQKAUTH', 'TERM','TERM_COMMON', 'ACCOUNT', 'FQKACC', 'FQKSERVE', 'LAUTH'],
        accountFlag: 'Y',
        filterSignFlag: 'Y',
        honourCreditOrgs: ['PARTNER_MSXJ']
      }
    }
  })
}

// -合同列表——一户多卡
export function ipayIntroAgreementList (bizContent = {}) {
  return Native.ajaxv2({
    useCache: true,
    isShowLoading: false,
    url: Api('IPAYLPS'),
    data: {
      method: Api('INTRO_AGS_LIST'),
      bizContent
    }
  })
}
