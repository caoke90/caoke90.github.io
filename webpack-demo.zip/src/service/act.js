// 2020年度账单
import Api from '../common/api'

export function queryAnnualBill () {
  return Native.ajaxv2({
    isShowLoading: false,
    url: Api('IPAYLPS_NEW'),
    data: {
      method: 'qihoo.sdk.ipay.query.user.annual.bill',
      bizContent: {}
    }
  })
}

export function MGM_BILL2020 () {
  return Native.ajaxv2({
    useCache:300,
    isShowLoading: false,
    url: Api('MMS'),
    data: {
      method: Api('MGM_SHARE_MINIPROGRAM'),
      bizContent: {
        bizType: 'MICRO_MGM_BILL2020_APP'
      }
    }
  })
}