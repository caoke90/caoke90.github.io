import Api from '../common/api'
import ios_app_map from './ios_app_map'

/**
 * 反欺诈嗅探
 */
let lock = false
let lock2 = false

export async function fraudUploadMiddle () {
  if (lock||lock2) {
    return
  }
  lock = true
  setTimeout(() => {
    lock = false
  }, 6000)
  try {
    const {fireEventAgainFlag, appListCode} = await Native.ajaxv2({
      isShowLoading: false,
      url: Api('IPAYLPS_NEW'),
      data: {
        method: Api('qihoo_sdk_ipay_anti_fraud_sniffer'),
        bizContent: {}
      }
    })
    if (fireEventAgainFlag) {
      if(Native.IS_ANDROID){
        const res = await Native.getInstalledApps()
        const bizContent = {
          appList: [],
        }
        const fileMap = []
        if (res.data.fileId) {
          fileMap.push({
            fileId: res.data.fileId,
            fileKey: 'appList'
          })
        } else {
          bizContent.appList = res.data.appList
        }
        await Native.ajaxv2({
          fileMap: fileMap,
          isShowLoading: false,
          url: Api('IPAYLPS_NEW'),
          data: {
            method: Api('qihoo_sdk_ipay_fire_event'),
            bizContent
          }
        })
      }else if(appListCode){
        const res = await Native.getInstalledApps(ios_app_map[appListCode] || [])
        const bizContent = {
          appListCode,
          appList: [],
        }
        const fileMap = []
        if (res.data.fileId) {
          fileMap.push({
            fileId: res.data.fileId,
            fileKey: 'appList'
          })
        } else {
          bizContent.appList = res.data.appList
        }
        await Native.ajaxv2({
          fileMap: fileMap,
          isShowLoading: false,
          url: Api('IPAYLPS_NEW'),
          data: {
            method: Api('qihoo_sdk_ipay_fire_event'),
            bizContent
          }
        })
      }

      lock2 = true
    }
  } catch (e) {
    lock = false
  }

}