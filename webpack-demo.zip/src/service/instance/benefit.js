import request from '../request'

// 微零花圣诞活动-查询用户奖励
export function benefitChrisQueryAward () {
  return request({ url: 'INTEGRAL_URL', method: 'BENEFIT_CHRIS_QUERY_AWARD' })
}

// 微零花圣诞活动-查询全部任务
export function benefitChrisQueryTask (activityCode = 'i_pay_chris_activity ') {
  return request({ url: 'INTEGRAL_URL', method: 'BENEFIT_CHRIS_QUERY_TASK', data: { activityCode } })
}

// 微零花圣诞活动-用户奖励历史列表
export function benefitChrisAwardHistory (activityCode = 'i_pay_chris_activity ') {
  return request({ url: 'INTEGRAL_URL', method: 'BENEFIT_CHRIS_AWARD_HISTORY', data: { activityCode } })
}

// 微零花圣诞活动-领取任务奖励
export function benefitChrisReceiveAward (businessNo) {
  return request({ url: 'INTEGRAL_URL', method: 'BENEFIT_CHRIS_RECEIVE_AWARD', data: { businessNo } })
}

// 微零花圣诞活动-用户签到
export function benefitChrisUserSign (businessBelong = 'i_pay_chris_activity') {
  return request({ url: 'INTEGRAL_URL', method: 'BENEFIT_CHRIS_USER_SIGN', data: { businessBelong } })
}
