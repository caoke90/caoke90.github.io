import request from '../request'

// 查询优惠券列表接口（支持分页）
export function mmsQueryCouponList (options) {
  return request({
    url: 'MMS',
    method: 'WLH_queryCoupon',
    isShowLoading: false,
    data: {
      ...options
    }
  })
}

// 查询跨年活动信息
export function mmsQueryNewYearInfo (options = {}) {
  return request({
    url: 'MMS',
    method: 'NEW_YEAR_2021',
    data: {
      ...options
    }
  })
}

// 领取跨年红包
export function mmsDrawNewYearEnvelope (options = {}) {
  return request({
    url: 'MMS',
    method: 'NEW_YEAR_2021_DRAW',
    data: {
      ...options
    }
  })
}

// 首页免息额度信息
export function mmsInterestFreeQuotaHome () {
  return request({
    url: 'MMS',
    method: 'INTEREST_FREE_QUOTA_HOME',
    isShowLoading: false
  })
}

// 用户福利浮层
/**
 * @param {String} type='1' 1 => 额度 + 优惠券，2 => 额度
 */
export function mmsWelfareFloatingLayer (type = '1') {
  return request({
    url: 'MMS',
    method: 'WELFARE_FLOATING_LAYER',
    data: { type },
    isShowLoading: false
  })
}

// 已动支状态查询推荐优惠券
export function mmsLoanedCouponRecommend () {
  return request({
    url: 'MMS',
    method: 'LOANED_COUPON_RECOMMEND',
    isShowLoading: false
  })
}

// 免息额度详情页
export function mmsInterestFreeQuotaDetail () {
  return request({
    url: 'MMS',
    method: 'INTEREST_FREE_QUOTA_DETAIL'
  })
}

/**
 * 免息额度开关更新
 * @param  {String} quotaSwitch 1 => 开, 2 => 关
 */
export function mmsInterestFreeQuotaSwitch (quotaSwitch) {
  return request({
    url: 'MMS',
    method: 'INTEREST_FREE_QUOTA_SWITCH',
    data: { quotaSwitch }
  })
}

/**
 * 免息额度组成
 * @param  {Object} data 请求参数
 * @param  {'valid' | 'ineffective'} data.type 免息额度类型，valid(有效),ineffective(未生效)
 */
export function mmsInterestFreeQuotaData (data) {
  return request({
    url: 'MMS',
    method: 'INTEREST_FREE_QUOTA_DATA',
    data
  })
}

/**
 * 免息额度记录
 * @param  {Object} data 请求参数
 * @param  {String} data.length 每次数量
 * @param  {String} data.nextId 下一页id
 * @param  {'elicit' | 'use' | 'overdue'} data.type 类型，elicit(获取),use(使用),overdue(过期)
 */
export function mmsInterestFreeQuotaLog (data) {
  return request({
    url: 'MMS',
    method: 'INTEREST_FREE_QUOTA_LOG',
    data,
    isShowLoading: false
  })
}

/**
 * 周周赢iPhone-周周送iphone首页
 * @param  {Object} data 请求参数
 * @param  {'userNo'} data.userNo
 */
export function mmsWeekPkMain (data) {
  return request({
    url: 'MMS',
    method: 'ACT_WEEK_PK_MAIN',
    data
  })
}

/**
 * 周周赢iPhone-立即报名
 * @param  {Object} data 请求参数
 * @param  {'userNo'} data.userNo
 */
export function mmsWeekPkApply (data) {
  return request({
    url: 'MMS',
    method: 'ACT_WEEK_PK_APPLY',
    data
  })
}

/**
 * 周周赢iPhone-立即订阅
 * @param  {Object} data 请求参数
 * @param  {'userNo'} data.userNo
 */
export function mmsWeekPkSub (data) {
  return request({
    url: 'MMS',
    method: 'ACT_WEEK_PK_SUB',
    data
  })
}

/**
 * 周周赢iPhone-参与记录
 * @param  {Object} data 请求参数
 * @param  {'userNo'} data.userNo
 */
export function mmsWeekPkParticipation (data) {
  return request({
    url: 'MMS',
    method: 'ACT_WEEK_PK_PARTICIPATION',
    data
  })
}

/**
 * 周周赢iPhone-历史排行榜
 * @param  {Object} data 请求参数
 * @param  {'userNo', 'batchNumber'} data
 */
export function mmsWeekPkHistory (data) {
  return request({
    url: 'MMS',
    method: 'ACT_WEEK_PK_HISTORY',
    data
  })
}