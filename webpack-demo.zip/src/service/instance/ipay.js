import request from '../request'

// 授信开卡流程状态接口
export function ipayQueryState () {
  return request({ url: 'IPAYLPS_NEW', method: 'WLH_iPayQueryState' })
}

// 弹框 - 协议查询接口 (新户)
export function ipayDialogAgsList (data) {
  return request({ url: 'IPAYLPS_NEW', method: 'IPAY_DIALOG_AGS_LIST', data })
}

// LPS协议信息预览
export function ipayAgsAgreement (options) {
  return request({ url: 'IPAYLPS', method: 'IPAY_AGR_PREVIEW', ...options })
}
// LPS设置分期信息预览
export function ipayInstallAgreement (options) {
  return request({ url: 'IPAYLPS', method: 'PREVIEW_INSTALLMENT_AGREEMENT', ...options })
}
// 微信支付宝绑卡页面银行卡列表查询
export function ipayBankCardQuery (options) {
  return request({ url: 'IPAYLPS_NEW', method: 'WECHAT_ALIPAY_BANK_CARD', ...options })
}

// 一键绑卡
export function ipayOneKeyBind (options) {
  return request({ url: 'IPAYLPS_NEW', method: 'BAIXIN_BIND_CARD', ...options })
}

// 一户多卡-开卡结果查询
export function ipayMoreCardInfo (options) {
  return request({ url: 'IPAYLPS_NEW', method: 'IPAY_MORE_CARD_INFO', ...options })
}

// 一户多卡-提交开卡
export function ipayMoreCardCommit (options) {
  return request({ url: 'IPAYLPS_NEW', method: 'IPAY_MORE_CARD_COMMIT', ...options })
}

// 一户多卡-银行卡列表查询
export function ipayQueryMoreCardList (options) {
  return request({ url: 'IPAYLPS_NEW', method: 'IPAY_MORE_CARD_LIST', ...options })
}

// 请求首页数据
export function ipayQueryHomeData (options) {
  return request({ url: 'IPAYLPS', method: 'WLH_iPayHome', ...options })
}

// 首页-降价弹窗信息
export function ipayQueryReduceInfo (isShowLoading = false) {
  return request({
    url: 'IPAYLPS',
    method: 'PRICE_REDUCE_QUERY',
    isShowLoading,
    isShowToast: false
  })
}

// 首页-增加资金方弹窗信息
export function ipayQueryAddFundInfo (isShowLoading = false) {
  return request({
    url: 'IPAYLPS_NEW',
    method: 'ADD_FUND_AGREEMENT',
    isShowLoading,
    isShowToast: false
  })
}

// 首页-降价弹窗-点击签署
export function ipayReduceSign () {
  return request({ url: 'IPAYLPS', method: 'PRICE_REDUCE_SIGN' })
}

// 请求协议列表接口
export function ipayQueryAgreementList (options) {
  return request({ url: 'IPAYLPS', method: 'INTRO_AGS_LIST', ...options })
}

// 请求协议列表接口
export function ipayUserDeviceTrustStatus (options) {
  return request({ url: 'IPAYLPS_NEW', method: 'IPAY_USER_DEVICE_TRUST_STATUS', ...options })
}

// 交易类型说明-优惠券展示页面费率展示
export function ipayInstallmentQueryIntroduceRate () {
  return request({ url: 'IPAYLPS_NEW', method: 'IPAY_INSTALLMENT_QUERY_INTRODUCE_RATE' })
}

// 介绍页-合同列表，对一类协议进行了打包
export function ipayAgreementParcelList (data) {
  return request({ url: 'IPAYLPS_NEW', method: 'AGREEMENT_PARCEL_LIST', data })
}

// 登录后微零花状态查询
export function ipayH5StatusInfo () {
  return request({ url: 'IPAYLPS_NEW', method: 'IPAY_H5_STATUS_INFO' })
}
