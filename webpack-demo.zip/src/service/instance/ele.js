import request from '../request'

// ele通用请求接口
export function eleQuery (eleType, params = {}) {
  return request({
    url: 'ELE',
    method: 'queryElements',
    isShowLoading: false,
    data: {
      eleType,
      ...params
    }
  })
}

// ele通用点击反馈接口
export function eleFeedback (eleType, elementCode) {
  return request({
    url: 'ELE',
    method: 'ELE_COMMON_CLICK',
    data: {
      eleType,
      elementCode
    }
  })
}
