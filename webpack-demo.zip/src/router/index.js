/* eslint-disable no-undef */
import Config from '../common/Config'
import Api from '../common/api'
import Router from 'vue-router'
import BModal from 'BModal'
import Native from 'native'
import { Toast } from 'vant'

/**
 * 懒加载view
 * @param view 对应的views目录下的文件
 * @returns {function(): (Promise<*>|*)}
 */
BModal.isFirstPageInit = false
BModal.status=false;

const lazyView = (view) => async () => {
  return import(/* webpackChunkName: "[request]"  */ `@/views/${view}`)
}
const routes = []
routes.push({
  path: '/http*',
  // 跳转到其他外部页面
  beforeEnter: function (to, from, next) {
    Native.openURL(to.fullPath.substr(1))
  }
})
for (const url in Config.UrlNode) {
  const name=url.replace('.html','')
  routes.push({
    path: '*/' + url,
    name: name,
    component: lazyView(name),
    meta: Config.UrlNode[url]
  })
}

routes.push({
  path: '*',
  // 跳转到其他外部页面
  beforeEnter: function (to, from, next) {
    if (to.path === '/') {
      location.href = 'test.html?appChannel=dev&serverEnv=dev'
    }
  }
})
const router = new Router({
  // mode: 'hash',
  mode: 'history',
  // base: Config.publicPath,
  routes: routes,
  scrollBehavior (to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return { x: 0, y: 0 }
    }
  }
})
router.beforeEach(async (to, from, next) => {

  if (!Config.firstName) {
    Config.firstName = to.name
  }

  next()
})
// 进入页面的时候，初始化
router.afterEach((to, from) => {

  // document.body.scrollTop = 0
  // document.documentElement.scrollTop = 0
})

export default router
