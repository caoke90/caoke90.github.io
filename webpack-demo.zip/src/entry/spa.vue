<template>
  <div
    ref="root"
    :class="[IS_IPHONE, $route.name, 'view', IS_ANDROID]">
    <mv-modal mkey="header" />
      <router-view :key="$route.fullPath" />
    <mv-modal mkey="footer" />
  </div>
</template>
<script>
// 标题
import BModal from 'BModal'
import Native from 'native'

export default {
  data () {
    return {
      // 设备className
      IS_IPHONE: Native.IS_IPHONE_X ? 'IphoneX' : (Native.IS_IOS ? 'Iphone' : ''),
      IS_ANDROID: !Native.IS_IOS ? 'android' : ''
    }
  },
  watch: {
  },
  created () {
    BModal.app = this
  }
}
</script>
<style lang="less">
.view {
  height: 100%;
}
</style>