// 引入公共js
import { rootEle } from '../common/vendor'

import Vue from 'vue'

// ui库
import { Toast, Icon } from 'vant'

// 项目的入口
import App from './spa.vue'
import router from '../router'

import dssReport, { vueErrorHandler } from '@/plugin/DssReport'

// 修改Toast默认配置参数
Toast.setDefaultOptions('success', { forbidClick: true, icon: 'passed' })
Vue.use(Toast)
Vue.use(Icon)

Vue.config.devtools = process.env.NODE_ENV === 'development'

// DSS 监控上报
try {
  // 首页加载性能监控
  dssReport.reportFirstPage()

  // js错误监控
  vueErrorHandler((errItem) => {
    dssReport.addError(errItem)
    dssReport.reportErrorList()
  })
} catch (error) {
  console.error('Dss report error is', error)
}
async function start () {
  let _Native= await import(/* webpackChunkName: "h5Native"  */ '../common/h5Native.js')

  Object.assign(Native, _Native.default)
  // native中的路由
  Native.router = router
  new Vue({
    router,
    render: (h) => h(App) // 把app挂载到html里
  }).$mount(rootEle)
}
start()
