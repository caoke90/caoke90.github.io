export default function (value) {
  if (!value || isNaN(value)) return value
  const strArr = String(value).split('.')
  let strInt = strArr[0]
  const strDecimal = strArr[1]
  let result = ''
  while (strInt.length > 3) {
    result = ',' + strInt.slice(-3) + result
    strInt = strInt.slice(0, strInt.length - 3)
  }
  if (strInt) {
    result = strInt + result
  }
  return result + (strDecimal ? `.${strDecimal}` : '')
}
