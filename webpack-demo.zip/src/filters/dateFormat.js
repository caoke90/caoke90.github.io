import dayjs from 'dayjs'

export default function (value, template) {
  if (!value) return value
  return dayjs(value).format(template || 'YYYY.MM.DD')
}
