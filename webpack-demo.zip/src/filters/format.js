import _ from 'lodash';
import dayjs from 'dayjs';

export default (timestamp, template) => {
  if (_.isNil(timestamp)) {
    return '-'
  } else {
    return dayjs(Number(timestamp)).format(template);
  }
}
