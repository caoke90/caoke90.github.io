<template>
  <div class="hello">
    <h1>vue文件中通过注释写配置</h1>
    <p>
        //页面配置title=hello world
    </p>
    <h3>不打包到生产环境</h3>
    <ul>
      <li>//页面配置 dev_title=测试页&build=dev</li>
    </ul>
  </div>
</template>

<script>

//页面配置title=hello world
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
h3{
    margin: 40px 0 0;
}

ul{
    list-style-type: none;
    padding :0;
}

li{
    display: inline-block;
    margin:0 10px;
}

a{
    color:#42b983;
}
</style>
