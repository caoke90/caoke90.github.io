<template>
  <div class="container">
    <header class="search-header">
      <van-icon
        name="search"
        class="search-icon" />
      <input
        type="search"
        placeholder="根据页面 title 或 url 搜索"
        :value="searchVal"
        @input="searchInput">
    </header>
    <div class="page-content">
      <h2>版本：{{ curVersion }}</h2>
      <van-grid :column-num="3">
        <van-grid-item
          v-for="(item,key) in fliteredPageList"
          v-show="key!=='md5'"
          :key="key"
          :text="item.dev_title||item.title"
          @click="openURL(item.key)" />
      </van-grid>
    </div>
  </div>
</template>

<script>
//页面配置title=test&build=dev
import Vue from 'vue'
import { Icon, Grid, GridItem } from 'vant'
import Native from 'native'

import Config from '../common/Config'
import Api from '../common/api'
import BModal from 'BModal'

import _ from 'lodash'

Vue.use(Grid)
Vue.use(GridItem)

console.log(Config)
// 提取页面对象
const pageList = Object.keys(Config.UrlNode).map(item => ({ ...Config.UrlNode[item], key: item }))
// 汉字拼音排序
pageList.sort((a, b) => {
  const aTtitle = a.dev_title || a.title || ''
  const bTtitle = b.dev_title || b.title || ''
  return aTtitle.localeCompare(bTtitle, 'zh')
})
const ss = window.sessionStorage || {}
const SEARCH_VALUE_KEY = '28f8a697'

export default {
  components: {
    'van-icon': Icon
  },
  data () {
    return {
      BModal: BModal,
      curVersion: process.env.curVersion,
      pageList,
      searchVal: ss.getItem(SEARCH_VALUE_KEY)
    }
  },
  computed: {
    fliteredPageList () {
      const value = this.searchVal

      if (!value) {
        return this.pageList
      }

      return this.pageList.filter(item => {
        const devTitle = item.dev_title || ''
        const title = item.title || ''
        const url = item.key||""
        return (devTitle.indexOf(value) !== -1) || (title.indexOf(value) !== -1) || (url.indexOf(value) !== -1)
      })
    }
  },
  created () {
    this.searchInput = _.debounce(this.handleSearchChange, 100)
    // 初始化缓存值
    if (this.searchVal) this.handleSearchChange({ target: { value: this.searchVal } })
  },
  methods: {
    handleSearchChange (e) {
      const value = e.target.value
      this.searchVal = value
      ss.setItem(SEARCH_VALUE_KEY, value)
    },
    forward4 () {
      Native.forward({
        data: {
          url: 'authenticate_failed.html'
        }
      })
    },
    // 验证密码
    async verifyPwd () {
      const data = await BModal.verifyPwd.skip()
      console.log('验证密码', data)
    },
    openURL (url) {
      this.$router.push({
        path: url,
        query: Config.query
      })
    },
    async verifyTradersPwd () {
      await Native.verifyTradersPwd({
        title: '请输入交易密码',
        businessParams: {
          pwdType: 'T',
          authType: 'PWD',
          authPartner: 'XINYONGHUA'
        },
        field: 'password',
        isShowToast: 'F',
        method: 'qihoo.sdk.user.auth.partnerverify'
      })
    }
  }
}

</script>

<style type="text/css" lang="less" scoped>
  .search-header {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 99;
    width: 100%;
    height: 100px;
    padding: 20px 25px;
    background-color: #eee;

    .search-icon {
      position: absolute;
      top: 32px;
      left: 35px;
      color: #777;
      font-size: 34px;
      pointer-events: none;
    }

    input {
      display: block;
      width: 100%;
      height: 100%;
      padding: 0 20px 0 50px;
      font-size: 26px;
      line-height: 34px;
      background-color: #ddd;
      border-radius: 10px;
      appearance: none;
    }
  }

  .page-content {
    margin-top: 130px;
  }

  h2 {
    margin-bottom: 10px;
    padding: 0 25px;
    font-size: 40px;
  }

  ul {
    margin-bottom: 20px;
    font-size: 32px;
    line-height: 3px;
  }

  li {
    margin-bottom: 1px;
    padding: 0 25px;
    line-height: 60px;
  }
</style>
