<template>
    <div class="hello">
        <van-button @click="clickBtn" type="primary">点击全局组件alert</van-button>
    </div>
</template>

<script>
  //页面配置title=全局组件demo
  import Vue from 'vue';
  import { Button } from 'vant';
  import BModal from "BModal";

  Vue.use(Button);
  import alert from '../componets/alert';
  BModal.addModalComponent(alert,'footer')

  export default {
    name: 'HelloWorld',
    methods:{
      async clickBtn(){
        const back=await BModal.alert.show('我是全局组件alert')
        console.log('确认')
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.hello{
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>
