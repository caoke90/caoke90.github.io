<template>
    <div class="hello">
        <van-button @click="clickBtn" type="primary">点击全局组件alert</van-button>
        <mv-alert ref="alert"></mv-alert>
    </div>
</template>

<script>
  //页面配置title=页面组件demo
  import Vue from 'vue';
  import { Button } from 'vant';

  Vue.use(Button);
  import alert from '../componets/alert';

  export default {
    name: 'HelloWorld',
    components:{
      'mv-alert':alert
    },
    methods:{
      async clickBtn(){
        const back=await this.$refs.alert.show('我是全局组件alert')
        console.log('确认')
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.hello{
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>
