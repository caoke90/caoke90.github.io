module.exports=[
  {
    "/":"/test.html",

  },{
    "/api/element.do":"/api/element.do",//资源位
    "/ubas/event/report":"/api/report.do",//资源位
  }
]
