module.exports = {
  "extends": [
    "stylelint-config-standard",
    "stylelint-config-rational-order"
  ],
  "rules": {
    "indentation": 2,
    "no-missing-end-of-source-newline": null,
    "max-nesting-depth": 4,
    "selector-max-compound-selectors": 4,
    "at-rule-no-unknown": null,
    "scss/at-rule-no-unknown": true,
    "selector-pseudo-class-no-unknown": [true, {
      ignorePseudoClasses: ['global', 'local']
    }],
    "selector-list-comma-newline-after": null,
    "unit-case": null,
    "font-family-no-missing-generic-family-keyword": null,
    "no-descending-specificity": null,
  },
  "plugins": [
    "stylelint-scss"
  ]
}