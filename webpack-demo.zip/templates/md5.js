//版本控制<% include include/_common.ejs %>
var LCacheLib="<%=require('@/lib/LCache.js')%>";
var LCacheName='LCache-'+LCacheLib;
if(!localStorage[LCacheName]){
var xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET",LCacheLib,false);
xmlhttp.send();
  if (xmlhttp.readyState===4&&xmlhttp.status===200) {
    localStorage.setItem('UpLCacheLib',LCacheName);//移除之前的缓存
    localStorage.setItem(LCacheName,xmlhttp.responseText);
  }
}
var script = document.createElement('script');
script.text = localStorage.getItem(LCacheName);
document.getElementsByTagName('head')[0].appendChild( script );

var curVersion='<%=process.env.curVersion%>';
LCache.loadChunk(curVersion,'wlhVersion');//增量包
window.Native={};
LCache.dataArr=[
"<%=require('@/lib/axios.js')%>",
"<%=require('@/lib/es6-promise.js')%>",
"<%=require('@/lib/vue.js')%>",
"<%=require('@/lib/vue-router.js')%>",
"<%=require('@/lib/fastclick.js')%>",
"<%=getEntry('spa','css')%>",
"<%=getEntry('spa','js')%>",
];
LCache.loadAll(LCache.dataArr)
